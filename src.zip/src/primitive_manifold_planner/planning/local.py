from __future__ import annotations

from dataclasses import dataclass
from typing import Any
import numpy as np

from primitive_manifold_planner.manifolds import ImplicitManifold
from primitive_manifold_planner.projection import project_newton


@dataclass
class LocalPathResult:
    """
    Result of local constrained path generation on a manifold.
    """

    success: bool
    path: np.ndarray
    iterations: int
    reached_goal: bool
    message: str
    planner_name: str = "projection"
    chart_count: int = 0


def _validate_local_inputs(
    manifold: ImplicitManifold,
    x_start: np.ndarray,
    x_goal: np.ndarray,
    step_size: float,
    goal_tol: float,
    max_iters: int,
):
    if step_size <= 0.0:
        raise ValueError(f"step_size must be positive, got {step_size}")
    if goal_tol <= 0.0:
        raise ValueError(f"goal_tol must be positive, got {goal_tol}")
    if max_iters <= 0:
        raise ValueError(f"max_iters must be positive, got {max_iters}")

    x_start = manifold._coerce_point(x_start)
    x_goal = manifold._coerce_point(x_goal)

    return x_start, x_goal


def _failed_result(
    x_start: np.ndarray,
    message: str,
    planner_name: str,
) -> LocalPathResult:
    return LocalPathResult(
        success=False,
        path=np.array([x_start]),
        iterations=0,
        reached_goal=False,
        message=message,
        planner_name=planner_name,
        chart_count=0,
    )


def _point_is_within_bounds(manifold: ImplicitManifold, x: np.ndarray, tol: float = 1e-9) -> bool:
    within_fn = getattr(manifold, "within_bounds", None)
    if callable(within_fn):
        return bool(within_fn(np.asarray(x, dtype=float), tol=tol))
    return True


def constrained_interpolate(
    manifold: ImplicitManifold,
    x_start: np.ndarray,
    x_goal: np.ndarray,
    step_size: float = 0.1,
    goal_tol: float = 1e-3,
    max_iters: int = 500,
    projection_tol: float = 1e-10,
    projection_max_iters: int = 50,
    projection_damping: float = 1.0,
) -> LocalPathResult:
    """
    Projection-style local constrained motion.

    Strategy:
      - move directly toward goal in ambient space
      - project each trial step back onto the manifold
    """
    x_start, x_goal = _validate_local_inputs(
        manifold=manifold,
        x_start=x_start,
        x_goal=x_goal,
        step_size=step_size,
        goal_tol=goal_tol,
        max_iters=max_iters,
    )

    if not manifold.is_valid(x_start, tol=1e-6):
        return _failed_result(
            x_start=x_start,
            message="Start point is not on the manifold.",
            planner_name="projection",
        )

    if not manifold.is_valid(x_goal, tol=1e-6):
        return _failed_result(
            x_start=x_start,
            message="Goal point is not on the manifold.",
            planner_name="projection",
        )

    if not _point_is_within_bounds(manifold, x_start):
        return _failed_result(
            x_start=x_start,
            message="Start point is outside bounded manifold limits.",
            planner_name="projection",
        )

    if not _point_is_within_bounds(manifold, x_goal):
        return _failed_result(
            x_start=x_start,
            message="Goal point is outside bounded manifold limits.",
            planner_name="projection",
        )

    x_current = x_start.copy()
    path = [x_current.copy()]

    for k in range(max_iters):
        to_goal = x_goal - x_current
        dist_to_goal = float(np.linalg.norm(to_goal))

        if dist_to_goal <= goal_tol:
            return LocalPathResult(
                success=True,
                path=np.asarray(path),
                iterations=k,
                reached_goal=True,
                message="Reached goal tolerance on the manifold.",
                planner_name="projection",
                chart_count=0,
            )

        direction = to_goal / max(dist_to_goal, 1e-15)
        step = min(step_size, dist_to_goal)
        x_trial = x_current + step * direction

        proj = project_newton(
            manifold=manifold,
            x0=x_trial,
            tol=projection_tol,
            max_iters=projection_max_iters,
            damping=projection_damping,
        )

        if not proj.success:
            return LocalPathResult(
                success=False,
                path=np.asarray(path),
                iterations=k,
                reached_goal=False,
                message=f"Projection failed during local planning: {proj.message}",
                planner_name="projection",
                chart_count=0,
            )

        x_next = proj.x_projected

        if not _point_is_within_bounds(manifold, x_next):
            return LocalPathResult(
                success=False,
                path=np.asarray(path),
                iterations=k,
                reached_goal=False,
                message="Projection left the bounded manifold region.",
                planner_name="projection",
                chart_count=0,
            )

        move_norm = float(np.linalg.norm(x_next - x_current))
        if move_norm <= 1e-12:
            return LocalPathResult(
                success=False,
                path=np.asarray(path),
                iterations=k,
                reached_goal=False,
                message="Local planning stalled: projected step made no progress.",
                planner_name="projection",
                chart_count=0,
            )

        path.append(x_next.copy())
        x_current = x_next

    final_dist = float(np.linalg.norm(x_goal - x_current))
    reached_goal = final_dist <= goal_tol

    return LocalPathResult(
        success=reached_goal,
        path=np.asarray(path),
        iterations=max_iters,
        reached_goal=reached_goal,
        message=(
            "Local planning reached max iterations and hit goal tolerance."
            if reached_goal
            else "Local planning reached max iterations without reaching the goal."
        ),
        planner_name="projection",
        chart_count=0,
    )


def _choose_tangent_direction(
    manifold: ImplicitManifold,
    x_current: np.ndarray,
    x_goal: np.ndarray,
    preview_step: float,
) -> np.ndarray:
    """
    Choose a tangent direction whose sign better reduces distance to x_goal.

    For codimension-1 manifolds, the tangent projector applied to the goal
    direction gives a good local continuation direction.
    """
    to_goal = x_goal - x_current
    to_goal_norm = float(np.linalg.norm(to_goal))
    if to_goal_norm <= 1e-15:
        return np.zeros_like(x_current)

    ambient_dir = to_goal / to_goal_norm
    tangent_dir = manifold.project_tangent(x_current, ambient_dir)
    tangent_norm = float(np.linalg.norm(tangent_dir))

    # If goal direction is almost normal to the manifold, build a fallback tangent
    # from the Jacobian normal in 2D codim-1 cases.
    if tangent_norm <= 1e-12 and manifold.ambient_dim == 2 and manifold.codim == 1:
        J = manifold.jacobian(x_current)
        n = J.reshape(-1)
        tangent_dir = np.array([-n[1], n[0]], dtype=float)
        tangent_norm = float(np.linalg.norm(tangent_dir))

    if tangent_norm <= 1e-12:
        return np.zeros_like(x_current)

    tangent_dir = tangent_dir / tangent_norm

    x_plus = x_current + preview_step * tangent_dir
    x_minus = x_current - preview_step * tangent_dir

    if np.linalg.norm(x_plus - x_goal) <= np.linalg.norm(x_minus - x_goal):
        return tangent_dir
    return -tangent_dir


def atlas_like_interpolate(
    manifold: ImplicitManifold,
    x_start: np.ndarray,
    x_goal: np.ndarray,
    step_size: float = 0.1,
    goal_tol: float = 1e-3,
    max_iters: int = 500,
    projection_tol: float = 1e-10,
    projection_max_iters: int = 50,
    projection_damping: float = 1.0,
    preview_fraction: float = 0.5,
    min_progress_tol: float = 1e-10,
    max_step_growth: float = 2.5,
) -> LocalPathResult:
    """
    Atlas-like continuation local planner.

    Strategy:
      - compute a local tangent direction at current point
      - step along tangent direction
      - project back to the manifold
      - treat each accepted projected point as a new local chart center

    This is not a full AtlasRRT chart atlas, but it is a continuation-style
    local planner built from tangent stepping plus projection correction.
    """
    x_start, x_goal = _validate_local_inputs(
        manifold=manifold,
        x_start=x_start,
        x_goal=x_goal,
        step_size=step_size,
        goal_tol=goal_tol,
        max_iters=max_iters,
    )

    if not manifold.is_valid(x_start, tol=1e-6):
        return _failed_result(
            x_start=x_start,
            message="Start point is not on the manifold.",
            planner_name="atlas_like",
        )

    if not manifold.is_valid(x_goal, tol=1e-6):
        return _failed_result(
            x_start=x_start,
            message="Goal point is not on the manifold.",
            planner_name="atlas_like",
        )

    if not _point_is_within_bounds(manifold, x_start):
        return _failed_result(
            x_start=x_start,
            message="Start point is outside bounded manifold limits.",
            planner_name="atlas_like",
        )

    if not _point_is_within_bounds(manifold, x_goal):
        return _failed_result(
            x_start=x_start,
            message="Goal point is outside bounded manifold limits.",
            planner_name="atlas_like",
        )

    x_current = x_start.copy()
    path = [x_current.copy()]
    chart_count = 1

    for k in range(max_iters):
        to_goal = x_goal - x_current
        dist_to_goal = float(np.linalg.norm(to_goal))

        if dist_to_goal <= goal_tol:
            return LocalPathResult(
                success=True,
                path=np.asarray(path),
                iterations=k,
                reached_goal=True,
                message="Reached goal tolerance on the manifold.",
                planner_name="atlas_like",
                chart_count=chart_count,
            )

        tangent_dir = _choose_tangent_direction(
            manifold=manifold,
            x_current=x_current,
            x_goal=x_goal,
            preview_step=max(step_size * preview_fraction, 1e-6),
        )

        tangent_norm = float(np.linalg.norm(tangent_dir))
        if tangent_norm <= 1e-12:
            return LocalPathResult(
                success=False,
                path=np.asarray(path),
                iterations=k,
                reached_goal=False,
                message="Atlas-like local planning stalled: no usable tangent direction.",
                planner_name="atlas_like",
                chart_count=chart_count,
            )

        step = min(step_size, dist_to_goal)
        x_trial = x_current + step * tangent_dir

        proj = project_newton(
            manifold=manifold,
            x0=x_trial,
            tol=projection_tol,
            max_iters=projection_max_iters,
            damping=projection_damping,
        )

        if not proj.success:
            return LocalPathResult(
                success=False,
                path=np.asarray(path),
                iterations=k,
                reached_goal=False,
                message=f"Projection failed during atlas-like continuation: {proj.message}",
                planner_name="atlas_like",
                chart_count=chart_count,
            )

        x_next = proj.x_projected
        if not _point_is_within_bounds(manifold, x_next):
            return LocalPathResult(
                success=False,
                path=np.asarray(path),
                iterations=k,
                reached_goal=False,
                message="Atlas-like continuation left the bounded manifold region.",
                planner_name="atlas_like",
                chart_count=chart_count,
            )
        move_norm = float(np.linalg.norm(x_next - x_current))

        # retry with a shorter tangent step once if the continuation behaved badly
        if move_norm <= min_progress_tol or move_norm > max_step_growth * step_size:
            x_trial_small = x_current + 0.5 * step * tangent_dir
            proj_small = project_newton(
                manifold=manifold,
                x0=x_trial_small,
                tol=projection_tol,
                max_iters=projection_max_iters,
                damping=projection_damping,
            )

            if not proj_small.success:
                return LocalPathResult(
                    success=False,
                    path=np.asarray(path),
                    iterations=k,
                    reached_goal=False,
                    message=(
                        "Atlas-like continuation failed: projection failed on both full and reduced tangent steps."
                    ),
                    planner_name="atlas_like",
                    chart_count=chart_count,
                )

            x_next = proj_small.x_projected
            if not _point_is_within_bounds(manifold, x_next):
                return LocalPathResult(
                    success=False,
                    path=np.asarray(path),
                    iterations=k,
                    reached_goal=False,
                    message="Reduced atlas-like step left the bounded manifold region.",
                    planner_name="atlas_like",
                    chart_count=chart_count,
                )
            move_norm = float(np.linalg.norm(x_next - x_current))

        if move_norm <= min_progress_tol:
            return LocalPathResult(
                success=False,
                path=np.asarray(path),
                iterations=k,
                reached_goal=False,
                message="Atlas-like local planning stalled: projected tangent step made no progress.",
                planner_name="atlas_like",
                chart_count=chart_count,
            )

        path.append(x_next.copy())
        x_current = x_next
        chart_count += 1

    final_dist = float(np.linalg.norm(x_goal - x_current))
    reached_goal = final_dist <= goal_tol

    return LocalPathResult(
        success=reached_goal,
        path=np.asarray(path),
        iterations=max_iters,
        reached_goal=reached_goal,
        message=(
            "Atlas-like local planning reached max iterations and hit goal tolerance."
            if reached_goal
            else "Atlas-like local planning reached max iterations without reaching the goal."
        ),
        planner_name="atlas_like",
        chart_count=chart_count,
    )


def run_local_planner(
    manifold: ImplicitManifold,
    x_start: np.ndarray,
    x_goal: np.ndarray,
    planner_name: str = "projection",
    **kwargs: Any,
) -> LocalPathResult:
    """
    Dispatch local constrained motion generation by planner name.
    """
    if planner_name == "projection":
        return constrained_interpolate(
            manifold=manifold,
            x_start=x_start,
            x_goal=x_goal,
            **kwargs,
        )

    if planner_name == "atlas_like":
        return atlas_like_interpolate(
            manifold=manifold,
            x_start=x_start,
            x_goal=x_goal,
            **kwargs,
        )

    raise ValueError(
        f"Unknown local planner '{planner_name}'. Expected one of: ['projection', 'atlas_like']"
    )
