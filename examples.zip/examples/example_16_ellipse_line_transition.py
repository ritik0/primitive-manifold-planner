from __future__ import annotations

import numpy as np
import matplotlib
matplotlib.use("TkAgg")
import matplotlib.pyplot as plt

from primitive_manifold_planner.manifolds import EllipseManifold, LineManifold
from primitive_manifold_planner.planning import find_transition_candidates
from primitive_manifold_planner.visualization import (
    finalize_2d_axes,
    plot_ellipse_manifold,
    plot_transition_candidates_2d,
)


def main() -> None:
    ellipse = EllipseManifold(center=np.array([0.0, 0.0]), a=3.0, b=2.0, name="ellipse")
    line = LineManifold(
        point=np.array([0.0, 1.0]),
        normal=np.array([0.0, 1.0]),  # y = 1
        name="line y=1",
    )

    rng = np.random.default_rng(21)
    result = find_transition_candidates(
        manifold_a=ellipse,
        manifold_b=line,
        bounds_min=np.array([-4.0, -3.0]),
        bounds_max=np.array([4.0, 3.0]),
        num_seeds=120,
        tol=1e-8,
        max_candidates=10,
        rng=rng,
    )

    print("=== Ellipse-line transition candidates ===")
    print(f"Success       : {result.success}")
    print(f"Message       : {result.message}")
    print(f"# candidates  : {len(result.candidates)}")

    for i, cand in enumerate(result.candidates):
        print(
            f"  Candidate {i}: "
            f"point={cand.point}, "
            f"residual={cand.residual_norm:.3e}, "
            f"score={cand.score:.6f}"
        )

    fig, ax = plt.subplots(figsize=(8, 7))

    plot_ellipse_manifold(ax, ellipse, label="ellipse")

    xs = np.linspace(-4.0, 4.0, 300)
    ys = np.ones_like(xs)
    ax.plot(xs, ys, label="line y=1")

    selected = result.best_candidate.point if result.best_candidate is not None else None
    plot_transition_candidates_2d(
        ax,
        result.candidates,
        selected_point=selected,
        annotate=True,
    )

    finalize_2d_axes(ax, title="Ellipse-line transition candidates")

    out_path = "example_16_ellipse_line_transition.png"
    plt.savefig(out_path, dpi=200, bbox_inches="tight")
    print(f"Saved figure to: {out_path}")

    plt.show(block=True)


if __name__ == "__main__":
    main()