from __future__ import annotations

import numpy as np
import matplotlib.pyplot as plt

from primitive_manifold_planner.manifolds import CircleManifold
from primitive_manifold_planner.planning import constrained_interpolate
from primitive_manifold_planner.visualization import (
    finalize_2d_axes,
    plot_circle_manifold,
    plot_path_2d,
    plot_start_goal,
)


def main() -> None:
    # Define the manifold
    circle = CircleManifold(center=np.array([0.0, 0.0]), radius=2.0, name="circle")

    # Choose start and goal points that lie on the circle
    x_start = np.array([2.0, 0.0])
    x_goal = np.array([0.0, 2.0])

    # Run local constrained planning
    result = constrained_interpolate(
        manifold=circle,
        x_start=x_start,
        x_goal=x_goal,
        step_size=0.2,
        goal_tol=5e-2,
        max_iters=500,
    )

    print("=== Local constrained interpolation on a circle ===")
    print(f"Success      : {result.success}")
    print(f"Reached goal : {result.reached_goal}")
    print(f"Iterations   : {result.iterations}")
    print(f"Path points  : {len(result.path)}")
    print(f"Message      : {result.message}")

    # Plot result
    fig, ax = plt.subplots(figsize=(7, 7))

    plot_circle_manifold(ax, circle, label="circle manifold")
    plot_path_2d(ax, result.path, show_points=True, label="projected local path")
    plot_start_goal(ax, x_start, x_goal)
    finalize_2d_axes(ax, title="Projection-based local path on a circle")

    plt.show()


if __name__ == "__main__":
    main()