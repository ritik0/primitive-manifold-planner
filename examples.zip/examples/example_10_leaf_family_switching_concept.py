from __future__ import annotations

import numpy as np
import matplotlib
matplotlib.use("TkAgg")
import matplotlib.pyplot as plt
from collections import deque

from primitive_manifold_planner.manifolds import ParallelLineFamily
from primitive_manifold_planner.visualization import finalize_2d_axes


def bfs_path(adjacency: dict[str, list[str]], start: str, goal: str) -> list[str] | None:
    if start == goal:
        return [start]

    queue = deque([start])
    parent = {start: None}

    while queue:
        current = queue.popleft()
        for nbr in adjacency[current]:
            if nbr in parent:
                continue
            parent[nbr] = current
            if nbr == goal:
                path = [goal]
                while parent[path[-1]] is not None:
                    path.append(parent[path[-1]])
                path.reverse()
                return path
            queue.append(nbr)

    return None


def main() -> None:
    family = ParallelLineFamily(name="parallel_lines")
    lambdas = [-2.0, -1.0, 0.0, 1.0, 2.0]

    start_lambda = -1.0
    goal_lambda = 1.0

    start_point = np.array([-3.0, start_lambda])
    goal_point = np.array([3.0, goal_lambda])

    print("=== Leaf-family switching concept experiment ===")
    print("Sampled leaves:", lambdas)
    print(f"Start leaf: lambda={start_lambda}")
    print(f"Goal  leaf: lambda={goal_lambda}")

    # ------------------------------------------------------------
    # Case 1: fixed-leaf planning only
    # ------------------------------------------------------------
    same_leaf_possible = (start_lambda == goal_lambda)

    print("\nCase 1: fixed-leaf planning only")
    if same_leaf_possible:
        print("  Start and goal are on the same leaf: reachable.")
    else:
        print("  Start and goal are on different leaves: unreachable if switching is forbidden.")

    # ------------------------------------------------------------
    # Case 2: discrete switching between sampled neighboring leaves
    # ------------------------------------------------------------
    node_names = [f"lambda_{lam:g}" for lam in lambdas]

    adjacency = {name: [] for name in node_names}
    for i in range(len(node_names) - 1):
        a = node_names[i]
        b = node_names[i + 1]
        adjacency[a].append(b)
        adjacency[b].append(a)

    start_node = f"lambda_{start_lambda:g}"
    goal_node = f"lambda_{goal_lambda:g}"

    route = bfs_path(adjacency, start_node, goal_node)

    print("\nCase 2: sampled-leaf switching allowed")
    print("  Adjacency:")
    for k, v in adjacency.items():
        print(f"    {k} -> {v}")

    if route is None:
        print("  No discrete leaf route found.")
    else:
        print(f"  Discrete leaf route found: {route}")

    # ------------------------------------------------------------
    # Plot
    # ------------------------------------------------------------
    fig, ax = plt.subplots(figsize=(9, 6))

    xs = np.linspace(-4.0, 4.0, 200)
    for lam in lambdas:
        ys = np.full_like(xs, lam)
        ax.plot(xs, ys, label=f"leaf y={lam:g}")

    ax.scatter([start_point[0]], [start_point[1]], s=100, marker="o", label="start")
    ax.scatter([goal_point[0]], [goal_point[1]], s=120, marker="*", label="goal")

    # Draw conceptual switching route as vertical dashed connectors
    if route is not None:
        route_lambdas = [float(name.split("_")[1]) for name in route]

        # show conceptual vertical "switches" near x = 0
        x_switch = 0.0
        for i in range(len(route_lambdas) - 1):
            y0 = route_lambdas[i]
            y1 = route_lambdas[i + 1]
            ax.plot([x_switch, x_switch], [y0, y1], linestyle="--", linewidth=2)

        # also draw horizontal movement on first and last leaf conceptually
        ax.plot([start_point[0], x_switch], [start_point[1], start_point[1]], linestyle=":")
        ax.plot([x_switch, goal_point[0]], [goal_point[1], goal_point[1]], linestyle=":")

    finalize_2d_axes(
        ax,
        title="Leaf-family concept: fixed leaf vs switching across sampled leaves",
    )

    out_path = "example_10_leaf_family_switching_concept.png"
    plt.savefig(out_path, dpi=200, bbox_inches="tight")
    print(f"\nSaved figure to: {out_path}")

    plt.show(block=True)


if __name__ == "__main__":
    main()