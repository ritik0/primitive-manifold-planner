from __future__ import annotations

from dataclasses import dataclass
from typing import List
import numpy as np
import matplotlib.pyplot as plt

from primitive_manifold_planner.families.leaf_state import LeafState
from primitive_manifold_planner.planners.component_leaf_graph import (
    build_component_leaf_graph,
    shortest_component_route,
)
from primitive_manifold_planner.planners.realize_component_leaf_route import (
    realize_component_route,
)
from primitive_manifold_planner.projection import project_newton

from primitive_manifold_planner.examplesupport.planar2link import (
    Planar2LinkKinematics,
    component_of_q,
    wrap_q,
    torus_distance,
)
from primitive_manifold_planner.examplesupport.planar2link_families import (
    EndEffectorXFamily,
    EndEffectorYFamily,
    Joint2Family,
)
from primitive_manifold_planner.examplesupport.planar2link_helpers import (
    make_seed_points_fn,
    component_ids_for_family,
    compatible_components_for_leaf,
    allowed_switch_pair,
)


@dataclass
class BenchmarkRow:
    case_name: str
    planner_name: str
    route_found: bool
    realization_success: bool
    route_string: str
    num_edges: int
    path_length: float
    message: str


FORBIDDEN_CENTER = np.array([2.09,.0], dtype=float)
FORBIDDEN_RADIUS = 0.55


def in_forbidden_region(q: np.ndarray) -> bool:
    return torus_distance(q, FORBIDDEN_CENTER) <= FORBIDDEN_RADIUS


def component_edge_cost_nominal(edge) -> float:
    return 1.0 + float(edge.score)


def component_edge_cost_forbidden(edge) -> float:
    cost = 1.0 + float(edge.score)
    if in_forbidden_region(edge.transition_point):
        cost += 1000.0
    return cost


def total_path_length_from_steps(steps) -> float:
    total = 0.0
    for step in steps:
        path = np.asarray(step.path)
        if len(path) >= 2:
            total += float(np.sum(np.linalg.norm(np.diff(path, axis=0), axis=1)))
    return total


def build_cases():
    return [
        ("up_to_up", np.array([0.5 * np.pi, 0.5 * np.pi]), np.array([0.0, 0.5 * np.pi])),
        ("up_to_down", np.array([0.5 * np.pi, 0.5 * np.pi]), np.array([0.0, -0.5 * np.pi])),
        ("down_to_down", np.array([-0.5 * np.pi, -0.5 * np.pi]), np.array([0.0, -0.5 * np.pi])),
        ("down_to_up", np.array([-0.5 * np.pi, -0.5 * np.pi]), np.array([0.0, 0.5 * np.pi])),
    ]


def build_switch_families(robot: Planar2LinkKinematics):
    return [
        EndEffectorXFamily("left_x_family", robot, [-1.00]),
        Joint2Family("switch_q2_family", [0.0]),
        EndEffectorYFamily("bridge_y_family", robot, [-1.00, 1.00]),
        EndEffectorXFamily("right_x_family", robot, [1.00]),
    ]


def run_benchmark() -> List[BenchmarkRow]:
    np.random.seed(7)

    robot = Planar2LinkKinematics(l1=1.0, l2=1.0)
    seed_points_fn = make_seed_points_fn(robot)
    families = build_switch_families(robot)

    rows: List[BenchmarkRow] = []

    for case_name, start_q_raw, goal_q_raw in build_cases():
        start_q = wrap_q(start_q_raw)
        goal_q = wrap_q(goal_q_raw)

        start_state = LeafState("left_x_family", -1.0, start_q.copy())
        start_comp = component_of_q(start_q)
        goal_comp = component_of_q(goal_q)

        graph = build_component_leaf_graph(
            families=families,
            project_newton=project_newton,
            seed_points_fn=seed_points_fn,
            goal_point=goal_q.copy(),
            component_ids_for_family_fn=component_ids_for_family,
            compatible_components_fn=compatible_components_for_leaf,
            allowed_family_pair_fn=allowed_switch_pair,
            max_candidates_per_pair=6,
        )

        # ----------------------------------------------------
        # Nominal aware+switch
        # ----------------------------------------------------
        nominal_route = shortest_component_route(
            graph=graph,
            start=("left_x_family", -1.0, start_comp),
            goal=("right_x_family", 1.0, goal_comp),
            edge_cost_fn=component_edge_cost_nominal,
        )

        if nominal_route is None:
            rows.append(
                BenchmarkRow(
                    case_name=case_name,
                    planner_name="aware+switch",
                    route_found=False,
                    realization_success=False,
                    route_string="",
                    num_edges=0,
                    path_length=0.0,
                    message="No route found.",
                )
            )
        else:
            route_string = " -> ".join(
                [f"left_x_family[-1.0|{start_comp}]"] +
                [f"{e.dst[0]}[{e.dst[1]}|{e.dst[2]}]" for e in nominal_route]
            )
            realized = realize_component_route(
                graph=graph,
                start_state=start_state,
                start_component=start_comp,
                goal_q=goal_q.copy(),
                families=families,
                route_edges=nominal_route,
                step_size=0.08,
                local_planner_name="projection",
                local_planner_kwargs=dict(
                    goal_tol=1e-3,
                    max_iters=1200,
                    projection_tol=1e-10,
                    projection_max_iters=50,
                    projection_damping=1.0,
                ),
                wrap_state_fn=wrap_q,
                state_distance_fn=torus_distance,
            )
            rows.append(
                BenchmarkRow(
                    case_name=case_name,
                    planner_name="aware+switch",
                    route_found=True,
                    realization_success=bool(realized.success),
                    route_string=route_string,
                    num_edges=len(nominal_route),
                    path_length=total_path_length_from_steps(realized.steps) if realized.success else 0.0,
                    message=realized.message,
                )
            )

        # ----------------------------------------------------
        # Aware+switch with forbidden-region penalty
        # ----------------------------------------------------
        forbidden_route = shortest_component_route(
            graph=graph,
            start=("left_x_family", -1.0, start_comp),
            goal=("right_x_family", 1.0, goal_comp),
            edge_cost_fn=component_edge_cost_forbidden,
        )

        if forbidden_route is None:
            rows.append(
                BenchmarkRow(
                    case_name=case_name,
                    planner_name="aware+switch+forbidden",
                    route_found=False,
                    realization_success=False,
                    route_string="",
                    num_edges=0,
                    path_length=0.0,
                    message="No route found.",
                )
            )
        else:
            route_string = " -> ".join(
                [f"left_x_family[-1.0|{start_comp}]"] +
                [f"{e.dst[0]}[{e.dst[1]}|{e.dst[2]}]" for e in forbidden_route]
            )
            realized = realize_component_route(
                graph=graph,
                start_state=start_state,
                start_component=start_comp,
                goal_q=goal_q.copy(),
                families=families,
                route_edges=forbidden_route,
                step_size=0.08,
                local_planner_name="projection",
                local_planner_kwargs=dict(
                    goal_tol=1e-3,
                    max_iters=1200,
                    projection_tol=1e-10,
                    projection_max_iters=50,
                    projection_damping=1.0,
                ),
                wrap_state_fn=wrap_q,
                state_distance_fn=torus_distance,
            )
            rows.append(
                BenchmarkRow(
                    case_name=case_name,
                    planner_name="aware+switch+forbidden",
                    route_found=True,
                    realization_success=bool(realized.success),
                    route_string=route_string,
                    num_edges=len(forbidden_route),
                    path_length=total_path_length_from_steps(realized.steps) if realized.success else 0.0,
                    message=realized.message,
                )
            )

    return rows


def main():
    rows = run_benchmark()

    case_order = ["up_to_up", "up_to_down", "down_to_down", "down_to_up"]
    planner_order = ["aware+switch", "aware+switch+forbidden"]

    print("\nExample 47: forbidden-region benchmark\n")
    print(f"Forbidden center = {np.round(FORBIDDEN_CENTER, 4)}")
    print(f"Forbidden radius = {FORBIDDEN_RADIUS:.3f}\n")

    for r in rows:
        print(
            f"{r.case_name:12s} | {r.planner_name:23s} | "
            f"route={str(r.route_found):5s} | "
            f"realized={str(r.realization_success):5s} | "
            f"edges={r.num_edges:d} | "
            f"length={r.path_length:7.4f} | "
            f"{r.message}"
        )
        if r.route_string:
            print(f"  route: {r.route_string}")

    # ------------------------------------------
    # Plot path lengths
    # ------------------------------------------
    fig, axes = plt.subplots(1, 2, figsize=(14, 5))

    # left: path length comparison
    ax = axes[0]
    x = np.arange(len(case_order))
    width = 0.35

    for k, planner in enumerate(planner_order):
        vals = []
        for case in case_order:
            row = next(r for r in rows if r.case_name == case and r.planner_name == planner)
            vals.append(row.path_length if row.realization_success else np.nan)
        vals = np.asarray(vals, dtype=float)

        ax.bar(x + (k - 0.5) * width, np.nan_to_num(vals, nan=0.0), width=width, label=planner)

        for idx, v in enumerate(vals):
            if np.isfinite(v):
                ax.text(
                    x[idx] + (k - 0.5) * width,
                    v + 0.15,
                    f"{v:.2f}",
                    ha="center",
                    va="bottom",
                    fontsize=9,
                )

    ax.set_xticks(x)
    ax.set_xticklabels(case_order)
    ax.set_ylabel("Path length")
    ax.set_title("Path lengths with and without forbidden-region penalty")
    ax.legend()

    # right: success matrix
    ax = axes[1]
    mat = np.zeros((len(case_order), len(planner_order)), dtype=int)
    for i, case in enumerate(case_order):
        for j, planner in enumerate(planner_order):
            row = next(r for r in rows if r.case_name == case and r.planner_name == planner)
            mat[i, j] = 1 if row.realization_success else 0

    im = ax.imshow(mat, aspect="auto", vmin=0, vmax=1)
    ax.set_xticks(np.arange(len(planner_order)))
    ax.set_xticklabels(planner_order, rotation=10)
    ax.set_yticks(np.arange(len(case_order)))
    ax.set_yticklabels(case_order)
    ax.set_title("Successful realization")

    for i in range(mat.shape[0]):
        for j in range(mat.shape[1]):
            ax.text(
                j, i, "yes" if mat[i, j] == 1 else "no",
                ha="center", va="center"
            )

    plt.tight_layout()
    plt.show()


if __name__ == "__main__":
    main()