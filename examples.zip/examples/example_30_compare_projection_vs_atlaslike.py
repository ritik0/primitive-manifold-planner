from __future__ import annotations

from dataclasses import dataclass
from typing import List, Dict, Tuple
import math
import numpy as np
import matplotlib.pyplot as plt

from primitive_manifold_planner.families.leaf_state import LeafState
from primitive_manifold_planner.manifolds import (
    LineManifold,
    CircleManifold,
    EllipseManifold,
)
from primitive_manifold_planner.planners.plan_foliated_route import plan_foliated_route
from primitive_manifold_planner.projection import project_newton


# ============================================================
# Benchmark family adapters
# Thin benchmark-side wrappers only.
# Planning logic stays in the package.
# ============================================================

class BenchmarkLeafFamily:
    def __init__(self, name: str, lambdas: List[float]):
        self.name = name
        self._lambdas = [float(l) for l in lambdas]

    def manifold(self, lam: float):
        raise NotImplementedError

    def sample_lambdas(self, context=None):
        return list(self._lambdas)


class VerticalLineFamily(BenchmarkLeafFamily):
    def manifold(self, lam: float):
        return LineManifold(
            point=np.array([float(lam), 0.0]),
            normal=np.array([1.0, 0.0]),
            name=f"{self.name}_lambda_{lam:g}",
        )


class HorizontalLineFamily(BenchmarkLeafFamily):
    def manifold(self, lam: float):
        return LineManifold(
            point=np.array([0.0, float(lam)]),
            normal=np.array([0.0, 1.0]),
            name=f"{self.name}_lambda_{lam:g}",
        )


class CircleFamilyAdapter(BenchmarkLeafFamily):
    def __init__(self, name: str, center: np.ndarray, lambdas: List[float]):
        super().__init__(name=name, lambdas=lambdas)
        self.center = np.asarray(center, dtype=float)

    def manifold(self, lam: float):
        return CircleManifold(
            center=self.center.copy(),
            radius=float(lam),
            name=f"{self.name}_lambda_{lam:g}",
        )


class EllipseFamilyAdapter(BenchmarkLeafFamily):
    """
    Axis-aligned ellipse family.
    To stay compatible with your current EllipseManifold, we keep it axis-aligned.
    """
    def __init__(self, name: str, center: np.ndarray, a_scales: Dict[float, float], b_scales: Dict[float, float]):
        super().__init__(name=name, lambdas=list(a_scales.keys()))
        self.center = np.asarray(center, dtype=float)
        self.a_scales = {float(k): float(v) for k, v in a_scales.items()}
        self.b_scales = {float(k): float(v) for k, v in b_scales.items()}

    def manifold(self, lam: float):
        lam = float(lam)
        return EllipseManifold(
            center=self.center.copy(),
            a=self.a_scales[lam],
            b=self.b_scales[lam],
            name=f"{self.name}_lambda_{lam:g}",
        )


# ============================================================
# Benchmark definition
# ============================================================

@dataclass
class BenchmarkCase:
    start_family_name: str
    start_lam: float
    start_point: np.ndarray
    goal_family_name: str
    goal_lam: float
    goal_point: np.ndarray
    title: str


def build_benchmark():
    families = [
        VerticalLineFamily(
            name="start_line",
            lambdas=[-2.20, -1.80, -1.40],
        ),
        CircleFamilyAdapter(
            name="left_circle",
            center=np.array([-0.60, 0.10]),
            lambdas=[1.15, 1.45, 1.75],
        ),
        EllipseFamilyAdapter(
            name="mid_ellipse",
            center=np.array([0.35, 0.95]),
            a_scales={
                0.90: 1.00,
                1.10: 1.25,
                1.30: 1.50,
            },
            b_scales={
                0.90: 0.55,
                1.10: 0.72,
                1.30: 0.88,
            },
        ),
        CircleFamilyAdapter(
            name="right_circle",
            center=np.array([1.55, 1.05]),
            lambdas=[0.95, 1.25, 1.55],
        ),
        HorizontalLineFamily(
            name="goal_line",
            lambdas=[0.90, 1.35, 1.80],
        ),
    ]

    cases = [
        BenchmarkCase(
            start_family_name="start_line",
            start_lam=-1.80,
            start_point=np.array([-1.80, -1.85]),
            goal_family_name="goal_line",
            goal_lam=1.35,
            goal_point=np.array([2.60, 1.35]),
            title="Case 0: mid-height goal",
        ),
        BenchmarkCase(
            start_family_name="start_line",
            start_lam=-2.20,
            start_point=np.array([-2.20, -1.20]),
            goal_family_name="goal_line",
            goal_lam=1.80,
            goal_point=np.array([2.95, 1.80]),
            title="Case 1: higher goal",
        ),
        BenchmarkCase(
            start_family_name="start_line",
            start_lam=-1.40,
            start_point=np.array([-1.40, 0.15]),
            goal_family_name="goal_line",
            goal_lam=0.90,
            goal_point=np.array([2.20, 0.90]),
            title="Case 2: lower goal",
        ),
    ]

    return families, cases


# ============================================================
# Utilities
# ============================================================

def get_family_map(families):
    return {f.name: f for f in families}


def plot_manifold(ax, manifold, color="lightgray", lw=1.2, alpha=0.35):
    if isinstance(manifold, LineManifold):
        p = manifold.point
        n = manifold.normal
        t = np.array([-n[1], n[0]], dtype=float)
        s = np.linspace(-4.5, 4.5, 300)
        pts = p[None, :] + s[:, None] * t[None, :]
        ax.plot(pts[:, 0], pts[:, 1], color=color, lw=lw, alpha=alpha)

    elif isinstance(manifold, CircleManifold):
        th = np.linspace(0.0, 2.0 * np.pi, 300)
        pts = np.column_stack([
            manifold.center[0] + manifold.radius * np.cos(th),
            manifold.center[1] + manifold.radius * np.sin(th),
        ])
        ax.plot(pts[:, 0], pts[:, 1], color=color, lw=lw, alpha=alpha)

    elif isinstance(manifold, EllipseManifold):
        th = np.linspace(0.0, 2.0 * np.pi, 300)
        pts = np.array([manifold.point_from_angle(t) for t in th])
        ax.plot(pts[:, 0], pts[:, 1], color=color, lw=lw, alpha=alpha)


def plot_all_families(ax, families):
    for fam in families:
        for lam in fam.sample_lambdas():
            plot_manifold(ax, fam.manifold(lam))


def total_path_length_from_steps(steps) -> float:
    total = 0.0
    for step in steps:
        path = np.asarray(step.path)
        if len(path) >= 2:
            total += float(np.sum(np.linalg.norm(np.diff(path, axis=0), axis=1)))
    return total


def total_chart_count_from_steps(steps) -> int:
    return int(sum(getattr(step, "chart_count", 0) for step in steps))


def concatenate_steps(steps) -> np.ndarray:
    pts = []
    for i, step in enumerate(steps):
        path = np.asarray(step.path)
        if len(path) == 0:
            continue
        if i == 0:
            pts.extend(list(path))
        else:
            pts.extend(list(path[1:]))
    if not pts:
        return np.zeros((0, 2))
    return np.asarray(pts)


def print_plan_summary(label: str, result):
    print(f"\n=== {label} ===")
    print(f"success      : {result.success}")
    print(f"message      : {result.message}")
    print(f"num steps    : {len(result.steps)}")
    print(f"path length  : {total_path_length_from_steps(result.steps):.4f}")
    print(f"chart count  : {total_chart_count_from_steps(result.steps)}")

    for i, step in enumerate(result.steps):
        step_path = np.asarray(step.path)
        path_len = 0.0
        if len(step_path) >= 2:
            path_len = float(np.sum(np.linalg.norm(np.diff(step_path, axis=0), axis=1)))
        print(
            f"  step {i:02d} | kind={step.kind:>6s} | "
            f"family={step.family_name}[{step.lam}] | "
            f"planner={getattr(step, 'planner_name', 'unknown')} | "
            f"charts={getattr(step, 'chart_count', 0)} | "
            f"len={path_len:.4f}"
        )


# ============================================================
# Main comparison
# ============================================================

def main():
    np.random.seed(7)

    families, cases = build_benchmark()
    family_map = get_family_map(families)

    # Change this to 0, 1, or 2
    case_id = 2
    case = cases[case_id]

    start_state = LeafState(
        family_name=case.start_family_name,
        lam=case.start_lam,
        x=case.start_point.copy(),
    )
    goal_family = family_map[case.goal_family_name]
    goal_lam = case.goal_lam
    goal_point = case.goal_point.copy()

    common_kwargs = dict(
        start_state=start_state,
        goal_point=goal_point,
        goal_family=goal_family,
        goal_lam=goal_lam,
        families=families,
        project_newton=project_newton,
        max_switches=3,
        local_step_size=0.08,
        progress_tol=1e-4,
    )

    result_projection = plan_foliated_route(
        **common_kwargs,
        local_planner_name="projection",
        local_planner_kwargs=dict(
            goal_tol=1e-3,
            max_iters=500,
            projection_tol=1e-10,
            projection_max_iters=50,
            projection_damping=1.0,
        ),
    )

    result_atlas = plan_foliated_route(
        **common_kwargs,
        local_planner_name="atlas_like",
        local_planner_kwargs=dict(
            goal_tol=1e-3,
            max_iters=500,
            projection_tol=1e-10,
            projection_max_iters=50,
            projection_damping=1.0,
            preview_fraction=0.5,
            min_progress_tol=1e-10,
            max_step_growth=2.5,
        ),
    )

    print(f"\nRunning {case.title}")
    print(f"start = {case.start_family_name}[{case.start_lam}] at {case.start_point}")
    print(f"goal  = {case.goal_family_name}[{case.goal_lam}] at {case.goal_point}")

    print_plan_summary("Projection", result_projection)
    print_plan_summary("Atlas-like", result_atlas)

    fig, ax = plt.subplots(figsize=(10, 8))
    plot_all_families(ax, families)

    proj_pts = concatenate_steps(result_projection.steps)
    atlas_pts = concatenate_steps(result_atlas.steps)

    if len(proj_pts) > 0:
        ax.plot(
            proj_pts[:, 0],
            proj_pts[:, 1],
            color="tab:red",
            lw=3.0,
            label="projection",
        )

    if len(atlas_pts) > 0:
        ax.plot(
            atlas_pts[:, 0],
            atlas_pts[:, 1],
            color="tab:blue",
            lw=3.0,
            ls="--",
            label="atlas_like",
        )

    ax.scatter(case.start_point[0], case.start_point[1], s=90, marker="s", color="black", label="start")
    ax.scatter(case.goal_point[0], case.goal_point[1], s=140, marker="*", color="gold", edgecolor="black", label="goal")

    ax.set_title(f"Example 30: projection vs atlas-like\n{case.title}")
    ax.set_aspect("equal")
    ax.grid(True, alpha=0.25)
    ax.legend()
    plt.tight_layout()
    plt.show()


if __name__ == "__main__":
    main()