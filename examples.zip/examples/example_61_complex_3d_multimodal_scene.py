from __future__ import annotations

import numpy as np
import matplotlib.pyplot as plt

from primitive_manifold_planner.families.leaf_state import LeafState
from primitive_manifold_planner.families.standard import PlaneFamily, SphereFamily
from primitive_manifold_planner.manifolds import PlaneManifold, SphereManifold
from primitive_manifold_planner.planners.component_discovery import ComponentModelRegistry
from primitive_manifold_planner.planners.mode_semantics import PlanningSemanticContext
from primitive_manifold_planner.planners.multimodal_component_planner import (
    MultimodalComponentPlanner,
    PlannerConfig,
)
from primitive_manifold_planner.planners.semantic_templates import (
    build_support_transfer_goal_semantic_model,
)
from primitive_manifold_planner.projection import project_newton
from primitive_manifold_planner.visualization import (
    add_manifold,
    add_path,
    add_points,
    add_transition_markers,
    pyvista_available,
)

try:
    import pyvista as pv
except Exception:
    pv = None


def sphere_point(center: np.ndarray, radius: float, azimuth_deg: float, elevation_deg: float) -> np.ndarray:
    az = np.deg2rad(float(azimuth_deg))
    el = np.deg2rad(float(elevation_deg))
    direction = np.array(
        [
            np.cos(el) * np.cos(az),
            np.cos(el) * np.sin(az),
            np.sin(el),
        ],
        dtype=float,
    )
    return np.asarray(center, dtype=float) + float(radius) * direction


def build_scene():
    left_support = SphereFamily(
        name="left_support_3d",
        center=np.array([-2.10, -0.45, 0.50], dtype=float),
        radii={1.05: 1.05},
    )
    center_support = SphereFamily(
        name="center_support_3d",
        center=np.array([0.0, 0.0, 0.60], dtype=float),
        radii={1.10: 1.10},
    )
    right_support = SphereFamily(
        name="right_support_3d",
        center=np.array([2.10, 0.45, 0.50], dtype=float),
        radii={1.05: 1.05},
    )

    left_low_transfer = PlaneFamily(
        name="left_low_transfer_3d",
        base_point=np.array([0.0, 0.0, 0.0], dtype=float),
        normal=np.array([0.0, 0.0, 1.0], dtype=float),
        offsets=[-0.08],
        anchor_span=1.1,
    )
    left_high_transfer = PlaneFamily(
        name="left_high_transfer_3d",
        base_point=np.array([0.0, 0.0, 0.0], dtype=float),
        normal=np.array([0.0, 0.0, 1.0], dtype=float),
        offsets=[0.26],
        anchor_span=1.1,
    )
    right_low_transfer = PlaneFamily(
        name="right_low_transfer_3d",
        base_point=np.array([0.0, 0.0, 0.0], dtype=float),
        normal=np.array([0.0, 0.0, 1.0], dtype=float),
        offsets=[-0.02],
        anchor_span=1.1,
    )
    right_high_transfer = PlaneFamily(
        name="right_high_transfer_3d",
        base_point=np.array([0.0, 0.0, 0.0], dtype=float),
        normal=np.array([0.0, 0.0, 1.0], dtype=float),
        offsets=[0.30],
        anchor_span=1.1,
    )

    families = [
        left_support,
        left_low_transfer,
        left_high_transfer,
        center_support,
        right_low_transfer,
        right_high_transfer,
        right_support,
    ]

    start_q = sphere_point(left_support.center, 1.05, azimuth_deg=-35.0, elevation_deg=-30.0)
    goal_q = sphere_point(right_support.center, 1.05, azimuth_deg=205.0, elevation_deg=-32.0)

    return families, start_q, goal_q


def build_component_registry(families):
    registry = ComponentModelRegistry()
    for fam in families:
        for lam in fam.sample_lambdas():
            registry.register_static_components(fam.name, float(lam), component_ids=["0"])
    return registry


def build_semantic_model():
    def semantic_feasibility(context: PlanningSemanticContext) -> bool:
        if context.point is None:
            return True
        q = np.asarray(context.point, dtype=float)
        fams = {context.source_family_name, context.target_family_name}

        if {"left_low_transfer_3d", "left_high_transfer_3d"} & fams:
            return bool(-1.90 <= float(q[0]) <= 0.45 and -1.05 <= float(q[1]) <= 0.55)
        if {"right_low_transfer_3d", "right_high_transfer_3d"} & fams:
            return bool(-0.45 <= float(q[0]) <= 1.90 and -0.55 <= float(q[1]) <= 1.05)
        return True

    def semantic_admissibility(context: PlanningSemanticContext) -> float:
        if context.point is None:
            return 0.0
        q = np.asarray(context.point, dtype=float)
        goal = None if context.goal_point is None else np.asarray(context.goal_point, dtype=float)
        fams = {context.source_family_name, context.target_family_name}

        cost = 0.0
        if "left_high_transfer_3d" in fams:
            cost += 0.30
        if "right_low_transfer_3d" in fams:
            cost += 0.30
        if goal is not None:
            cost += 0.03 * float(np.linalg.norm(q - goal))
        return float(cost)

    return build_support_transfer_goal_semantic_model(
        support_families=["left_support_3d", "center_support_3d"],
        transfer_families=[
            "left_low_transfer_3d",
            "left_high_transfer_3d",
            "right_low_transfer_3d",
            "right_high_transfer_3d",
        ],
        goal_support_families=["right_support_3d"],
        transition_feasibility_fn=semantic_feasibility,
        transition_admissibility_fn=semantic_admissibility,
    )


def seed_points_fn(source_family, source_lam, target_family, target_lam):
    src = list(source_family.transition_seed_anchors(source_lam))
    dst = list(target_family.transition_seed_anchors(target_lam))
    return [np.asarray(p, dtype=float).copy() for p in src + dst]


def plot_manifold(ax, manifold, color="lightgray", alpha=0.14):
    if isinstance(manifold, SphereManifold):
        u = np.linspace(0.0, 2.0 * np.pi, 36)
        v = np.linspace(0.0, np.pi, 20)
        x = manifold.center[0] + manifold.radius * np.outer(np.cos(u), np.sin(v))
        y = manifold.center[1] + manifold.radius * np.outer(np.sin(u), np.sin(v))
        z = manifold.center[2] + manifold.radius * np.outer(np.ones_like(u), np.cos(v))
        ax.plot_wireframe(x, y, z, color=color, alpha=alpha, rstride=2, cstride=2, linewidth=0.6)
    elif isinstance(manifold, PlaneManifold):
        xx = np.linspace(-2.0, 2.0, 18)
        yy = np.linspace(-1.1, 1.1, 12)
        X, Y = np.meshgrid(xx, yy)
        Z = np.zeros_like(X) + manifold.point[2]
        ax.plot_surface(X, Y, Z, color=color, alpha=alpha, linewidth=0.0, shade=False)


def plot_used_manifold(ax, manifold, color, family_name: str):
    label_pos = np.zeros((3,), dtype=float)
    if isinstance(manifold, SphereManifold):
        u = np.linspace(0.0, 2.0 * np.pi, 32)
        v = np.linspace(0.0, np.pi, 18)
        x = manifold.center[0] + manifold.radius * np.outer(np.cos(u), np.sin(v))
        y = manifold.center[1] + manifold.radius * np.outer(np.sin(u), np.sin(v))
        z = manifold.center[2] + manifold.radius * np.outer(np.ones_like(u), np.cos(v))
        ax.plot_wireframe(x, y, z, color=color, alpha=0.20, rstride=2, cstride=2, linewidth=0.8)
        label_pos = manifold.center + np.array([0.0, 0.0, manifold.radius + 0.08], dtype=float)
    elif isinstance(manifold, PlaneManifold):
        xx = np.linspace(-2.0, 2.0, 18)
        yy = np.linspace(-1.1, 1.1, 12)
        X, Y = np.meshgrid(xx, yy)
        Z = np.zeros_like(X) + manifold.point[2]
        ax.plot_surface(X, Y, Z, color=color, alpha=0.16, linewidth=0.0, shade=False)
        label_pos = manifold.point + np.array([0.0, 0.0, 0.08], dtype=float)
    ax.text(
        float(label_pos[0]),
        float(label_pos[1]),
        float(label_pos[2]),
        family_name,
        fontsize=9,
        color=color,
    )


def concatenate_realization(realization):
    pts = []
    for i, step in enumerate(realization.steps):
        path = np.asarray(step.path)
        if len(path) == 0:
            continue
        if i == 0:
            pts.extend(list(path))
        else:
            pts.extend(list(path[1:]))
    if not pts:
        return np.zeros((0, 3))
    return np.asarray(pts)


def selected_transfer_families(realization):
    families = []
    for step in realization.steps:
        if "transfer" in step.family_name and (not families or families[-1] != step.family_name):
            families.append(step.family_name)
    return families


def used_leaf_sequence(realization):
    seq = []
    for step in realization.steps:
        key = (step.family_name, float(step.lam))
        if not seq or seq[-1] != key:
            seq.append(key)
    return seq


def plot_realization_segments(ax, realization, color_map):
    for step in realization.steps:
        path = np.asarray(step.path)
        if len(path) == 0:
            continue
        color = color_map.get(step.family_name, "#1565c0")
        ax.plot(
            path[:, 0],
            path[:, 1],
            path[:, 2],
            color=color,
            linewidth=3.0,
        )
        if step.transition_point is not None:
            tp = np.asarray(step.transition_point, dtype=float)
            ax.scatter(tp[0], tp[1], tp[2], s=65, marker="x", color="black")


def show_pyvista_views(families, colors, result, start_q: np.ndarray, goal_q: np.ndarray):
    if pv is None:
        return False

    transition_points = []
    if result.realization is not None and result.realization.success:
        transition_points = [
            np.asarray(step.transition_point, dtype=float)
            for step in result.realization.steps
            if step.transition_point is not None
        ]

    plotter = pv.Plotter(window_size=(1200, 780))
    plotter.add_text("Complex 3D Multimodal Scene", font_size=12)
    for fam in families:
        for lam in fam.sample_lambdas():
            add_manifold(plotter, fam.manifold(lam), color=colors.get(fam.name, "#999999"), opacity=0.12)
    if result.realization is not None and result.realization.success:
        for step in result.realization.steps:
            step_path = np.asarray(step.path)
            if len(step_path) < 2:
                continue
            add_path(plotter, step_path, color=colors.get(step.family_name, "#1565c0"), width=7.0)
        add_transition_markers(plotter, transition_points, color="black", size=12.0)
    add_points(plotter, start_q, color="black", size=16.0, label="start")
    add_points(plotter, goal_q, color="gold", size=18.0, label="goal")
    plotter.add_axes()
    plotter.show_grid()
    plotter.show()
    return True


def main():
    np.random.seed(29)

    families, start_q, goal_q = build_scene()
    registry = build_component_registry(families)
    semantic_model = build_semantic_model()

    planner = MultimodalComponentPlanner(
        families=families,
        project_newton=project_newton,
        seed_points_fn=seed_points_fn,
        component_model_registry=registry,
        config=PlannerConfig(
            semantic_model=semantic_model,
            local_planner_name="projection",
            local_planner_kwargs=dict(
                goal_tol=1e-3,
                max_iters=1000,
                projection_tol=1e-10,
                projection_max_iters=60,
                projection_damping=1.0,
            ),
            step_size=0.10,
            max_candidates_per_pair=10,
        ),
    )

    result = planner.plan_with_inferred_components(
        start_state=LeafState("left_support_3d", 1.05, start_q.copy()),
        goal_family_name="right_support_3d",
        goal_lam=1.05,
        goal_q=goal_q.copy(),
    )

    print("\nRunning complex 3D multimodal scene")
    print(f"route_found = {result.route_found}")
    print(f"realization_success = {result.realization_success}")
    print(f"message = {result.message}")
    print(f"route = {result.diagnostics.selected_route_string}")
    print(f"route base score = {result.diagnostics.selected_route_base_score:.4f}")
    print(f"route admissibility cost = {result.diagnostics.selected_route_admissibility_cost:.4f}")
    print(f"route total edge cost = {result.diagnostics.selected_route_total_edge_cost:.4f}")

    colors = {
        "left_support_3d": "#c58b4c",
        "center_support_3d": "#c58b4c",
        "right_support_3d": "#c58b4c",
        "left_low_transfer_3d": "#7fa7c6",
        "left_high_transfer_3d": "#9fb7d0",
        "right_low_transfer_3d": "#7fa7c6",
        "right_high_transfer_3d": "#9fb7d0",
    }
    chosen = []
    if result.realization is not None and result.realization.success:
        chosen = selected_transfer_families(result.realization)
        print(f"selected transfer families = {chosen}")

    if pyvista_available():
        shown = show_pyvista_views(
            families=families,
            colors=colors,
            result=result,
            start_q=start_q,
            goal_q=goal_q,
        )
        if shown:
            return

    fig = plt.figure(figsize=(11, 8))
    ax = fig.add_subplot(111, projection="3d")

    for fam in families:
        for lam in fam.sample_lambdas():
            plot_manifold(ax, fam.manifold(lam), color=colors.get(fam.name, "#999999"), alpha=0.12)

    if result.realization is not None and result.realization.success:
        plot_realization_segments(ax, result.realization, colors)

    ax.scatter(start_q[0], start_q[1], start_q[2], s=90, marker="s", color="black", label="start")
    ax.scatter(goal_q[0], goal_q[1], goal_q[2], s=130, marker="*", color="gold", edgecolor="black", label="goal")
    ax.set_xlabel("x")
    ax.set_ylabel("y")
    ax.set_zlabel("z")
    ax.set_title("Example 61: complex 3D multimodal scene")
    ax.view_init(elev=24, azim=-58)
    plt.tight_layout()
    plt.show()


if __name__ == "__main__":
    main()
