from __future__ import annotations

from dataclasses import dataclass
from typing import List, Optional, Tuple
import numpy as np
import matplotlib.pyplot as plt

from primitive_manifold_planner.families.leaf_state import LeafState
from primitive_manifold_planner.planners.leaf_graph import (
    build_leaf_graph,
    shortest_leaf_route,
)
from primitive_manifold_planner.planners.realize_leaf_route import realize_leaf_route
from primitive_manifold_planner.projection import project_newton


# ============================================================
# Minimal leaf-RRT implementation kept local to this example
# ============================================================

@dataclass
class LeafRRTNode:
    x: np.ndarray
    parent: Optional[int] = None


@dataclass
class LeafRRTResult:
    success: bool
    path: np.ndarray
    message: str
    nodes: List[LeafRRTNode]


def _backtrack_path(nodes: List[LeafRRTNode], idx: int) -> np.ndarray:
    pts = []
    cur = idx
    while cur is not None:
        pts.append(nodes[cur].x.copy())
        cur = nodes[cur].parent
    pts.reverse()
    return np.asarray(pts)


def _concat_paths(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    if len(a) == 0:
        return np.asarray(b)
    if len(b) == 0:
        return np.asarray(a)
    return np.vstack([a, b[1:]])


def _run_local_planner(
    manifold,
    x_start,
    x_goal,
    step_size,
    local_planner_name,
    local_planner_kwargs,
):
    from primitive_manifold_planner.planning.local import run_local_planner
    return run_local_planner(
        manifold=manifold,
        x_start=np.asarray(x_start, dtype=float),
        x_goal=np.asarray(x_goal, dtype=float),
        planner_name=local_planner_name,
        step_size=step_size,
        **local_planner_kwargs,
    )


def plan_on_leaf_rrt(
    manifold,
    x_start: np.ndarray,
    x_goal: np.ndarray,
    project_newton_fn,
    bounds: Tuple[np.ndarray, np.ndarray],
    step_size: float = 0.10,
    max_nodes: int = 300,
    goal_bias: float = 0.20,
    local_planner_name: str = "projection",
    local_planner_kwargs: Optional[dict] = None,
):
    local_planner_kwargs = dict(local_planner_kwargs or {})
    lower, upper = bounds
    lower = np.asarray(lower, dtype=float)
    upper = np.asarray(upper, dtype=float)

    direct = _run_local_planner(
        manifold=manifold,
        x_start=x_start,
        x_goal=x_goal,
        step_size=step_size,
        local_planner_name=local_planner_name,
        local_planner_kwargs=local_planner_kwargs,
    )
    if direct.success and len(direct.path) > 0:
        return LeafRRTResult(
            success=True,
            path=np.asarray(direct.path),
            message="Solved directly without growing a tree.",
            nodes=[LeafRRTNode(np.asarray(x_start, dtype=float), None)],
        )

    nodes = [LeafRRTNode(np.asarray(x_start, dtype=float), None)]

    for _ in range(max_nodes):
        if np.random.rand() < goal_bias:
            x_rand = np.asarray(x_goal, dtype=float).copy()
        else:
            x_rand = np.random.uniform(lower, upper)

        proj = project_newton_fn(
            manifold=manifold,
            x0=np.asarray(x_rand, dtype=float),
            tol=1e-10,
            max_iters=50,
            damping=1.0,
        )
        if not proj.success:
            continue

        x_proj = np.asarray(proj.x_projected, dtype=float)

        dists = [float(np.linalg.norm(n.x - x_proj)) for n in nodes]
        i_near = int(np.argmin(dists))
        x_near = nodes[i_near].x

        extend = _run_local_planner(
            manifold=manifold,
            x_start=x_near,
            x_goal=x_proj,
            step_size=step_size,
            local_planner_name=local_planner_name,
            local_planner_kwargs=local_planner_kwargs,
        )
        if not extend.success or len(extend.path) == 0:
            continue

        x_new = np.asarray(extend.path[-1], dtype=float)
        nodes.append(LeafRRTNode(x=x_new, parent=i_near))
        i_new = len(nodes) - 1

        to_goal = _run_local_planner(
            manifold=manifold,
            x_start=x_new,
            x_goal=np.asarray(x_goal, dtype=float),
            step_size=step_size,
            local_planner_name=local_planner_name,
            local_planner_kwargs=local_planner_kwargs,
        )
        if to_goal.success and len(to_goal.path) > 0:
            tree_path = _backtrack_path(nodes, i_new)
            full_path = _concat_paths(tree_path, np.asarray(to_goal.path))
            return LeafRRTResult(
                success=True,
                path=full_path,
                message="Solved with leaf-RRT.",
                nodes=nodes,
            )

    return LeafRRTResult(
        success=False,
        path=np.zeros((0, len(np.asarray(x_start).reshape(-1)))),
        message="Leaf-RRT failed to connect start to goal on the chosen leaf.",
        nodes=nodes,
    )


# ============================================================
# Same 2-link robot + task manifolds as Example 37
# ============================================================

class Planar2LinkKinematics:
    def __init__(self, l1: float = 1.0, l2: float = 1.0):
        self.l1 = float(l1)
        self.l2 = float(l2)

    def fk(self, q: np.ndarray) -> np.ndarray:
        q = np.asarray(q, dtype=float)
        q1, q2 = q
        x = self.l1 * np.cos(q1) + self.l2 * np.cos(q1 + q2)
        y = self.l1 * np.sin(q1) + self.l2 * np.sin(q1 + q2)
        return np.array([x, y], dtype=float)

    def jacobian_xy(self, q: np.ndarray) -> np.ndarray:
        q = np.asarray(q, dtype=float)
        q1, q2 = q
        dx_dq1 = -self.l1 * np.sin(q1) - self.l2 * np.sin(q1 + q2)
        dx_dq2 = -self.l2 * np.sin(q1 + q2)
        dy_dq1 = self.l1 * np.cos(q1) + self.l2 * np.cos(q1 + q2)
        dy_dq2 = self.l2 * np.cos(q1 + q2)
        return np.array(
            [
                [dx_dq1, dx_dq2],
                [dy_dq1, dy_dq2],
            ],
            dtype=float,
        )


class EndEffectorXManifold:
    def __init__(self, robot: Planar2LinkKinematics, target_x: float, name: str):
        self.robot = robot
        self.target_x = float(target_x)
        self.name = name

    def _coerce_point(self, q: np.ndarray) -> np.ndarray:
        q = np.asarray(q, dtype=float).reshape(-1)
        return q[:2].copy()

    def residual(self, q: np.ndarray) -> np.ndarray:
        q = self._coerce_point(q)
        return np.array([self.robot.fk(q)[0] - self.target_x], dtype=float)

    def jacobian(self, q: np.ndarray) -> np.ndarray:
        q = self._coerce_point(q)
        return self.robot.jacobian_xy(q)[0:1, :]

    def is_valid(self, q: np.ndarray, tol: float = 1e-6) -> bool:
        return float(np.linalg.norm(self.residual(q))) <= tol


class EndEffectorYManifold:
    def __init__(self, robot: Planar2LinkKinematics, target_y: float, name: str):
        self.robot = robot
        self.target_y = float(target_y)
        self.name = name

    def _coerce_point(self, q: np.ndarray) -> np.ndarray:
        q = np.asarray(q, dtype=float).reshape(-1)
        return q[:2].copy()

    def residual(self, q: np.ndarray) -> np.ndarray:
        q = self._coerce_point(q)
        return np.array([self.robot.fk(q)[1] - self.target_y], dtype=float)

    def jacobian(self, q: np.ndarray) -> np.ndarray:
        q = self._coerce_point(q)
        return self.robot.jacobian_xy(q)[1:2, :]

    def is_valid(self, q: np.ndarray, tol: float = 1e-6) -> bool:
        return float(np.linalg.norm(self.residual(q))) <= tol


class BenchmarkLeafFamily:
    def __init__(self, name: str, lambdas: List[float]):
        self.name = name
        self._lambdas = [float(v) for v in lambdas]

    def manifold(self, lam: float):
        raise NotImplementedError

    def sample_lambdas(self, context=None):
        return list(self._lambdas)

    def lambda_distance(self, lam_a, lam_b) -> float:
        return abs(float(lam_a) - float(lam_b))


class EndEffectorXFamily(BenchmarkLeafFamily):
    def __init__(self, name: str, robot: Planar2LinkKinematics, lambdas: List[float]):
        super().__init__(name=name, lambdas=lambdas)
        self.robot = robot

    def manifold(self, lam: float):
        return EndEffectorXManifold(
            robot=self.robot,
            target_x=float(lam),
            name=f"{self.name}_lambda_{lam:g}",
        )


class EndEffectorYFamily(BenchmarkLeafFamily):
    def __init__(self, name: str, robot: Planar2LinkKinematics, lambdas: List[float]):
        super().__init__(name=name, lambdas=lambdas)
        self.robot = robot

    def manifold(self, lam: float):
        return EndEffectorYManifold(
            robot=self.robot,
            target_y=float(lam),
            name=f"{self.name}_lambda_{lam:g}",
        )


@dataclass
class BenchmarkCase:
    start_family_name: str
    start_lam: float
    start_q: np.ndarray
    goal_family_name: str
    goal_lam: float
    goal_q: np.ndarray
    title: str


def build_benchmark():
    robot = Planar2LinkKinematics(l1=1.0, l2=1.0)

    start_q = np.array([0.5 * np.pi, 0.5 * np.pi], dtype=float)
    goal_q = np.array([0.0, 0.5 * np.pi], dtype=float)

    families = [
        EndEffectorXFamily("left_x_family", robot, [-1.00, -0.80]),
        EndEffectorYFamily("bridge_y_family", robot, [-1.00, -0.50, 0.00, 0.50, 1.00]),
        EndEffectorXFamily("right_x_family", robot, [0.80, 1.00]),
    ]

    case = BenchmarkCase(
        start_family_name="left_x_family",
        start_lam=-1.0,
        start_q=start_q,
        goal_family_name="right_x_family",
        goal_lam=1.0,
        goal_q=goal_q,
        title="Example 38: joint-space leaf graph with constrained leaf-RRT realization",
    )

    return robot, families, case


def get_family_map(families):
    return {f.name: f for f in families}


def allowed_family_pair(fam_a_name: str, fam_b_name: str) -> bool:
    allowed = {
        ("left_x_family", "bridge_y_family"),
        ("bridge_y_family", "left_x_family"),
        ("bridge_y_family", "right_x_family"),
        ("right_x_family", "bridge_y_family"),
    }
    return (fam_a_name, fam_b_name) in allowed


def wrap_to_pi(angle: float) -> float:
    return (float(angle) + np.pi) % (2.0 * np.pi) - np.pi


def two_link_ik_solutions(robot, x: float, y: float):
    l1 = float(robot.l1)
    l2 = float(robot.l2)

    r2 = x * x + y * y
    cos_q2 = (r2 - l1 * l1 - l2 * l2) / (2.0 * l1 * l2)

    if cos_q2 < -1.0 - 1e-10 or cos_q2 > 1.0 + 1e-10:
        return []

    cos_q2 = np.clip(cos_q2, -1.0, 1.0)
    q2_candidates = [np.arccos(cos_q2), -np.arccos(cos_q2)]

    sols = []
    for q2 in q2_candidates:
        k1 = l1 + l2 * np.cos(q2)
        k2 = l2 * np.sin(q2)
        q1 = np.arctan2(y, x) - np.arctan2(k2, k1)

        q1 = wrap_to_pi(q1)
        q2 = wrap_to_pi(q2)
        q = np.array([q1, q2], dtype=float)

        duplicate = False
        for s in sols:
            if np.linalg.norm(q - s) < 1e-8:
                duplicate = True
                break
        if not duplicate:
            sols.append(q)

    return sols


def seed_points_fn(fam_a, lam_a, fam_b, lam_b):
    seeds = []

    vals = np.linspace(-np.pi, np.pi, 9)
    for q1 in vals:
        for q2 in vals:
            seeds.append(np.array([q1, q2], dtype=float))

    def add_ik_seeds(robot, x_target: float, y_target: float):
        sols = two_link_ik_solutions(robot, x_target, y_target)
        eps = 0.05

        for q in sols:
            seeds.append(q.copy())
            seeds.append(q + np.array([eps, 0.0]))
            seeds.append(q + np.array([-eps, 0.0]))
            seeds.append(q + np.array([0.0, eps]))
            seeds.append(q + np.array([0.0, -eps]))
            seeds.append(q + np.array([eps, eps]))
            seeds.append(q + np.array([-eps, -eps]))

    if fam_a.name.endswith("x_family") and fam_b.name.endswith("y_family"):
        add_ik_seeds(fam_a.robot, float(lam_a), float(lam_b))

    if fam_b.name.endswith("x_family") and fam_a.name.endswith("y_family"):
        add_ik_seeds(fam_b.robot, float(lam_b), float(lam_a))

    uniq = []
    for s in seeds:
        s = np.array([wrap_to_pi(s[0]), wrap_to_pi(s[1])], dtype=float)
        if not any(np.linalg.norm(s - t) < 1e-8 for t in uniq):
            uniq.append(s)

    return uniq


def build_restricted_leaf_graph(families, goal_point):
    graph = build_leaf_graph(
        families=families,
        project_newton=project_newton,
        seed_points_fn=seed_points_fn,
        goal_point=goal_point,
        max_candidates_per_pair=2,
    )

    filtered = {}
    for src, edges in graph.adjacency.items():
        kept = []
        for e in edges:
            if allowed_family_pair(e.src[0], e.dst[0]):
                kept.append(e)
        filtered[src] = kept
    graph.adjacency = filtered
    return graph


def edge_cost_fn(edge):
    return 1.0 + edge.score


def concatenate_steps(steps) -> np.ndarray:
    pts = []
    for i, step in enumerate(steps):
        path = np.asarray(step.path)
        if len(path) == 0:
            continue
        if i == 0:
            pts.extend(list(path))
        else:
            pts.extend(list(path[1:]))
    if not pts:
        return np.zeros((0, 2))
    return np.asarray(pts)


def total_path_length_from_steps(steps) -> float:
    total = 0.0
    for step in steps:
        path = np.asarray(step.path)
        if len(path) >= 2:
            total += float(np.sum(np.linalg.norm(np.diff(path, axis=0), axis=1)))
    return total


def plot_workspace_path(ax, robot, q_path: np.ndarray, label: str, style="-"):
    if len(q_path) == 0:
        return
    ee = np.asarray([robot.fk(q) for q in q_path])
    ax.plot(ee[:, 0], ee[:, 1], style, lw=2.5, label=label)


def summarize_leaf_sequence(route_edges, start_key):
    seq = [f"{start_key[0]}[{start_key[1]}]"]
    for e in route_edges:
        seq.append(f"{e.dst[0]}[{e.dst[1]}]")
    return " -> ".join(seq)


def main():
    np.random.seed(7)

    robot, families, case = build_benchmark()
    family_map = get_family_map(families)

    start_key = (case.start_family_name, case.start_lam)
    goal_key = (case.goal_family_name, case.goal_lam)

    start_state = LeafState(
        family_name=case.start_family_name,
        lam=case.start_lam,
        x=case.start_q.copy(),
    )
    goal_family = family_map[case.goal_family_name]
    goal_lam = case.goal_lam
    goal_q = case.goal_q.copy()

    graph = build_restricted_leaf_graph(
        families=families,
        goal_point=goal_q,
    )

    print(f"\n{case.title}")
    print(f"start_key = {start_key}")
    print(f"goal_key  = {goal_key}")
    print(f"graph nodes = {sorted(graph.adjacency.keys(), key=lambda x: (x[0], x[1]))}")

    route = shortest_leaf_route(
        graph=graph,
        start=start_key,
        goal=goal_key,
        edge_cost_fn=edge_cost_fn,
    )

    if route is None:
        print("No nominal route found.")
        return

    print("Selected leaf route:")
    print("  " + summarize_leaf_sequence(route, start_key))

    print("\nTransition edges:")
    for i, e in enumerate(route):
        print(
            f"  edge {i}: {e.src} -> {e.dst}, "
            f"cand={e.candidate_index}, "
            f"q_transition={np.round(e.transition_point, 4)}, "
            f"score={e.score:.4f}, "
            f"EE={np.round(robot.fk(e.transition_point), 4)}"
        )

    deterministic = realize_leaf_route(
        start_state=start_state,
        goal_point=goal_q,
        goal_family=goal_family,
        goal_lam=goal_lam,
        families=families,
        route_edges=route,
        step_size=0.08,
        local_planner_name="projection",
        local_planner_kwargs=dict(
            goal_tol=1e-3,
            max_iters=800,
            projection_tol=1e-10,
            projection_max_iters=50,
            projection_damping=1.0,
        ),
    )

    lower = np.array([-np.pi, -np.pi], dtype=float)
    upper = np.array([np.pi, np.pi], dtype=float)

    current = start_state.copy()
    rrt_steps = []
    rrt_success = True
    rrt_message = "Successfully realized leaf route with constrained leaf-RRT segments."

    for edge in route:
        current_family = family_map[current.family_name]
        current_leaf = current_family.manifold(current.lam)

        seg = plan_on_leaf_rrt(
            manifold=current_leaf,
            x_start=current.x,
            x_goal=edge.transition_point,
            project_newton_fn=project_newton,
            bounds=(lower, upper),
            step_size=0.10,
            max_nodes=300,
            goal_bias=0.20,
            local_planner_name="projection",
            local_planner_kwargs=dict(
                goal_tol=1e-3,
                max_iters=400,
                projection_tol=1e-10,
                projection_max_iters=50,
                projection_damping=1.0,
            ),
        )

        if not seg.success:
            rrt_success = False
            rrt_message = (
                f"Failed reaching transition on leaf "
                f"{current.family_name}[{current.lam}]: {seg.message}"
            )
            break

        rrt_steps.append(
            type(
                "TmpStep",
                (),
                {
                    "path": seg.path,
                    "transition_point": edge.transition_point.copy(),
                },
            )()
        )

        current = LeafState(edge.dst[0], edge.dst[1], edge.transition_point.copy())

    if rrt_success:
        final_family = family_map[current.family_name]
        final_leaf = final_family.manifold(current.lam)

        final_seg = plan_on_leaf_rrt(
            manifold=final_leaf,
            x_start=current.x,
            x_goal=goal_q,
            project_newton_fn=project_newton,
            bounds=(lower, upper),
            step_size=0.10,
            max_nodes=300,
            goal_bias=0.20,
            local_planner_name="projection",
            local_planner_kwargs=dict(
                goal_tol=1e-3,
                max_iters=400,
                projection_tol=1e-10,
                projection_max_iters=50,
                projection_damping=1.0,
            ),
        )

        if not final_seg.success:
            rrt_success = False
            rrt_message = f"Failed final motion on goal leaf: {final_seg.message}"
        else:
            rrt_steps.append(
                type(
                    "TmpStep",
                    (),
                    {
                        "path": final_seg.path,
                        "transition_point": None,
                    },
                )()
            )

    print("\nDeterministic realization:")
    print(f"  success     : {deterministic.success}")
    print(f"  message     : {deterministic.message}")
    print(f"  path length : {total_path_length_from_steps(deterministic.steps):.4f}")

    print("\nLeaf-RRT realization:")
    print(f"  success     : {rrt_success}")
    print(f"  message     : {rrt_message}")
    if rrt_success:
        print(f"  path length : {total_path_length_from_steps(rrt_steps):.4f}")

    q_det = concatenate_steps(deterministic.steps)
    q_rrt = concatenate_steps(rrt_steps) if rrt_success else np.zeros((0, 2))

    fig, axes = plt.subplots(1, 2, figsize=(14, 6))

    ax = axes[0]
    if len(q_det) > 0:
        ax.plot(q_det[:, 0], q_det[:, 1], "--", lw=2.0, label="deterministic leaf realization")
    if len(q_rrt) > 0:
        ax.plot(q_rrt[:, 0], q_rrt[:, 1], lw=3.0, label="leaf-RRT realization")
    for i, e in enumerate(route):
        ax.scatter(
            e.transition_point[0],
            e.transition_point[1],
            s=60,
            zorder=5,
            label="exact transition" if i == 0 else None,
        )
    ax.scatter(case.start_q[0], case.start_q[1], s=90, marker="s", color="black", label="start")
    ax.scatter(case.goal_q[0], case.goal_q[1], s=120, marker="*", color="gold", edgecolor="black", label="goal")
    ax.set_title("Joint space")
    ax.set_xlabel("q1 [rad]")
    ax.set_ylabel("q2 [rad]")
    ax.set_xlim([-np.pi, np.pi])
    ax.set_ylim([-np.pi, np.pi])
    ax.grid(True, alpha=0.25)
    ax.legend()

    ax = axes[1]
    plot_workspace_path(ax, robot, q_det, label="deterministic EE path", style="--")
    plot_workspace_path(ax, robot, q_rrt, label="leaf-RRT EE path", style="-")
    ax.scatter(*robot.fk(case.start_q), s=90, marker="s", color="black", label="start EE")
    ax.scatter(*robot.fk(case.goal_q), s=120, marker="*", color="gold", edgecolor="black", label="goal EE")
    ax.set_title("Workspace interpretation")
    ax.set_xlabel("x")
    ax.set_ylabel("y")
    ax.set_aspect("equal")
    ax.grid(True, alpha=0.25)
    ax.legend()

    plt.tight_layout()
    plt.show()


if __name__ == "__main__":
    main()