import math
import itertools
from dataclasses import dataclass, field
from typing import Dict, List, Tuple, Optional, Set

import numpy as np
import matplotlib.pyplot as plt

try:
    from scipy.optimize import least_squares
except ImportError as exc:
    raise ImportError(
        "This example needs scipy. Install it with: pip install scipy"
    ) from exc


# ============================================================
# Basic helpers
# ============================================================

EPS = 1e-6


def norm(x: np.ndarray) -> float:
    return float(np.linalg.norm(x))


def unit(x: np.ndarray) -> np.ndarray:
    n = np.linalg.norm(x)
    if n < 1e-12:
        return np.zeros_like(x)
    return x / n


def unique_points(points: List[np.ndarray], tol: float = 1e-2) -> List[np.ndarray]:
    out: List[np.ndarray] = []
    for p in points:
        keep = True
        for q in out:
            if norm(p - q) < tol:
                keep = False
                break
        if keep:
            out.append(p)
    return out


# ============================================================
# Leaf / manifold primitives
# ============================================================

class Leaf:
    def __init__(self, family: str, lam: float):
        self.family = family
        self.lam = lam

    @property
    def key(self) -> Tuple[str, float]:
        return (self.family, self.lam)

    @property
    def name(self) -> str:
        return f"{self.family}:{self.lam:+.2f}"

    def residual(self, x: np.ndarray) -> np.ndarray:
        raise NotImplementedError

    def project(self, x: np.ndarray) -> np.ndarray:
        raise NotImplementedError

    def path_length(self, a: np.ndarray, b: np.ndarray, n: int = 80) -> float:
        pts = constrained_interpolate(self, a, b, num=n)
        return polyline_length(pts)

    def sample_points(self, n: int = 400) -> np.ndarray:
        raise NotImplementedError


class LineLeaf(Leaf):
    """
    Implicit line: n^T x - lam = 0
    where n is unit normal.
    """
    def __init__(self, family: str, lam: float, normal: np.ndarray):
        super().__init__(family, lam)
        self.n = unit(np.asarray(normal, dtype=float))
        self.t = np.array([-self.n[1], self.n[0]], dtype=float)

    def residual(self, x: np.ndarray) -> np.ndarray:
        return np.array([float(self.n @ x - self.lam)])

    def project(self, x: np.ndarray) -> np.ndarray:
        r = self.n @ x - self.lam
        return x - r * self.n

    def sample_points(self, n: int = 400) -> np.ndarray:
        base = self.lam * self.n
        s = np.linspace(-4.5, 4.5, n)
        pts = base[None, :] + s[:, None] * self.t[None, :]
        return pts


class CircleLeaf(Leaf):
    """
    Implicit circle: ||x-c|| - r = 0
    Here lam is used as radius.
    """
    def __init__(self, family: str, lam: float, center: np.ndarray):
        super().__init__(family, lam)
        self.c = np.asarray(center, dtype=float)
        self.r = float(lam)

    def residual(self, x: np.ndarray) -> np.ndarray:
        return np.array([norm(x - self.c) - self.r])

    def project(self, x: np.ndarray) -> np.ndarray:
        d = x - self.c
        nd = norm(d)
        if nd < 1e-12:
            d = np.array([1.0, 0.0])
            nd = 1.0
        return self.c + self.r * d / nd

    def sample_points(self, n: int = 400) -> np.ndarray:
        th = np.linspace(0.0, 2.0 * np.pi, n)
        pts = np.column_stack([
            self.c[0] + self.r * np.cos(th),
            self.c[1] + self.r * np.sin(th),
        ])
        return pts


class EllipseLeaf(Leaf):
    """
    Rotated ellipse:
        ((x')/a)^2 + ((y')/b)^2 - 1 = 0
    lam is used as a scale factor on (a0, b0).
    """
    def __init__(
        self,
        family: str,
        lam: float,
        center: np.ndarray,
        a0: float,
        b0: float,
        angle_deg: float,
    ):
        super().__init__(family, lam)
        self.c = np.asarray(center, dtype=float)
        self.a = float(a0 * lam)
        self.b = float(b0 * lam)
        th = math.radians(angle_deg)
        self.R = np.array([
            [math.cos(th), -math.sin(th)],
            [math.sin(th),  math.cos(th)],
        ], dtype=float)

    def _local(self, x: np.ndarray) -> np.ndarray:
        return self.R.T @ (x - self.c)

    def _world(self, y: np.ndarray) -> np.ndarray:
        return self.c + self.R @ y

    def residual(self, x: np.ndarray) -> np.ndarray:
        y = self._local(x)
        return np.array([(y[0] / self.a) ** 2 + (y[1] / self.b) ** 2 - 1.0])

    def project(self, x: np.ndarray) -> np.ndarray:
        x0 = np.asarray(x, dtype=float).copy()

        def fun(z: np.ndarray) -> np.ndarray:
            z = np.asarray(z, dtype=float)
            return np.array([
                z[0] - x0[0],
                z[1] - x0[1],
                20.0 * self.residual(z)[0],
            ])

        res = least_squares(fun, x0, max_nfev=80)
        return res.x

    def sample_points(self, n: int = 400) -> np.ndarray:
        th = np.linspace(0.0, 2.0 * np.pi, n)
        pts_local = np.column_stack([
            self.a * np.cos(th),
            self.b * np.sin(th),
        ])
        pts = np.array([self._world(p) for p in pts_local])
        return pts


# ============================================================
# Constrained local motion
# ============================================================

def constrained_interpolate(
    leaf: Leaf,
    a: np.ndarray,
    b: np.ndarray,
    num: int = 80,
) -> np.ndarray:
    a = leaf.project(a)
    b = leaf.project(b)
    ts = np.linspace(0.0, 1.0, num)
    pts = []
    prev = a.copy()
    for t in ts:
        guess = (1.0 - t) * a + t * b
        p = leaf.project(guess)
        # light continuity help
        if norm(p - prev) > 0.8:
            mid = 0.5 * (prev + guess)
            p = leaf.project(mid)
        pts.append(p)
        prev = p
    return np.array(pts)


def polyline_length(pts: np.ndarray) -> float:
    if len(pts) < 2:
        return 0.0
    return float(np.sum(np.linalg.norm(np.diff(pts, axis=0), axis=1)))


# ============================================================
# Transition discovery
# ============================================================

@dataclass
class TransitionCandidate:
    id: str
    leaf_a: Tuple[str, float]
    leaf_b: Tuple[str, float]
    point: np.ndarray
    score: float


def stacked_project_to_intersection(
    leaf_a: Leaf,
    leaf_b: Leaf,
    x0: np.ndarray,
) -> Optional[np.ndarray]:
    x0 = np.asarray(x0, dtype=float)

    def residual(z: np.ndarray) -> np.ndarray:
        return np.concatenate([leaf_a.residual(z), leaf_b.residual(z)])

    res = least_squares(residual, x0, max_nfev=100)
    z = res.x
    err = norm(residual(z))
    if err > 1e-3:
        return None
    return z


def discover_transition_candidates(
    leaf_a: Leaf,
    leaf_b: Leaf,
    bounds: Tuple[float, float, float, float],
    num_ambient_samples: int = 180,
    near_thresh: float = 0.18,
    max_keep: int = 4,
    rng: Optional[np.random.Generator] = None,
) -> List[TransitionCandidate]:
    if rng is None:
        rng = np.random.default_rng(0)

    xmin, xmax, ymin, ymax = bounds
    accepted: List[np.ndarray] = []

    # attraction-style ambient sampling
    for _ in range(num_ambient_samples):
        x = np.array([
            rng.uniform(xmin, xmax),
            rng.uniform(ymin, ymax),
        ], dtype=float)

        # project to source leaf first
        x_on_a = leaf_a.project(x)

        # see if it gets near target leaf
        rb = abs(float(leaf_b.residual(x_on_a)[0]))
        if rb < near_thresh:
            z = stacked_project_to_intersection(leaf_a, leaf_b, x_on_a)
            if z is not None:
                accepted.append(z)

        # symmetric attempt
        x_on_b = leaf_b.project(x)
        ra = abs(float(leaf_a.residual(x_on_b)[0]))
        if ra < near_thresh:
            z = stacked_project_to_intersection(leaf_a, leaf_b, x_on_b)
            if z is not None:
                accepted.append(z)

    accepted = unique_points(accepted, tol=0.04)

    # score by origin proximity and centrality
    scored: List[Tuple[float, np.ndarray]] = []
    for p in accepted:
        s = norm(p)
        scored.append((s, p))
    scored.sort(key=lambda t: t[0])

    kept = [p for _, p in scored[:max_keep]]

    out: List[TransitionCandidate] = []
    for k, p in enumerate(kept):
        out.append(
            TransitionCandidate(
                id=f"{leaf_a.name}->{leaf_b.name}#c{k}",
                leaf_a=leaf_a.key,
                leaf_b=leaf_b.key,
                point=p,
                score=float(norm(p)),
            )
        )
    return out


# ============================================================
# Graph search over transition candidates
# ============================================================

@dataclass
class SegmentEdge:
    src: str
    dst: str
    via_leaf: Tuple[str, float]
    cost: float
    p_src: np.ndarray
    p_dst: np.ndarray


def pair_key(a: Tuple[str, float], b: Tuple[str, float]) -> Tuple[Tuple[str, float], Tuple[str, float]]:
    return tuple(sorted([a, b], key=lambda x: (x[0], x[1])))


def build_transition_inventory(
    leaves: Dict[Tuple[str, float], Leaf],
    candidate_pairs: List[Tuple[Tuple[str, float], Tuple[str, float]]],
    bounds: Tuple[float, float, float, float],
    rng: np.random.Generator,
) -> Dict[Tuple[Tuple[str, float], Tuple[str, float]], List[TransitionCandidate]]:
    inventory: Dict[Tuple[Tuple[str, float], Tuple[str, float]], List[TransitionCandidate]] = {}
    for a_key, b_key in candidate_pairs:
        a = leaves[a_key]
        b = leaves[b_key]
        cands = discover_transition_candidates(
            a,
            b,
            bounds=bounds,
            num_ambient_samples=240,
            near_thresh=0.16,
            max_keep=4,
            rng=rng,
        )
        if cands:
            inventory[pair_key(a_key, b_key)] = cands
    return inventory


def build_segment_graph(
    leaves: Dict[Tuple[str, float], Leaf],
    inventory: Dict[Tuple[Tuple[str, float], Tuple[str, float]], List[TransitionCandidate]],
    start_leaf: Tuple[str, float],
    start_point: np.ndarray,
    goal_leaf: Tuple[str, float],
    goal_point: np.ndarray,
) -> Tuple[Dict[str, List[SegmentEdge]], Dict[str, TransitionCandidate]]:
    candidate_by_id: Dict[str, TransitionCandidate] = {}
    for cands in inventory.values():
        for c in cands:
            candidate_by_id[c.id] = c

    nodes = ["START", "GOAL"] + list(candidate_by_id.keys())
    adj: Dict[str, List[SegmentEdge]] = {n: [] for n in nodes}

    def leaves_of_node(node_id: str) -> Set[Tuple[str, float]]:
        if node_id == "START":
            return {start_leaf}
        if node_id == "GOAL":
            return {goal_leaf}
        c = candidate_by_id[node_id]
        return {c.leaf_a, c.leaf_b}

    def point_of_node(node_id: str) -> np.ndarray:
        if node_id == "START":
            return start_point
        if node_id == "GOAL":
            return goal_point
        return candidate_by_id[node_id].point

    # connect START -> candidate if they share the start leaf
    for cid, c in candidate_by_id.items():
        shared = {start_leaf} & {c.leaf_a, c.leaf_b}
        if shared:
            leaf_key = next(iter(shared))
            leaf = leaves[leaf_key]
            d = leaf.path_length(start_point, c.point, n=80)
            adj["START"].append(
                SegmentEdge("START", cid, leaf_key, d, start_point, c.point)
            )

    # candidate <-> candidate if they share a leaf
    ids = list(candidate_by_id.keys())
    for i in range(len(ids)):
        for j in range(len(ids)):
            if i == j:
                continue
            a_id = ids[i]
            b_id = ids[j]
            la = leaves_of_node(a_id)
            lb = leaves_of_node(b_id)
            shared = la & lb
            if not shared:
                continue
            pa = point_of_node(a_id)
            pb = point_of_node(b_id)
            for leaf_key in shared:
                leaf = leaves[leaf_key]
                d = leaf.path_length(pa, pb, n=70)
                adj[a_id].append(
                    SegmentEdge(a_id, b_id, leaf_key, d, pa, pb)
                )

    # candidate -> GOAL if they share the goal leaf
    for cid, c in candidate_by_id.items():
        shared = {goal_leaf} & {c.leaf_a, c.leaf_b}
        if shared:
            leaf_key = next(iter(shared))
            leaf = leaves[leaf_key]
            d = leaf.path_length(c.point, goal_point, n=80)
            adj[cid].append(
                SegmentEdge(cid, "GOAL", leaf_key, d, c.point, goal_point)
            )

    return adj, candidate_by_id


def shortest_path(
    adj: Dict[str, List[SegmentEdge]],
    start: str = "START",
    goal: str = "GOAL",
) -> Tuple[float, List[SegmentEdge]]:
    import heapq

    dist: Dict[str, float] = {k: float("inf") for k in adj.keys()}
    prev: Dict[str, Optional[SegmentEdge]] = {k: None for k in adj.keys()}
    dist[start] = 0.0

    pq = [(0.0, start)]
    while pq:
        dcur, u = heapq.heappop(pq)
        if dcur > dist[u] + 1e-12:
            continue
        if u == goal:
            break
        for e in adj[u]:
            nd = dcur + e.cost
            if nd + 1e-12 < dist[e.dst]:
                dist[e.dst] = nd
                prev[e.dst] = e
                heapq.heappush(pq, (nd, e.dst))

    if not np.isfinite(dist[goal]):
        return float("inf"), []

    path_edges: List[SegmentEdge] = []
    cur = goal
    while cur != start:
        e = prev[cur]
        if e is None:
            break
        path_edges.append(e)
        cur = e.src
    path_edges.reverse()
    return dist[goal], path_edges


# ============================================================
# Plotting
# ============================================================

def plot_workspace(
    ax: plt.Axes,
    leaves: Dict[Tuple[str, float], Leaf],
    inventory: Dict[Tuple[Tuple[str, float], Tuple[str, float]], List[TransitionCandidate]],
    start_leaf: Tuple[str, float],
    start_point: np.ndarray,
    goal_leaf: Tuple[str, float],
    goal_point: np.ndarray,
    path_edges: List[SegmentEdge],
):
    # all leaves
    for key, leaf in leaves.items():
        pts = leaf.sample_points()
        lw = 1.2
        alpha = 0.22
        if key == start_leaf:
            lw = 2.2
            alpha = 0.8
        if key == goal_leaf:
            lw = 2.2
            alpha = 0.8
        ax.plot(pts[:, 0], pts[:, 1], alpha=alpha, linewidth=lw)

    # all transition candidates
    all_cands = [c for lst in inventory.values() for c in lst]
    if all_cands:
        pts = np.array([c.point for c in all_cands])
        ax.scatter(
            pts[:, 0],
            pts[:, 1],
            s=20,
            marker="o",
            alpha=0.65,
            label="transition candidates",
        )

    # selected route
    for e in path_edges:
        leaf = leaves[e.via_leaf]
        pts = constrained_interpolate(leaf, e.p_src, e.p_dst, num=100)
        ax.plot(pts[:, 0], pts[:, 1], linewidth=3.5)

    ax.scatter([start_point[0]], [start_point[1]], s=90, marker="s", label="start")
    ax.scatter([goal_point[0]], [goal_point[1]], s=90, marker="*", label="goal")

    ax.set_title("Dense multimodal workspace + selected constrained route")
    ax.set_aspect("equal")
    ax.grid(True, alpha=0.25)
    ax.legend(loc="upper left")


def family_order(name: str) -> int:
    order = {
        "start_line": 0,
        "left_circle": 1,
        "mid_ellipse": 2,
        "right_circle": 3,
        "goal_line": 4,
    }
    return order.get(name, 999)


def compute_leaf_graph_layout(nodes: List[Tuple[str, float]]) -> Dict[Tuple[str, float], Tuple[float, float]]:
    by_family: Dict[str, List[Tuple[str, float]]] = {}
    for n in nodes:
        by_family.setdefault(n[0], []).append(n)

    for fam in by_family:
        by_family[fam].sort(key=lambda x: x[1])

    layout: Dict[Tuple[str, float], Tuple[float, float]] = {}
    families = sorted(by_family.keys(), key=family_order)
    for xi, fam in enumerate(families):
        group = by_family[fam]
        ys = np.linspace(-1.5, 1.5, len(group)) if len(group) > 1 else np.array([0.0])
        for y, node in zip(ys, group):
            layout[node] = (float(xi), float(y))
    return layout


def plot_leaf_graph(
    ax: plt.Axes,
    leaves: Dict[Tuple[str, float], Leaf],
    inventory: Dict[Tuple[Tuple[str, float], Tuple[str, float]], List[TransitionCandidate]],
    start_leaf: Tuple[str, float],
    goal_leaf: Tuple[str, float],
    path_edges: List[SegmentEdge],
):
    nodes = list(leaves.keys())
    layout = compute_leaf_graph_layout(nodes)

    # aggregate discovered edges
    edge_counts: Dict[Tuple[Tuple[str, float], Tuple[str, float]], int] = {}
    for k, v in inventory.items():
        edge_counts[k] = len(v)

    # selected route in leaf space
    selected_leaf_edges: List[Tuple[Tuple[str, float], Tuple[str, float]]] = []
    current_leaf = start_leaf
    current_node = "START"
    for e in path_edges:
        next_leaf = e.via_leaf
        if current_leaf != next_leaf:
            selected_leaf_edges.append(pair_key(current_leaf, next_leaf))
        current_leaf = next_leaf
        current_node = e.dst
    if current_leaf != goal_leaf:
        selected_leaf_edges.append(pair_key(current_leaf, goal_leaf))

    selected_leaf_edges_set = set(selected_leaf_edges)

    # draw all discovered edges
    for (a, b), count in edge_counts.items():
        xa, ya = layout[a]
        xb, yb = layout[b]
        is_selected = pair_key(a, b) in selected_leaf_edges_set
        lw = 4.0 if is_selected else 1.5
        alpha = 0.95 if is_selected else 0.35
        z = 5 if is_selected else 1
        ax.plot([xa, xb], [ya, yb], linewidth=lw, alpha=alpha, zorder=z)

        mx, my = 0.5 * (xa + xb), 0.5 * (ya + yb)
        ax.text(
            mx,
            my + 0.08,
            f"{count}",
            fontsize=9,
            ha="center",
            va="center",
            bbox=dict(boxstyle="round,pad=0.15", fc="white", ec="none", alpha=0.75),
            zorder=10,
        )

    # draw nodes
    for node in nodes:
        x, y = layout[node]
        is_start = node == start_leaf
        is_goal = node == goal_leaf
        size = 260 if (is_start or is_goal) else 150
        ax.scatter([x], [y], s=size, zorder=20)
        ax.text(
            x,
            y - 0.18,
            f"{node[0]}\nλ={node[1]:+.2f}",
            fontsize=9,
            ha="center",
            va="top",
        )

    ax.set_title("Leaf graph: all discovered options, selected route highlighted")
    ax.set_xticks([])
    ax.set_yticks([])
    ax.grid(False)
    for spine in ax.spines.values():
        spine.set_visible(False)


# ============================================================
# Dense benchmark definition
# ============================================================

def make_dense_benchmark() -> Tuple[
    Dict[Tuple[str, float], Leaf],
    Tuple[str, float],
    np.ndarray,
    Tuple[str, float],
    np.ndarray,
    List[Tuple[Tuple[str, float], Tuple[str, float]]],
    Tuple[float, float, float, float],
]:
    leaves: Dict[Tuple[str, float], Leaf] = {}

    # Start family: vertical lines x = lam
    for lam in [-2.20, -1.80, -1.40]:
        leaf = LineLeaf("start_line", lam, normal=np.array([1.0, 0.0]))
        leaves[leaf.key] = leaf

    # Left bridge family: circles
    for lam in [1.15, 1.45, 1.75]:
        leaf = CircleLeaf("left_circle", lam, center=np.array([-0.60, 0.10]))
        leaves[leaf.key] = leaf

    # Middle bridge family: ellipses
    for lam in [0.90, 1.10, 1.30]:
        leaf = EllipseLeaf(
            "mid_ellipse",
            lam,
            center=np.array([0.35, 0.95]),
            a0=1.25,
            b0=0.70,
            angle_deg=28.0,
        )
        leaves[leaf.key] = leaf

    # Right bridge family: circles
    for lam in [0.95, 1.25, 1.55]:
        leaf = CircleLeaf("right_circle", lam, center=np.array([1.55, 1.05]))
        leaves[leaf.key] = leaf

    # Goal family: horizontal lines y = lam
    for lam in [0.90, 1.35, 1.80]:
        leaf = LineLeaf("goal_line", lam, normal=np.array([0.0, 1.0]))
        leaves[leaf.key] = leaf

    start_leaf = ("start_line", -1.80)
    goal_leaf = ("goal_line", 1.35)

    start_point = np.array([-1.80, -1.85], dtype=float)
    goal_point = np.array([2.60, 1.35], dtype=float)

    # Candidate leaf-pair discovery set:
    # dense but structured, not complete all-to-all
    candidate_pairs: List[Tuple[Tuple[str, float], Tuple[str, float]]] = []

    start_keys = [k for k in leaves if k[0] == "start_line"]
    left_keys = [k for k in leaves if k[0] == "left_circle"]
    mid_keys = [k for k in leaves if k[0] == "mid_ellipse"]
    right_keys = [k for k in leaves if k[0] == "right_circle"]
    goal_keys = [k for k in leaves if k[0] == "goal_line"]

    # Dense route options
    candidate_pairs += list(itertools.product(start_keys, left_keys))
    candidate_pairs += list(itertools.product(start_keys, mid_keys))
    candidate_pairs += list(itertools.product(left_keys, mid_keys))
    candidate_pairs += list(itertools.product(left_keys, right_keys))
    candidate_pairs += list(itertools.product(mid_keys, right_keys))
    candidate_pairs += list(itertools.product(mid_keys, goal_keys))
    candidate_pairs += list(itertools.product(right_keys, goal_keys))

    bounds = (-3.2, 3.2, -2.4, 3.0)
    return leaves, start_leaf, start_point, goal_leaf, goal_point, candidate_pairs, bounds


# ============================================================
# Main
# ============================================================

def main():
    rng = np.random.default_rng(7)

    (
        leaves,
        start_leaf,
        start_point,
        goal_leaf,
        goal_point,
        candidate_pairs,
        bounds,
    ) = make_dense_benchmark()

    inventory = build_transition_inventory(
        leaves=leaves,
        candidate_pairs=candidate_pairs,
        bounds=bounds,
        rng=rng,
    )

    print("\n=== Example 29: dense multimodal graph ===")
    print(f"start leaf: {start_leaf}")
    print(f"goal leaf : {goal_leaf}")
    print(f"num leaves: {len(leaves)}")
    print(f"discovered leaf-pair edges: {len(inventory)}")
    print(f"discovered transition candidates: {sum(len(v) for v in inventory.values())}")

    adj, candidate_by_id = build_segment_graph(
        leaves=leaves,
        inventory=inventory,
        start_leaf=start_leaf,
        start_point=start_point,
        goal_leaf=goal_leaf,
        goal_point=goal_point,
    )

    total_cost, path_edges = shortest_path(adj)

    if not path_edges:
        print("No route found through transition graph.")
    else:
        print(f"selected route cost: {total_cost:.4f}")
        print("selected motion segments:")
        for i, e in enumerate(path_edges):
            print(
                f"  seg {i}: {e.src} -> {e.dst}, via leaf={e.via_leaf}, "
                f"cost={e.cost:.4f}"
            )

    fig, axes = plt.subplots(1, 2, figsize=(16, 7))
    plot_workspace(
        axes[0],
        leaves=leaves,
        inventory=inventory,
        start_leaf=start_leaf,
        start_point=start_point,
        goal_leaf=goal_leaf,
        goal_point=goal_point,
        path_edges=path_edges,
    )
    plot_leaf_graph(
        axes[1],
        leaves=leaves,
        inventory=inventory,
        start_leaf=start_leaf,
        goal_leaf=goal_leaf,
        path_edges=path_edges,
    )
    plt.tight_layout()
    plt.show()


if __name__ == "__main__":
    main()