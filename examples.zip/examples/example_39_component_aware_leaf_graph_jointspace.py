from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Tuple, Optional
import heapq
import numpy as np
import matplotlib.pyplot as plt

from primitive_manifold_planner.families.leaf_state import LeafState
from primitive_manifold_planner.planning.local import run_local_planner
from primitive_manifold_planner.projection import project_newton
from primitive_manifold_planner.transitions.leaf_transition import find_leaf_transition


# ============================================================
# Simple 2-link planar arm kinematics
# Ambient state is q = [q1, q2]
# ============================================================

class Planar2LinkKinematics:
    def __init__(self, l1: float = 1.0, l2: float = 1.0):
        self.l1 = float(l1)
        self.l2 = float(l2)

    def fk(self, q: np.ndarray) -> np.ndarray:
        q = np.asarray(q, dtype=float)
        q1, q2 = q
        x = self.l1 * np.cos(q1) + self.l2 * np.cos(q1 + q2)
        y = self.l1 * np.sin(q1) + self.l2 * np.sin(q1 + q2)
        return np.array([x, y], dtype=float)

    def jacobian_xy(self, q: np.ndarray) -> np.ndarray:
        q = np.asarray(q, dtype=float)
        q1, q2 = q
        dx_dq1 = -self.l1 * np.sin(q1) - self.l2 * np.sin(q1 + q2)
        dx_dq2 = -self.l2 * np.sin(q1 + q2)
        dy_dq1 = self.l1 * np.cos(q1) + self.l2 * np.cos(q1 + q2)
        dy_dq2 = self.l2 * np.cos(q1 + q2)
        return np.array(
            [
                [dx_dq1, dx_dq2],
                [dy_dq1, dy_dq2],
            ],
            dtype=float,
        )


# ============================================================
# Implicit task manifolds in joint space
# ============================================================

class EndEffectorXManifold:
    def __init__(self, robot: Planar2LinkKinematics, target_x: float, name: str):
        self.robot = robot
        self.target_x = float(target_x)
        self.name = name

    def _coerce_point(self, q: np.ndarray) -> np.ndarray:
        q = np.asarray(q, dtype=float).reshape(-1)
        return q[:2].copy()

    def residual(self, q: np.ndarray) -> np.ndarray:
        q = self._coerce_point(q)
        return np.array([self.robot.fk(q)[0] - self.target_x], dtype=float)

    def jacobian(self, q: np.ndarray) -> np.ndarray:
        q = self._coerce_point(q)
        return self.robot.jacobian_xy(q)[0:1, :]

    def is_valid(self, q: np.ndarray, tol: float = 1e-6) -> bool:
        return float(np.linalg.norm(self.residual(q))) <= tol


class EndEffectorYManifold:
    def __init__(self, robot: Planar2LinkKinematics, target_y: float, name: str):
        self.robot = robot
        self.target_y = float(target_y)
        self.name = name

    def _coerce_point(self, q: np.ndarray) -> np.ndarray:
        q = np.asarray(q, dtype=float).reshape(-1)
        return q[:2].copy()

    def residual(self, q: np.ndarray) -> np.ndarray:
        q = self._coerce_point(q)
        return np.array([self.robot.fk(q)[1] - self.target_y], dtype=float)

    def jacobian(self, q: np.ndarray) -> np.ndarray:
        q = self._coerce_point(q)
        return self.robot.jacobian_xy(q)[1:2, :]

    def is_valid(self, q: np.ndarray, tol: float = 1e-6) -> bool:
        return float(np.linalg.norm(self.residual(q))) <= tol


# ============================================================
# Thin family wrappers
# ============================================================

class BenchmarkLeafFamily:
    def __init__(self, name: str, lambdas: List[float]):
        self.name = name
        self._lambdas = [float(v) for v in lambdas]

    def manifold(self, lam: float):
        raise NotImplementedError

    def sample_lambdas(self, context=None):
        return list(self._lambdas)

    def lambda_distance(self, lam_a, lam_b) -> float:
        return abs(float(lam_a) - float(lam_b))


class EndEffectorXFamily(BenchmarkLeafFamily):
    def __init__(self, name: str, robot: Planar2LinkKinematics, lambdas: List[float]):
        super().__init__(name=name, lambdas=lambdas)
        self.robot = robot

    def manifold(self, lam: float):
        return EndEffectorXManifold(
            robot=self.robot,
            target_x=float(lam),
            name=f"{self.name}_lambda_{lam:g}",
        )


class EndEffectorYFamily(BenchmarkLeafFamily):
    def __init__(self, name: str, robot: Planar2LinkKinematics, lambdas: List[float]):
        super().__init__(name=name, lambdas=lambdas)
        self.robot = robot

    def manifold(self, lam: float):
        return EndEffectorYManifold(
            robot=self.robot,
            target_y=float(lam),
            name=f"{self.name}_lambda_{lam:g}",
        )


# ============================================================
# Component-aware graph
# ============================================================

ComponentKey = Tuple[str, float, str]


@dataclass
class ComponentEdge:
    src: ComponentKey
    dst: ComponentKey
    transition_point: np.ndarray
    score: float
    candidate_index: int = 0


@dataclass
class ComponentGraph:
    adjacency: Dict[ComponentKey, List[ComponentEdge]] = field(default_factory=dict)

    def add_node(self, node: ComponentKey) -> None:
        self.adjacency.setdefault(node, [])

    def add_edge(self, edge: ComponentEdge) -> None:
        self.add_node(edge.src)
        self.add_node(edge.dst)
        self.adjacency[edge.src].append(edge)

    def neighbors(self, node: ComponentKey) -> List[ComponentEdge]:
        return self.adjacency.get(node, [])


@dataclass
class ComponentRouteStep:
    family_name: str
    lam: float
    component_id: str
    path: np.ndarray
    transition_point: Optional[np.ndarray] = None


@dataclass
class ComponentRouteResult:
    success: bool
    steps: List[ComponentRouteStep]
    final_state: Optional[LeafState]
    message: str = ""


# ============================================================
# Helpers
# ============================================================

def wrap_to_pi(angle: float) -> float:
    return (float(angle) + np.pi) % (2.0 * np.pi) - np.pi


def component_of_q(q: np.ndarray) -> str:
    q = np.asarray(q, dtype=float)
    return "up" if float(q[1]) >= 0.0 else "down"


def two_link_ik_solutions(robot, x: float, y: float):
    l1 = float(robot.l1)
    l2 = float(robot.l2)

    r2 = x * x + y * y
    cos_q2 = (r2 - l1 * l1 - l2 * l2) / (2.0 * l1 * l2)

    if cos_q2 < -1.0 - 1e-10 or cos_q2 > 1.0 + 1e-10:
        return []

    cos_q2 = np.clip(cos_q2, -1.0, 1.0)
    q2_candidates = [np.arccos(cos_q2), -np.arccos(cos_q2)]

    sols = []
    for q2 in q2_candidates:
        k1 = l1 + l2 * np.cos(q2)
        k2 = l2 * np.sin(q2)
        q1 = np.arctan2(y, x) - np.arctan2(k2, k1)

        q1 = wrap_to_pi(q1)
        q2 = wrap_to_pi(q2)
        q = np.array([q1, q2], dtype=float)

        duplicate = False
        for s in sols:
            if np.linalg.norm(q - s) < 1e-8:
                duplicate = True
                break
        if not duplicate:
            sols.append(q)

    return sols


def allowed_family_pair(fam_a_name: str, fam_b_name: str) -> bool:
    allowed = {
        ("left_x_family", "bridge_y_family"),
        ("bridge_y_family", "left_x_family"),
        ("bridge_y_family", "right_x_family"),
        ("right_x_family", "bridge_y_family"),
    }
    return (fam_a_name, fam_b_name) in allowed


def seed_points_fn(fam_a, lam_a, fam_b, lam_b):
    seeds = []

    vals = np.linspace(-np.pi, np.pi, 9)
    for q1 in vals:
        for q2 in vals:
            seeds.append(np.array([q1, q2], dtype=float))

    def add_ik_seeds(robot, x_target: float, y_target: float):
        sols = two_link_ik_solutions(robot, x_target, y_target)
        eps = 0.05
        for q in sols:
            seeds.append(q.copy())
            seeds.append(q + np.array([eps, 0.0]))
            seeds.append(q + np.array([-eps, 0.0]))
            seeds.append(q + np.array([0.0, eps]))
            seeds.append(q + np.array([0.0, -eps]))
            seeds.append(q + np.array([eps, eps]))
            seeds.append(q + np.array([-eps, -eps]))

    if fam_a.name.endswith("x_family") and fam_b.name.endswith("y_family"):
        add_ik_seeds(fam_a.robot, float(lam_a), float(lam_b))

    if fam_b.name.endswith("x_family") and fam_a.name.endswith("y_family"):
        add_ik_seeds(fam_b.robot, float(lam_b), float(lam_a))

    uniq = []
    for s in seeds:
        s = np.array([wrap_to_pi(s[0]), wrap_to_pi(s[1])], dtype=float)
        if not any(np.linalg.norm(s - t) < 1e-8 for t in uniq):
            uniq.append(s)

    return uniq


def build_component_aware_graph(
    families,
    goal_point: np.ndarray,
    max_candidates_per_pair: int = 4,
):
    graph = ComponentGraph()
    component_ids = ["up", "down"]

    family_nodes = []
    for fam in families:
        for lam in fam.sample_lambdas():
            family_nodes.append((fam, lam))

    for fam, lam in family_nodes:
        for comp in component_ids:
            graph.add_node((fam.name, float(lam), comp))

    for i, (fam_a, lam_a) in enumerate(family_nodes):
        for j in range(i + 1, len(family_nodes)):
            fam_b, lam_b = family_nodes[j]

            if not allowed_family_pair(fam_a.name, fam_b.name):
                continue

            result = find_leaf_transition(
                source_family=fam_a,
                source_lam=lam_a,
                target_family=fam_b,
                target_lam=lam_b,
                seeds=seed_points_fn(fam_a, lam_a, fam_b, lam_b),
                project_newton=project_newton,
                goal=goal_point,
            )

            if not result.success:
                continue

            kept = result.candidates[:max_candidates_per_pair]
            for k, cand in enumerate(kept):
                comp = component_of_q(cand.x)

                src = (fam_a.name, float(lam_a), comp)
                dst = (fam_b.name, float(lam_b), comp)

                graph.add_edge(
                    ComponentEdge(
                        src=src,
                        dst=dst,
                        transition_point=cand.x.copy(),
                        score=float(cand.score),
                        candidate_index=k,
                    )
                )
                graph.add_edge(
                    ComponentEdge(
                        src=dst,
                        dst=src,
                        transition_point=cand.x.copy(),
                        score=float(cand.score),
                        candidate_index=k,
                    )
                )

    return graph


def edge_cost_fn(edge: ComponentEdge) -> float:
    return 1.0 + edge.score


def shortest_component_route(
    graph: ComponentGraph,
    start: ComponentKey,
    goal: ComponentKey,
):
    pq = []
    heapq.heappush(pq, (0.0, start))

    dist = {start: 0.0}
    parent = {}
    parent_edge = {}

    while pq:
        g_cost, node = heapq.heappop(pq)

        if node == goal:
            break

        if g_cost > dist.get(node, float("inf")):
            continue

        for edge in graph.neighbors(node):
            step_cost = float(edge_cost_fn(edge))
            new_cost = g_cost + step_cost

            if new_cost < dist.get(edge.dst, float("inf")):
                dist[edge.dst] = new_cost
                parent[edge.dst] = node
                parent_edge[edge.dst] = edge
                heapq.heappush(pq, (new_cost, edge.dst))

    if start == goal:
        return []

    if goal not in parent_edge:
        return None

    route = []
    cur = goal
    while cur != start:
        edge = parent_edge[cur]
        route.append(edge)
        cur = parent[cur]
    route.reverse()
    return route


def realize_component_route(
    start_state: LeafState,
    start_component: str,
    goal_q: np.ndarray,
    goal_component: str,
    families,
    route_edges,
    step_size: float = 0.08,
    local_planner_name: str = "projection",
    local_planner_kwargs: Optional[dict] = None,
):
    family_map = {f.name: f for f in families}
    current = start_state.copy()
    current_component = start_component
    steps: List[ComponentRouteStep] = []
    local_planner_kwargs = dict(local_planner_kwargs or {})

    for edge in route_edges:
        current_family = family_map[current.family_name]
        current_leaf = current_family.manifold(current.lam)

        seg = run_local_planner(
            manifold=current_leaf,
            x_start=current.x,
            x_goal=edge.transition_point,
            planner_name=local_planner_name,
            step_size=step_size,
            **local_planner_kwargs,
        )
        if not seg.success:
            return ComponentRouteResult(
                success=False,
                steps=steps,
                final_state=current,
                message=(
                    f"Failed reaching transition on "
                    f"{current.family_name}[{current.lam}] component={current_component}: "
                    f"{seg.message}"
                ),
            )

        steps.append(
            ComponentRouteStep(
                family_name=current.family_name,
                lam=float(current.lam),
                component_id=current_component,
                path=np.asarray(seg.path),
                transition_point=edge.transition_point.copy(),
            )
        )

        dst_family, dst_lam, dst_comp = edge.dst
        current = LeafState(dst_family, float(dst_lam), edge.transition_point.copy())
        current_component = dst_comp

    final_family = family_map[current.family_name]
    final_leaf = final_family.manifold(current.lam)

    final_seg = run_local_planner(
        manifold=final_leaf,
        x_start=current.x,
        x_goal=goal_q,
        planner_name=local_planner_name,
        step_size=step_size,
        **local_planner_kwargs,
    )
    if not final_seg.success:
        return ComponentRouteResult(
            success=False,
            steps=steps,
            final_state=current,
            message=f"Failed final motion on goal leaf: {final_seg.message}",
        )

    steps.append(
        ComponentRouteStep(
            family_name=current.family_name,
            lam=float(current.lam),
            component_id=current_component,
            path=np.asarray(final_seg.path),
            transition_point=None,
        )
    )

    return ComponentRouteResult(
        success=True,
        steps=steps,
        final_state=LeafState(current.family_name, current.lam, final_seg.path[-1].copy()),
        message="Successfully realized component-aware leaf route.",
    )


# ============================================================
# Example setup
# ============================================================

@dataclass
class BenchmarkCase:
    start_family_name: str
    start_lam: float
    start_q: np.ndarray
    goal_family_name: str
    goal_lam: float
    goal_q: np.ndarray
    title: str


def build_benchmark():
    robot = Planar2LinkKinematics(l1=1.0, l2=1.0)

    # Component-consistent case: up -> up
    start_q = np.array([0.5 * np.pi, 0.5 * np.pi], dtype=float)   # EE = (-1, 1), up
    goal_q = np.array([0.0, 0.5 * np.pi], dtype=float)            # EE = ( 1, 1), up

    families = [
        EndEffectorXFamily("left_x_family", robot, [-1.00, -0.80]),
        EndEffectorYFamily("bridge_y_family", robot, [-1.00, -0.50, 0.00, 0.50, 1.00]),
        EndEffectorXFamily("right_x_family", robot, [0.80, 1.00]),
    ]

    case = BenchmarkCase(
        start_family_name="left_x_family",
        start_lam=-1.0,
        start_q=start_q,
        goal_family_name="right_x_family",
        goal_lam=1.0,
        goal_q=goal_q,
        title="Example 39: component-aware leaf graph in 2D joint space",
    )
    return robot, families, case


# ============================================================
# Plot helpers
# ============================================================

def concatenate_steps(steps) -> np.ndarray:
    pts = []
    for i, step in enumerate(steps):
        path = np.asarray(step.path)
        if len(path) == 0:
            continue
        if i == 0:
            pts.extend(list(path))
        else:
            pts.extend(list(path[1:]))
    if not pts:
        return np.zeros((0, 2))
    return np.asarray(pts)


def total_path_length_from_steps(steps) -> float:
    total = 0.0
    for step in steps:
        path = np.asarray(step.path)
        if len(path) >= 2:
            total += float(np.sum(np.linalg.norm(np.diff(path, axis=0), axis=1)))
    return total


def summarize_component_route(route_edges, start_key):
    seq = [f"{start_key[0]}[{start_key[1]}|{start_key[2]}]"]
    for e in route_edges:
        fam, lam, comp = e.dst
        seq.append(f"{fam}[{lam}|{comp}]")
    return " -> ".join(seq)


def plot_jointspace_families(ax, robot, families):
    q1 = np.linspace(-np.pi, np.pi, 300)
    q2 = np.linspace(-np.pi, np.pi, 300)
    Q1, Q2 = np.meshgrid(q1, q2)

    X = robot.l1 * np.cos(Q1) + robot.l2 * np.cos(Q1 + Q2)
    Y = robot.l1 * np.sin(Q1) + robot.l2 * np.sin(Q1 + Q2)

    for fam in families:
        for lam in fam.sample_lambdas():
            if fam.name.endswith("x_family"):
                ax.contour(Q1, Q2, X, levels=[lam], linewidths=1.0, alpha=0.30)
            elif fam.name.endswith("y_family"):
                ax.contour(Q1, Q2, Y, levels=[lam], linewidths=1.0, alpha=0.30)


def plot_workspace_path(ax, robot, q_path: np.ndarray, label: str):
    if len(q_path) == 0:
        return
    ee = np.asarray([robot.fk(q) for q in q_path])
    ax.plot(ee[:, 0], ee[:, 1], lw=2.5, label=label)


# ============================================================
# Main
# ============================================================

def main():
    np.random.seed(7)

    robot, families, case = build_benchmark()

    start_comp = component_of_q(case.start_q)
    goal_comp = component_of_q(case.goal_q)

    start_key = (case.start_family_name, case.start_lam, start_comp)
    goal_key = (case.goal_family_name, case.goal_lam, goal_comp)

    start_state = LeafState(
        family_name=case.start_family_name,
        lam=case.start_lam,
        x=case.start_q.copy(),
    )

    graph = build_component_aware_graph(
        families=families,
        goal_point=case.goal_q.copy(),
        max_candidates_per_pair=4,
    )

    print(f"\n{case.title}")
    print(f"start q = {np.round(case.start_q, 4)}  comp={start_comp}")
    print(f"goal  q = {np.round(case.goal_q, 4)}  comp={goal_comp}")
    print(f"start EE = {np.round(robot.fk(case.start_q), 4)}")
    print(f"goal  EE = {np.round(robot.fk(case.goal_q), 4)}")
    print(f"start_key = {start_key}")
    print(f"goal_key  = {goal_key}")

    route = shortest_component_route(
        graph=graph,
        start=start_key,
        goal=goal_key,
    )

    if route is None:
        print("\nNo component-aware route found.")
        return

    print("\nSelected component-aware route:")
    print("  " + summarize_component_route(route, start_key))

    print("\nTransition edges:")
    for i, e in enumerate(route):
        print(
            f"  edge {i}: {e.src} -> {e.dst}, "
            f"cand={e.candidate_index}, "
            f"q_transition={np.round(e.transition_point, 4)}, "
            f"score={e.score:.4f}, "
            f"EE={np.round(robot.fk(e.transition_point), 4)}"
        )

    realized = realize_component_route(
        start_state=start_state,
        start_component=start_comp,
        goal_q=case.goal_q.copy(),
        goal_component=goal_comp,
        families=families,
        route_edges=route,
        step_size=0.08,
        local_planner_name="projection",
        local_planner_kwargs=dict(
            goal_tol=1e-3,
            max_iters=800,
            projection_tol=1e-10,
            projection_max_iters=50,
            projection_damping=1.0,
        ),
    )

    print("\nRealization result:")
    print(f"  success      : {realized.success}")
    print(f"  message      : {realized.message}")
    print(f"  path length  : {total_path_length_from_steps(realized.steps):.4f}")

    q_path = concatenate_steps(realized.steps)

    fig, axes = plt.subplots(1, 2, figsize=(14, 6))

    ax = axes[0]
    plot_jointspace_families(ax, robot, families)
    if len(q_path) > 0:
        ax.plot(q_path[:, 0], q_path[:, 1], lw=3.0, label="component-aware joint-space path")
    for i, e in enumerate(route):
        ax.scatter(
            e.transition_point[0],
            e.transition_point[1],
            s=60,
            zorder=5,
            label="exact transition" if i == 0 else None,
        )
    ax.scatter(case.start_q[0], case.start_q[1], s=90, marker="s", color="black", label="start")
    ax.scatter(case.goal_q[0], case.goal_q[1], s=120, marker="*", color="gold", edgecolor="black", label="goal")
    ax.set_title("Joint space with component-aware routing")
    ax.set_xlabel("q1 [rad]")
    ax.set_ylabel("q2 [rad]")
    ax.set_xlim([-np.pi, np.pi])
    ax.set_ylim([-np.pi, np.pi])
    ax.grid(True, alpha=0.25)
    ax.legend()

    ax = axes[1]
    plot_workspace_path(ax, robot, q_path, label="end-effector path")
    ax.scatter(*robot.fk(case.start_q), s=90, marker="s", color="black", label="start EE")
    ax.scatter(*robot.fk(case.goal_q), s=120, marker="*", color="gold", edgecolor="black", label="goal EE")
    ax.set_title("Workspace interpretation")
    ax.set_xlabel("x")
    ax.set_ylabel("y")
    ax.set_aspect("equal")
    ax.grid(True, alpha=0.25)
    ax.legend()

    plt.tight_layout()
    plt.show()


if __name__ == "__main__":
    main()