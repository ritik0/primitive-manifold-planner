from __future__ import annotations

import numpy as np
import matplotlib.pyplot as plt

from primitive_manifold_planner.manifolds import CircleManifold
from primitive_manifold_planner.planning import build_mode_graph, plan_multimodal_route
from primitive_manifold_planner.visualization import (
    finalize_2d_axes,
    plot_circle_manifold,
    plot_path_2d,
    plot_start_goal,
)


def main() -> None:
    # ------------------------------------------------------------
    # Define a very simple multimodal world: one circle mode
    # ------------------------------------------------------------
    manifolds = {
        "circle": CircleManifold(center=np.array([0.0, 0.0]), radius=2.0, name="circle"),
    }

    start_point = np.array([2.0, 0.0])
    goal_point = np.array([0.0, 2.0])

    # ------------------------------------------------------------
    # Build the mode graph
    # Even with one mode, this validates the same graph pipeline
    # used later for true multimodal cases.
    # ------------------------------------------------------------
    rng = np.random.default_rng(0)
    graph, diagnostics = build_mode_graph(
        manifolds=manifolds,
        bounds_min=np.array([-3.0, -3.0]),
        bounds_max=np.array([3.0, 3.0]),
        num_seeds=10,
        tol=1e-8,
        rng=rng,
    )

    print("=== Mode graph ===")
    print(graph)
    print(f"Nodes: {list(graph.nodes.keys())}")
    print(f"Edges: {len(graph.edges)}")
    print(f"Diagnostics keys: {list(diagnostics.keys())}")

    # ------------------------------------------------------------
    # Plan using the high-level multimodal planner
    # ------------------------------------------------------------
    result = plan_multimodal_route(
        graph=graph,
        start_mode="circle",
        goal_mode="circle",
        start_point=start_point,
        goal_point=goal_point,
        step_size=0.2,
        goal_tol=5e-2,
        max_iters=500,
    )

    print("\n=== Multimodal plan result ===")
    print(f"Success        : {result.success}")
    print(f"Message        : {result.message}")

    if result.route is not None:
        print(f"Mode sequence  : {result.route.mode_sequence}")
        print(f"# transitions  : {len(result.route.transition_steps)}")

    print(f"# segments     : {len(result.segment_plans)}")

    for i, seg in enumerate(result.segment_plans):
        print(f"\n  Segment {i + 1}")
        print(f"    mode       : {seg.mode_name}")
        print(f"    success    : {seg.success}")
        print(f"    message    : {seg.message}")
        print(f"    start      : {seg.start_point}")
        print(f"    end        : {seg.end_point}")
        print(f"    path shape : {seg.path.shape}")

    # ------------------------------------------------------------
    # Plot the result
    # ------------------------------------------------------------
    fig, ax = plt.subplots(figsize=(7, 7))

    circle = manifolds["circle"]
    plot_circle_manifold(ax, circle, label="circle manifold")
    plot_start_goal(ax, start_point, goal_point)

    if result.full_path is not None:
        plot_path_2d(ax, result.full_path, show_points=True, label="full multimodal path")

    finalize_2d_axes(ax, title="End-to-end multimodal planner on a single circle")
    plt.show()


if __name__ == "__main__":
    main()