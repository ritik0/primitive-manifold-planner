from __future__ import annotations

import numpy as np
import matplotlib
matplotlib.use("TkAgg")
import matplotlib.pyplot as plt

from primitive_manifold_planner.families.base import ManifoldFamily
from primitive_manifold_planner.transitions.attraction_sampler import (
    discover_transition_candidates_via_attraction,
)
from primitive_manifold_planner.projection import project_newton
from primitive_manifold_planner.manifolds import LineManifold, CircleManifold


class ParallelLineLeafFamily(ManifoldFamily):
    def __init__(self, name: str, lambdas=None):
        super().__init__(name)
        self._lambdas = lambdas if lambdas is not None else [-1.0, 1.0]

    def manifold(self, lam):
        return LineManifold(
            point=np.array([0.0, lam], dtype=float),
            normal=np.array([0.0, 1.0], dtype=float),
            name=f"{self.name}_lam_{lam}",
        )

    def sample_lambdas(self, context=None):
        return list(self._lambdas)


class CircleLeafFamily(ManifoldFamily):
    def __init__(self, name: str, center=(0.0, 0.0), radii=None):
        super().__init__(name)
        self.center = np.array(center, dtype=float)
        self._radii = radii if radii is not None else [1.4]

    def manifold(self, lam):
        return CircleManifold(
            center=self.center,
            radius=float(lam),
            name=f"{self.name}_r_{lam}",
        )

    def sample_lambdas(self, context=None):
        return list(self._radii)


def plot_family(ax, fam, color="lightgray", n=300):
    if isinstance(fam, ParallelLineLeafFamily):
        xs = np.linspace(-3.0, 3.0, n)
        for lam in fam.sample_lambdas():
            ys = np.full_like(xs, lam)
            ax.plot(xs, ys, "--", color=color, linewidth=1.2)

    elif isinstance(fam, CircleLeafFamily):
        ts = np.linspace(0.0, 2.0 * np.pi, n)
        for r in fam.sample_lambdas():
            xs = fam.center[0] + r * np.cos(ts)
            ys = fam.center[1] + r * np.sin(ts)
            ax.plot(xs, ys, "--", color=color, linewidth=1.2)


def main():
    np.random.seed(7)

    line_family = ParallelLineLeafFamily("line_family", lambdas=[-1.0])
    circle_family = CircleLeafFamily("circle_family", center=(0.0, 0.0), radii=[1.4])

    source_lam = -1.0
    target_lam = 1.4

    current_x = np.array([-2.2, -1.0], dtype=float)
    goal_x = np.array([2.2, 1.0], dtype=float)

    result = discover_transition_candidates_via_attraction(
        source_family=line_family,
        source_lam=source_lam,
        target_family=circle_family,
        target_lam=target_lam,
        current_x=current_x,
        goal_x=goal_x,
        project_newton=project_newton,
        ambient_local_radius=0.7,
        n_local_samples=50,
        n_goal_bias_samples=40,
        goal_band_width=0.20,
        target_residual_threshold=0.35,
    )

    print("\n=== Example 25 attraction-based transition discovery ===")
    print("success:", result.success)
    print("message:", result.message)
    print("num sampled points:", len(result.samples))
    accepted = sum(1 for s in result.samples if s.accepted_for_switch_attempt)
    print("num accepted for switch attempt:", accepted)
    print("num final transition candidates:", len(result.transition_result.candidates))

    for i, cand in enumerate(result.transition_result.candidates):
        print(
            f"  cand {i}: x={np.round(cand.x, 4)}, "
            f"residual_norm={cand.residual_norm:.6f}, score={cand.score:.4f}"
        )

    fig, ax = plt.subplots(figsize=(9, 8))

    plot_family(ax, line_family, color="lightblue")
    plot_family(ax, circle_family, color="moccasin")

    # ambient samples
    amb = np.array([s.x_ambient for s in result.samples])
    if len(amb) > 0:
        ax.scatter(
            amb[:, 0], amb[:, 1],
            s=16, alpha=0.18, color="gray", label="ambient samples"
        )

    # projected-on-source samples
    src_pts = np.array([s.x_on_source for s in result.samples])
    if len(src_pts) > 0:
        colors = ["tab:orange" if s.accepted_for_switch_attempt else "tab:blue" for s in result.samples]
        ax.scatter(
            src_pts[:, 0], src_pts[:, 1],
            s=26, alpha=0.75, c=colors, label="projected source samples"
        )

    # final transition candidates
    for i, cand in enumerate(result.transition_result.candidates):
        ax.scatter(
            cand.x[0], cand.x[1],
            s=100, marker="x", color="red",
            label="transition candidate" if i == 0 else None
        )

    ax.scatter(current_x[0], current_x[1], color="purple", s=95, label="current state")
    ax.scatter(goal_x[0], goal_x[1], color="green", s=95, label="goal")

    ax.set_aspect("equal", adjustable="box")
    ax.set_title("Example 25: Attraction-based transition discovery")
    ax.grid(True, alpha=0.3)
    ax.legend()
    plt.tight_layout()
    plt.savefig("example_25_transition_attraction.png", dpi=180)
    plt.show()


if __name__ == "__main__":
    main()