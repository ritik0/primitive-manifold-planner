from __future__ import annotations

import numpy as np
import matplotlib
matplotlib.use("TkAgg")
import matplotlib.pyplot as plt

from primitive_manifold_planner.families.base import ManifoldFamily
from primitive_manifold_planner.families.leaf_state import LeafState

from primitive_manifold_planner.manifolds import LineManifold, CircleManifold
from primitive_manifold_planner.planning.local import constrained_interpolate
from primitive_manifold_planner.projection import project_newton

from primitive_manifold_planner.planners.leaf_graph import (
    build_leaf_graph,
    shortest_leaf_route,
)
from primitive_manifold_planner.planners.realize_leaf_route import realize_leaf_route


class ParallelLineLeafFamily(ManifoldFamily):
    def __init__(self, name: str, lambdas=None):
        super().__init__(name)
        self._lambdas = lambdas if lambdas is not None else [-1.0, 1.0]

    def manifold(self, lam):
        return LineManifold(
            point=np.array([0.0, lam], dtype=float),
            normal=np.array([0.0, 1.0], dtype=float),
            name=f"{self.name}_lam_{lam}",
        )

    def sample_lambdas(self, context=None):
        return list(self._lambdas)


class SingleCircleLeafFamily(ManifoldFamily):
    """
    A family with one or more circle leaves around a chosen center.
    """
    def __init__(self, name: str, center=(0.0, 0.0), radii=None):
        super().__init__(name)
        self.center = np.array(center, dtype=float)
        self._radii = radii if radii is not None else [1.05]

    def manifold(self, lam):
        return CircleManifold(
            center=self.center,
            radius=float(lam),
            name=f"{self.name}_r_{lam}",
        )

    def sample_lambdas(self, context=None):
        return list(self._radii)


def plot_family(ax, fam, color="lightgray", n=300):
    if isinstance(fam, ParallelLineLeafFamily):
        xs = np.linspace(-3.0, 3.0, n)
        for lam in fam.sample_lambdas():
            ys = np.full_like(xs, lam)
            ax.plot(xs, ys, "--", color=color, linewidth=1.2)

    elif isinstance(fam, SingleCircleLeafFamily):
        ts = np.linspace(0.0, 2.0 * np.pi, n)
        for r in fam.sample_lambdas():
            xs = fam.center[0] + r * np.cos(ts)
            ys = fam.center[1] + r * np.sin(ts)
            ax.plot(xs, ys, "--", color=color, linewidth=1.2)


def plot_graph_edges(ax, graph):
    for src, edges in graph.adjacency.items():
        for e in edges:
            p = e.transition_point
            ax.scatter(p[0], p[1], color="red", s=22, alpha=0.55)


def plot_realized_result(ax, result):
    color_map = {
        "line_family": "tab:blue",
        "left_bridge": "tab:orange",
        "right_bridge": "tab:green",
    }

    for step in result.steps:
        pts = np.asarray(step.path)
        if len(pts) == 0:
            continue

        ax.plot(
            pts[:, 0],
            pts[:, 1],
            "-",
            color=color_map.get(step.family_name, "tab:purple"),
            linewidth=2.8,
        )

        if step.transition_point is not None:
            tp = step.transition_point
            ax.scatter(tp[0], tp[1], color="black", s=70, marker="x")


def informed_seed_points_fn(fam_a, lam_a, fam_b, lam_b):
    """
    Better seeds for line-circle and circle-circle intersections.
    """
    seeds = []

    def add_unique(arr):
        for s in arr:
            if not any(np.linalg.norm(s - u) < 1e-8 for u in seeds):
                seeds.append(s)

    # line-family vs circle-family
    if isinstance(fam_a, ParallelLineLeafFamily) and isinstance(fam_b, SingleCircleLeafFamily):
        y = float(lam_a)
        c = fam_b.center
        r = float(lam_b)

        dy = y - c[1]
        if abs(dy) <= r + 1e-9:
            dx_sq = max(r * r - dy * dy, 0.0)
            dx = np.sqrt(dx_sq)
            add_unique([
                np.array([c[0] + dx, y], dtype=float),
                np.array([c[0] - dx, y], dtype=float),
            ])

        xs = np.linspace(c[0] - 1.5 * r, c[0] + 1.5 * r, 11)
        add_unique([np.array([x, y], dtype=float) for x in xs])

        thetas = np.linspace(0.0, 2.0 * np.pi, 14, endpoint=False)
        add_unique([c + r * np.array([np.cos(t), np.sin(t)], dtype=float) for t in thetas])

        return seeds

    if isinstance(fam_a, SingleCircleLeafFamily) and isinstance(fam_b, ParallelLineLeafFamily):
        return informed_seed_points_fn(fam_b, lam_b, fam_a, lam_a)

    # circle-family vs circle-family
    if isinstance(fam_a, SingleCircleLeafFamily) and isinstance(fam_b, SingleCircleLeafFamily):
        c1, r1 = fam_a.center, float(lam_a)
        c2, r2 = fam_b.center, float(lam_b)

        thetas = np.linspace(0.0, 2.0 * np.pi, 16, endpoint=False)
        add_unique([c1 + r1 * np.array([np.cos(t), np.sin(t)], dtype=float) for t in thetas])
        add_unique([c2 + r2 * np.array([np.cos(t), np.sin(t)], dtype=float) for t in thetas])

        for t in np.linspace(0.0, 2.0 * np.pi, 8, endpoint=False):
            p1 = c1 + r1 * np.array([np.cos(t), np.sin(t)], dtype=float)
            p2 = c2 + r2 * np.array([np.cos(t), np.sin(t)], dtype=float)
            add_unique([0.5 * (p1 + p2)])

        return seeds

    # line-family vs line-family
    if isinstance(fam_a, ParallelLineLeafFamily) and isinstance(fam_b, ParallelLineLeafFamily):
        y1 = float(lam_a)
        y2 = float(lam_b)
        if abs(y1 - y2) < 1e-9:
            xs = np.linspace(-3.0, 3.0, 11)
            add_unique([np.array([x, y1], dtype=float) for x in xs])
        return seeds

    # fallback
    add_unique([
        np.array([0.0, 0.0], dtype=float),
        np.array([1.0, 0.0], dtype=float),
        np.array([-1.0, 0.0], dtype=float),
        np.array([0.0, 1.0], dtype=float),
        np.array([0.0, -1.0], dtype=float),
    ])
    return seeds


def main():
    np.random.seed(7)

    # Bottom and top leaves
    line_family = ParallelLineLeafFamily("line_family", lambdas=[-1.0, 1.0])

    # Two competing bridge families
    left_bridge = SingleCircleLeafFamily(
        "left_bridge",
        center=(-0.9, 0.0),
        radii=[1.05],
    )
    right_bridge = SingleCircleLeafFamily(
        "right_bridge",
        center=(0.9, 0.0),
        radii=[1.05],
    )

    families = [line_family, left_bridge, right_bridge]

    # Start and goal chosen so left bridge should usually be more attractive
    start_x = np.array([-2.25, -1.0], dtype=float)
    goal_point = np.array([-2.25, 1.0], dtype=float)

    start_state = LeafState("line_family", -1.0, start_x)
    goal_family = line_family
    goal_lam = 1.0

    start_key = (start_state.family_name, start_state.lam)
    goal_key = (goal_family.name, goal_lam)

    graph = build_leaf_graph(
        families=families,
        project_newton=project_newton,
        seed_points_fn=informed_seed_points_fn,
        goal_point=goal_point,
        max_candidates_per_pair=3,
    )

    print("\n=== Example 19 graph adjacency ===")
    for node, edges in graph.adjacency.items():
        print(f"{node}: {len(edges)} edge(s)")
        for e in edges:
            print(
                f"    -> {e.dst}, cand={e.candidate_index}, "
                f"transition={np.round(e.transition_point, 4)}, score={e.score:.4f}"
            )

    route = shortest_leaf_route(graph, start=start_key, goal=goal_key)

    print("\n=== Example 19 chosen leaf-graph route ===")
    if route is None:
        print("No leaf route found.")
        return

    for i, edge in enumerate(route):
        print(
            f"  edge {i}: {edge.src} -> {edge.dst}, "
            f"cand={edge.candidate_index}, "
            f"transition={np.round(edge.transition_point, 4)}, score={edge.score:.4f}"
        )

    realized = realize_leaf_route(
        start_state=start_state,
        goal_point=goal_point,
        goal_family=goal_family,
        goal_lam=goal_lam,
        families=families,
        route_edges=route,
        constrained_interpolate=constrained_interpolate,
        step_size=0.08,
    )

    print("\n=== Example 19 realized route ===")
    print("success:", realized.success)
    print("message:", realized.message)
    print("num steps:", len(realized.steps))

    fig, ax = plt.subplots(figsize=(9, 8))
    plot_family(ax, line_family, color="lightblue")
    plot_family(ax, left_bridge, color="moccasin")
    plot_family(ax, right_bridge, color="honeydew")
    plot_graph_edges(ax, graph)
    plot_realized_result(ax, realized)

    ax.scatter(start_x[0], start_x[1], color="purple", s=95, label="start")
    ax.scatter(goal_point[0], goal_point[1], color="green", s=95, label="goal")

    ax.set_aspect("equal", adjustable="box")
    ax.set_title("Example 19: Two competing bridge families")
    ax.legend()
    ax.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig("example_19_two_competing_bridges.png", dpi=180)
    plt.show()


if __name__ == "__main__":
    main()