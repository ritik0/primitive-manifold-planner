from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import List
import csv
import json
import time
from pathlib import Path

import numpy as np

from primitive_manifold_planner.families.leaf_state import LeafState
from primitive_manifold_planner.planners.multimodal_component_planner import (
    MultimodalComponentPlanner,
    PlannerConfig,
)
from primitive_manifold_planner.projection import project_newton

from primitive_manifold_planner.examplesupport.planar2link import (
    Planar2LinkKinematics,
    component_of_q,
    wrap_q,
    torus_distance,
)
from primitive_manifold_planner.examplesupport.planar2link_families import (
    EndEffectorXFamily,
    EndEffectorYFamily,
    Joint2Family,
)
from primitive_manifold_planner.examplesupport.planar2link_helpers import (
    make_seed_points_fn,
    component_ids_for_family,
    compatible_components_for_leaf,
    allowed_unaware_pair,
    allowed_switch_pair,
)


@dataclass
class ExportRow:
    case_name: str
    planner_name: str

    start_q1: float
    start_q2: float
    goal_q1: float
    goal_q2: float
    start_component: str
    goal_component: str

    route_found: bool
    realization_success: bool
    success: bool

    num_edges: int
    path_length: float

    graph_nodes: int
    graph_edges: int
    transition_pairs: int
    transition_candidates: int

    selected_route_string: str
    nominal_candidate_indices: str
    realized_candidate_indices: str

    total_time_sec: float
    graph_build_time_sec: float
    route_search_time_sec: float
    realization_time_sec: float

    failure_stage: str
    failure_reason: str
    message: str


def build_cases():
    return [
        ("up_to_up", np.array([0.5 * np.pi, 0.5 * np.pi]), np.array([0.0, 0.5 * np.pi])),
        ("up_to_down", np.array([0.5 * np.pi, 0.5 * np.pi]), np.array([0.0, -0.5 * np.pi])),
        ("down_to_down", np.array([-0.5 * np.pi, -0.5 * np.pi]), np.array([0.0, -0.5 * np.pi])),
        ("down_to_up", np.array([-0.5 * np.pi, -0.5 * np.pi]), np.array([0.0, 0.5 * np.pi])),
    ]


def _route_string(route_edges, start_key) -> str:
    if route_edges is None:
        return ""
    seq = [f"{start_key[0]}[{start_key[1]}|{start_key[2]}]"]
    for e in route_edges:
        fam, lam, comp = e.dst
        seq.append(f"{fam}[{lam}|{comp}]")
    return " -> ".join(seq)


def _realized_candidate_indices(realization) -> List[int]:
    if realization is None:
        return []
    out: List[int] = []
    for step in realization.steps[:-1]:
        msg = step.message
        marker = "candidate_index="
        if marker in msg:
            tail = msg.split(marker, 1)[1]
            token = ""
            for ch in tail:
                if ch.isdigit():
                    token += ch
                else:
                    break
            if token:
                out.append(int(token))
    return out


def _timed_plan(
    planner: MultimodalComponentPlanner,
    start_state: LeafState,
    start_component: str,
    goal_family_name: str,
    goal_lam: float,
    goal_component: str,
    goal_q: np.ndarray,
):
    start_key = (
        start_state.family_name,
        float(start_state.lam),
        str(start_component),
    )
    goal_key = (
        str(goal_family_name),
        float(goal_lam),
        str(goal_component),
    )

    t0 = time.perf_counter()
    graph, transition_manager = planner.build_graph(goal_point=goal_q)
    t1 = time.perf_counter()

    route_edges = planner.search_route(
        graph=graph,
        start_key=start_key,
        goal_key=goal_key,
    )
    t2 = time.perf_counter()

    realization = None
    path_length = 0.0
    if route_edges is not None:
        realization = planner.realize_route(
            transition_manager=transition_manager,
            start_state=start_state,
            start_component=start_component,
            goal_q=goal_q,
            route_edges=route_edges,
        )
        t3 = time.perf_counter()
        if realization.success:
            for step in realization.steps:
                path = np.asarray(step.path)
                if len(path) >= 2:
                    path_length += float(np.sum(np.linalg.norm(np.diff(path, axis=0), axis=1)))
    else:
        t3 = time.perf_counter()

    diagnostics = planner._collect_graph_diagnostics(graph, transition_manager)
    diagnostics.start_key = start_key
    diagnostics.goal_key = goal_key
    diagnostics.selected_route_string = _route_string(route_edges, start_key)
    diagnostics.selected_candidate_indices = (
        [int(e.candidate_index) for e in route_edges] if route_edges is not None else []
    )

    if realization is None:
        diagnostics.failure_stage = "route_search"
        diagnostics.failure_reason = f"No component-aware route found from {start_key} to {goal_key}."
        success = False
        realization_success = False
        message = diagnostics.failure_reason
    else:
        diagnostics.realization_num_steps = len(realization.steps)
        diagnostics.realization_path_length = path_length
        if not realization.success:
            diagnostics.failure_stage = "realization"
            diagnostics.failure_reason = realization.message
        success = bool(realization.success)
        realization_success = bool(realization.success)
        message = realization.message

    return {
        "graph": graph,
        "transition_manager": transition_manager,
        "route_edges": route_edges,
        "realization": realization,
        "success": success,
        "route_found": route_edges is not None,
        "realization_success": realization_success,
        "path_length": path_length,
        "message": message,
        "diagnostics": diagnostics,
        "total_time_sec": t3 - t0,
        "graph_build_time_sec": t1 - t0,
        "route_search_time_sec": t2 - t1,
        "realization_time_sec": t3 - t2,
    }


def main():
    np.random.seed(7)

    out_dir = Path("outputs")
    out_dir.mkdir(parents=True, exist_ok=True)

    robot = Planar2LinkKinematics(l1=1.0, l2=1.0)

    config = PlannerConfig(
        max_candidates_per_pair=8,
        wrap_state_fn=wrap_q,
        state_distance_fn=torus_distance,
        local_planner_name="projection",
        local_planner_kwargs=dict(
            goal_tol=1e-3,
            max_iters=1200,
            projection_tol=1e-10,
            projection_max_iters=50,
            projection_damping=1.0,
        ),
        step_size=0.08,
    )

    seed_points_fn = make_seed_points_fn(robot)

    aware_families = [
        EndEffectorXFamily("left_x_family", robot, [-1.00]),
        EndEffectorYFamily("bridge_y_family", robot, [-1.00, 1.00]),
        EndEffectorXFamily("right_x_family", robot, [1.00]),
    ]
    aware_planner = MultimodalComponentPlanner(
        families=aware_families,
        project_newton=project_newton,
        seed_points_fn=seed_points_fn,
        component_ids_for_family_fn=component_ids_for_family,
        compatible_components_fn=compatible_components_for_leaf,
        allowed_family_pair_fn=allowed_unaware_pair,
        config=config,
    )

    switch_families = [
        EndEffectorXFamily("left_x_family", robot, [-1.00]),
        Joint2Family("switch_q2_family", [0.0]),
        EndEffectorYFamily("bridge_y_family", robot, [-1.00, 1.00]),
        EndEffectorXFamily("right_x_family", robot, [1.00]),
    ]
    switch_planner = MultimodalComponentPlanner(
        families=switch_families,
        project_newton=project_newton,
        seed_points_fn=seed_points_fn,
        component_ids_for_family_fn=component_ids_for_family,
        compatible_components_fn=compatible_components_for_leaf,
        allowed_family_pair_fn=allowed_switch_pair,
        config=config,
    )

    planners = [
        ("planner_v1_aware", aware_planner),
        ("planner_v1_aware+switch", switch_planner),
    ]

    rows: List[ExportRow] = []
    json_rows: List[dict] = []

    for case_name, start_q_raw, goal_q_raw in build_cases():
        start_q = wrap_q(start_q_raw)
        goal_q = wrap_q(goal_q_raw)

        start_state = LeafState("left_x_family", -1.0, start_q.copy())
        start_comp = component_of_q(start_q)
        goal_comp = component_of_q(goal_q)

        for planner_name, planner in planners:
            run = _timed_plan(
                planner=planner,
                start_state=start_state,
                start_component=start_comp,
                goal_family_name="right_x_family",
                goal_lam=1.0,
                goal_component=goal_comp,
                goal_q=goal_q.copy(),
            )

            diagnostics = run["diagnostics"]
            realization = run["realization"]

            row = ExportRow(
                case_name=case_name,
                planner_name=planner_name,
                start_q1=float(start_q[0]),
                start_q2=float(start_q[1]),
                goal_q1=float(goal_q[0]),
                goal_q2=float(goal_q[1]),
                start_component=start_comp,
                goal_component=goal_comp,
                route_found=bool(run["route_found"]),
                realization_success=bool(run["realization_success"]),
                success=bool(run["success"]),
                num_edges=len(run["route_edges"]) if run["route_edges"] is not None else 0,
                path_length=float(run["path_length"]),
                graph_nodes=int(diagnostics.num_graph_nodes),
                graph_edges=int(diagnostics.num_graph_edges),
                transition_pairs=int(diagnostics.num_transition_pairs),
                transition_candidates=int(diagnostics.num_transition_candidates),
                selected_route_string=str(diagnostics.selected_route_string),
                nominal_candidate_indices=json.dumps(list(diagnostics.selected_candidate_indices)),
                realized_candidate_indices=json.dumps(_realized_candidate_indices(realization)),
                total_time_sec=float(run["total_time_sec"]),
                graph_build_time_sec=float(run["graph_build_time_sec"]),
                route_search_time_sec=float(run["route_search_time_sec"]),
                realization_time_sec=float(run["realization_time_sec"]),
                failure_stage=str(diagnostics.failure_stage),
                failure_reason=str(diagnostics.failure_reason),
                message=str(run["message"]),
            )
            rows.append(row)

            json_rows.append(asdict(row))

    csv_path = out_dir / "example_54_planner_v1_benchmark_export.csv"
    json_path = out_dir / "example_54_planner_v1_benchmark_export.json"

    with csv_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(asdict(rows[0]).keys()))
        writer.writeheader()
        for row in rows:
            writer.writerow(asdict(row))

    with json_path.open("w", encoding="utf-8") as f:
        json.dump(json_rows, f, indent=2)

    print("\nExample 54: planner v1 benchmark export\n")
    for row in rows:
        print(
            f"{row.case_name:12s} | {row.planner_name:24s} | "
            f"route={str(row.route_found):5s} | "
            f"realized={str(row.realization_success):5s} | "
            f"edges={row.num_edges:d} | "
            f"length={row.path_length:7.4f} | "
            f"time={row.total_time_sec:.4f}s"
        )
        if row.selected_route_string:
            print(f"  route: {row.selected_route_string}")
        print(f"  nominal_candidate_indices: {row.nominal_candidate_indices}")
        print(f"  realized_candidate_indices: {row.realized_candidate_indices}")

    print(f"\nSaved CSV:  {csv_path}")
    print(f"Saved JSON: {json_path}")


if __name__ == "__main__":
    main()