from __future__ import annotations

from dataclasses import dataclass
from typing import List
import numpy as np

from primitive_manifold_planner.families.leaf_state import LeafState
from primitive_manifold_planner.planners.leaf_graph import build_leaf_graph, shortest_leaf_route
from primitive_manifold_planner.planners.realize_leaf_route import realize_leaf_route
from primitive_manifold_planner.planners.component_leaf_graph import (
    build_component_leaf_graph,
    shortest_component_route,
)
from primitive_manifold_planner.planners.realize_component_leaf_route import (
    realize_component_route,
)
from primitive_manifold_planner.projection import project_newton

from primitive_manifold_planner.examplesupport.planar2link import (
    Planar2LinkKinematics,
    component_of_q,
    wrap_q,
    torus_distance,
)
from primitive_manifold_planner.examplesupport.planar2link_families import (
    EndEffectorXFamily,
    EndEffectorYFamily,
    Joint2Family,
)
from primitive_manifold_planner.examplesupport.planar2link_helpers import (
    make_seed_points_fn,
    component_ids_for_family,
    compatible_components_for_leaf,
    allowed_unaware_pair,
    allowed_switch_pair,
)


@dataclass
class BenchmarkRow:
    case_name: str
    planner_name: str
    route_found: bool
    realization_success: bool
    route_string: str
    num_edges: int
    path_length: float
    message: str


def total_path_length_from_steps(steps) -> float:
    total = 0.0
    for step in steps:
        path = np.asarray(step.path)
        if len(path) >= 2:
            total += float(np.sum(np.linalg.norm(np.diff(path, axis=0), axis=1)))
    return total


def build_cases():
    return [
        ("up_to_up",   np.array([0.5*np.pi,  0.5*np.pi]), np.array([0.0,  0.5*np.pi])),
        ("up_to_down", np.array([0.5*np.pi,  0.5*np.pi]), np.array([0.0, -0.5*np.pi])),
        ("down_to_down", np.array([-0.5*np.pi, -0.5*np.pi]), np.array([0.0, -0.5*np.pi])),
        ("down_to_up", np.array([-0.5*np.pi, -0.5*np.pi]), np.array([0.0,  0.5*np.pi])),
    ]


def main():
    np.random.seed(7)

    robot = Planar2LinkKinematics(l1=1.0, l2=1.0)
    seed_points_fn = make_seed_points_fn(robot)

    unaware_families = [
        EndEffectorXFamily("left_x_family", robot, [-1.00]),
        EndEffectorYFamily("bridge_y_family", robot, [-1.00, 1.00]),
        EndEffectorXFamily("right_x_family", robot, [1.00]),
    ]

    switch_families = [
        EndEffectorXFamily("left_x_family", robot, [-1.00]),
        Joint2Family("switch_q2_family", [0.0]),
        EndEffectorYFamily("bridge_y_family", robot, [-1.00, 1.00]),
        EndEffectorXFamily("right_x_family", robot, [1.00]),
    ]

    rows: List[BenchmarkRow] = []

    for case_name, start_q_raw, goal_q_raw in build_cases():
        start_q = wrap_q(start_q_raw)
        goal_q = wrap_q(goal_q_raw)

        start_state = LeafState("left_x_family", -1.0, start_q.copy())
        start_comp = component_of_q(start_q)
        goal_comp = component_of_q(goal_q)

        # ----------------------------------------------------
        # Unaware
        # ----------------------------------------------------
        unaware_graph = build_leaf_graph(
            families=unaware_families,
            project_newton=project_newton,
            seed_points_fn=seed_points_fn,
            goal_point=goal_q.copy(),
            max_candidates_per_pair=6,
        )
        unaware_graph.adjacency = {
            src: [e for e in edges if allowed_unaware_pair(e.src[0], e.dst[0])]
            for src, edges in unaware_graph.adjacency.items()
        }

        unaware_route = shortest_leaf_route(
            graph=unaware_graph,
            start=("left_x_family", -1.0),
            goal=("right_x_family", 1.0),
            edge_cost_fn=lambda e: 1.0 + e.score,
        )

        if unaware_route is None:
            rows.append(
                BenchmarkRow(
                    case_name=case_name,
                    planner_name="unaware",
                    route_found=False,
                    realization_success=False,
                    route_string="",
                    num_edges=0,
                    path_length=0.0,
                    message="No route found.",
                )
            )
        else:
            route_string = " -> ".join(
                ["left_x_family[-1.0]"] + [f"{e.dst[0]}[{e.dst[1]}]" for e in unaware_route]
            )
            realized = realize_leaf_route(
                start_state=start_state,
                goal_point=goal_q.copy(),
                goal_family={f.name: f for f in unaware_families}["right_x_family"],
                goal_lam=1.0,
                families=unaware_families,
                route_edges=unaware_route,
                step_size=0.08,
                local_planner_name="projection",
                local_planner_kwargs=dict(
                    goal_tol=1e-3,
                    max_iters=900,
                    projection_tol=1e-10,
                    projection_max_iters=50,
                    projection_damping=1.0,
                ),
            )
            rows.append(
                BenchmarkRow(
                    case_name=case_name,
                    planner_name="unaware",
                    route_found=True,
                    realization_success=bool(realized.success),
                    route_string=route_string,
                    num_edges=len(unaware_route),
                    path_length=total_path_length_from_steps(realized.steps) if realized.success else 0.0,
                    message=realized.message,
                )
            )

        # ----------------------------------------------------
        # Aware
        # ----------------------------------------------------
        aware_graph = build_component_leaf_graph(
            families=unaware_families,
            project_newton=project_newton,
            seed_points_fn=seed_points_fn,
            goal_point=goal_q.copy(),
            component_ids_for_family_fn=component_ids_for_family,
            compatible_components_fn=compatible_components_for_leaf,
            allowed_family_pair_fn=allowed_unaware_pair,
            max_candidates_per_pair=6,
        )

        aware_route = shortest_component_route(
            graph=aware_graph,
            start=("left_x_family", -1.0, start_comp),
            goal=("right_x_family", 1.0, goal_comp),
        )

        if aware_route is None:
            rows.append(
                BenchmarkRow(
                    case_name=case_name,
                    planner_name="aware",
                    route_found=False,
                    realization_success=False,
                    route_string="",
                    num_edges=0,
                    path_length=0.0,
                    message="No route found.",
                )
            )
        else:
            route_string = " -> ".join(
                [f"left_x_family[-1.0|{start_comp}]"] +
                [f"{e.dst[0]}[{e.dst[1]}|{e.dst[2]}]" for e in aware_route]
            )
            rows.append(
                BenchmarkRow(
                    case_name=case_name,
                    planner_name="aware",
                    route_found=True,
                    realization_success=False,
                    route_string=route_string,
                    num_edges=len(aware_route),
                    path_length=0.0,
                    message="Route exists in aware graph; no explicit switch connector used here.",
                )
            )

        # ----------------------------------------------------
        # Aware + switch
        # ----------------------------------------------------
        switch_graph = build_component_leaf_graph(
            families=switch_families,
            project_newton=project_newton,
            seed_points_fn=seed_points_fn,
            goal_point=goal_q.copy(),
            component_ids_for_family_fn=component_ids_for_family,
            compatible_components_fn=compatible_components_for_leaf,
            allowed_family_pair_fn=allowed_switch_pair,
            max_candidates_per_pair=6,
        )

        switch_route = shortest_component_route(
            graph=switch_graph,
            start=("left_x_family", -1.0, start_comp),
            goal=("right_x_family", 1.0, goal_comp),
        )

        if switch_route is None:
            rows.append(
                BenchmarkRow(
                    case_name=case_name,
                    planner_name="aware+switch",
                    route_found=False,
                    realization_success=False,
                    route_string="",
                    num_edges=0,
                    path_length=0.0,
                    message="No route found.",
                )
            )
        else:
            route_string = " -> ".join(
                [f"left_x_family[-1.0|{start_comp}]"] +
                [f"{e.dst[0]}[{e.dst[1]}|{e.dst[2]}]" for e in switch_route]
            )
            realized = realize_component_route(
                graph=switch_graph,
                start_state=start_state,
                start_component=start_comp,
                goal_q=goal_q.copy(),
                families=switch_families,
                route_edges=switch_route,
                step_size=0.08,
                local_planner_name="projection",
                local_planner_kwargs=dict(
                    goal_tol=1e-3,
                    max_iters=1200,
                    projection_tol=1e-10,
                    projection_max_iters=50,
                    projection_damping=1.0,
                ),
                wrap_state_fn=wrap_q,
                state_distance_fn=torus_distance,
            )
            rows.append(
                BenchmarkRow(
                    case_name=case_name,
                    planner_name="aware+switch",
                    route_found=True,
                    realization_success=bool(realized.success),
                    route_string=route_string,
                    num_edges=len(switch_route),
                    path_length=total_path_length_from_steps(realized.steps) if realized.success else 0.0,
                    message=realized.message,
                )
            )

    print("\nExample 45: small branch benchmark\n")
    for r in rows:
        print(
            f"{r.case_name:12s} | {r.planner_name:12s} | "
            f"route={str(r.route_found):5s} | "
            f"realized={str(r.realization_success):5s} | "
            f"edges={r.num_edges:d} | "
            f"length={r.path_length:7.4f} | "
            f"{r.message}"
        )
        if r.route_string:
            print(f"  route: {r.route_string}")


if __name__ == "__main__":
    main()