from __future__ import annotations

import numpy as np

from primitive_manifold_planner.families.base import ManifoldFamily
from primitive_manifold_planner.families.leaf_state import LeafState
from primitive_manifold_planner.manifolds import LineManifold, CircleManifold
from primitive_manifold_planner.planning.local import constrained_interpolate
from primitive_manifold_planner.projection import project_newton
from primitive_manifold_planner.benchmarks.runner import (
    BenchmarkCase,
    run_benchmark_case,
    save_results_csv,
)


class ParallelLineLeafFamily(ManifoldFamily):
    def __init__(self, name: str, lambdas=None):
        super().__init__(name)
        self._lambdas = lambdas if lambdas is not None else [-1.0, 1.0]

    def manifold(self, lam):
        return LineManifold(
            point=np.array([0.0, lam], dtype=float),
            normal=np.array([0.0, 1.0], dtype=float),
            name=f"{self.name}_lam_{lam}",
        )

    def sample_lambdas(self, context=None):
        return list(self._lambdas)


class SingleCircleLeafFamily(ManifoldFamily):
    def __init__(self, name: str, center=(0.0, 0.0), radii=None):
        super().__init__(name)
        self.center = np.array(center, dtype=float)
        self._radii = radii if radii is not None else [1.05]

    def manifold(self, lam):
        return CircleManifold(
            center=self.center,
            radius=float(lam),
            name=f"{self.name}_r_{lam}",
        )

    def sample_lambdas(self, context=None):
        return list(self._radii)


def informed_seed_points_fn(fam_a, lam_a, fam_b, lam_b):
    seeds = []

    def add_unique(arr):
        for s in arr:
            if not any(np.linalg.norm(s - u) < 1e-8 for u in seeds):
                seeds.append(s)

    if isinstance(fam_a, ParallelLineLeafFamily) and isinstance(fam_b, SingleCircleLeafFamily):
        y = float(lam_a)
        c = fam_b.center
        r = float(lam_b)

        dy = y - c[1]
        if abs(dy) <= r + 1e-9:
            dx_sq = max(r * r - dy * dy, 0.0)
            dx = np.sqrt(dx_sq)
            add_unique([
                np.array([c[0] + dx, y], dtype=float),
                np.array([c[0] - dx, y], dtype=float),
            ])

        xs = np.linspace(c[0] - 1.5 * r, c[0] + 1.5 * r, 11)
        add_unique([np.array([x, y], dtype=float) for x in xs])

        thetas = np.linspace(0.0, 2.0 * np.pi, 14, endpoint=False)
        add_unique([c + r * np.array([np.cos(t), np.sin(t)], dtype=float) for t in thetas])
        return seeds

    if isinstance(fam_a, SingleCircleLeafFamily) and isinstance(fam_b, ParallelLineLeafFamily):
        return informed_seed_points_fn(fam_b, lam_b, fam_a, lam_a)

    if isinstance(fam_a, SingleCircleLeafFamily) and isinstance(fam_b, SingleCircleLeafFamily):
        c1, r1 = fam_a.center, float(lam_a)
        c2, r2 = fam_b.center, float(lam_b)

        thetas = np.linspace(0.0, 2.0 * np.pi, 16, endpoint=False)
        add_unique([c1 + r1 * np.array([np.cos(t), np.sin(t)], dtype=float) for t in thetas])
        add_unique([c2 + r2 * np.array([np.cos(t), np.sin(t)], dtype=float) for t in thetas])

        for t in np.linspace(0.0, 2.0 * np.pi, 8, endpoint=False):
            p1 = c1 + r1 * np.array([np.cos(t), np.sin(t)], dtype=float)
            p2 = c2 + r2 * np.array([np.cos(t), np.sin(t)], dtype=float)
            add_unique([0.5 * (p1 + p2)])
        return seeds

    add_unique([
        np.array([0.0, 0.0], dtype=float),
        np.array([1.0, 0.0], dtype=float),
        np.array([-1.0, 0.0], dtype=float),
        np.array([0.0, 1.0], dtype=float),
        np.array([0.0, -1.0], dtype=float),
    ])
    return seeds


def main():
    np.random.seed(7)

    line_family = ParallelLineLeafFamily("line_family", lambdas=[-1.0, 1.0])
    left_bridge = SingleCircleLeafFamily("left_bridge", center=(-0.9, 0.0), radii=[1.05])
    right_bridge = SingleCircleLeafFamily("right_bridge", center=(0.9, 0.0), radii=[1.05])

    families = [line_family, left_bridge, right_bridge]

    start_state = LeafState("line_family", -1.0, np.array([0.0, -1.0], dtype=float))

    cases = [
        BenchmarkCase(
            name="left_goal_prefers_left_bridge",
            families=families,
            start_state=start_state,
            goal_point=np.array([-2.25, 1.0], dtype=float),
            goal_family_name="line_family",
            goal_lam=1.0,
            seed_points_fn=informed_seed_points_fn,
        ),
        BenchmarkCase(
            name="right_goal_prefers_right_bridge",
            families=families,
            start_state=start_state,
            goal_point=np.array([2.25, 1.0], dtype=float),
            goal_family_name="line_family",
            goal_lam=1.0,
            seed_points_fn=informed_seed_points_fn,
        ),
        BenchmarkCase(
            name="center_goal_can_choose_either",
            families=families,
            start_state=start_state,
            goal_point=np.array([0.0, 1.0], dtype=float),
            goal_family_name="line_family",
            goal_lam=1.0,
            seed_points_fn=informed_seed_points_fn,
        ),
    ]

    results = []
    print("\n=== Running benchmark cases ===")
    for case in cases:
        result = run_benchmark_case(
            case=case,
            project_newton=project_newton,
            constrained_interpolate=constrained_interpolate,
            max_candidates_per_pair=3,
        )
        results.append(result)

        print(f"\nCase: {result.case_name}")
        print(f"  success            : {result.success}")
        print(f"  route_found        : {result.route_found}")
        print(f"  route_num_edges    : {result.route_num_edges}")
        print(f"  realized_num_steps : {result.realized_num_steps}")
        print(f"  leaf_sequence      : {result.chosen_leaf_sequence}")
        print(f"  transitions        : {result.transition_points}")
        print(f"  path_length        : {result.path_length:.4f}")
        print(f"  runtime_sec        : {result.runtime_sec:.4f}")
        print(f"  message            : {result.message}")

    out_csv = "outputs/benchmark_results/example_23_benchmark_summary.csv"
    save_results_csv(results, out_csv)
    print(f"\nSaved CSV summary to: {out_csv}")


if __name__ == "__main__":
    main()