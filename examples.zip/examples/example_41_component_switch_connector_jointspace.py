from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Tuple, Optional
import heapq
import numpy as np
import matplotlib.pyplot as plt

from primitive_manifold_planner.families.leaf_state import LeafState
from primitive_manifold_planner.planning.local import run_local_planner
from primitive_manifold_planner.projection import project_newton
from primitive_manifold_planner.transitions.leaf_transition import find_leaf_transition


# ============================================================
# Simple 2-link planar arm kinematics
# ============================================================

class Planar2LinkKinematics:
    def __init__(self, l1: float = 1.0, l2: float = 1.0):
        self.l1 = float(l1)
        self.l2 = float(l2)

    def fk(self, q: np.ndarray) -> np.ndarray:
        q = np.asarray(q, dtype=float)
        q1, q2 = q
        x = self.l1 * np.cos(q1) + self.l2 * np.cos(q1 + q2)
        y = self.l1 * np.sin(q1) + self.l2 * np.sin(q1 + q2)
        return np.array([x, y], dtype=float)

    def jacobian_xy(self, q: np.ndarray) -> np.ndarray:
        q = np.asarray(q, dtype=float)
        q1, q2 = q
        dx_dq1 = -self.l1 * np.sin(q1) - self.l2 * np.sin(q1 + q2)
        dx_dq2 = -self.l2 * np.sin(q1 + q2)
        dy_dq1 = self.l1 * np.cos(q1) + self.l2 * np.cos(q1 + q2)
        dy_dq2 = self.l2 * np.cos(q1 + q2)
        return np.array(
            [
                [dx_dq1, dx_dq2],
                [dy_dq1, dy_dq2],
            ],
            dtype=float,
        )


# ============================================================
# Implicit task manifolds in joint space
# ============================================================

class EndEffectorXManifold:
    def __init__(self, robot: Planar2LinkKinematics, target_x: float, name: str):
        self.robot = robot
        self.target_x = float(target_x)
        self.name = name

    def _coerce_point(self, q: np.ndarray) -> np.ndarray:
        q = np.asarray(q, dtype=float).reshape(-1)
        return q[:2].copy()

    def residual(self, q: np.ndarray) -> np.ndarray:
        q = self._coerce_point(q)
        return np.array([self.robot.fk(q)[0] - self.target_x], dtype=float)

    def jacobian(self, q: np.ndarray) -> np.ndarray:
        q = self._coerce_point(q)
        return self.robot.jacobian_xy(q)[0:1, :]

    def is_valid(self, q: np.ndarray, tol: float = 1e-6) -> bool:
        return float(np.linalg.norm(self.residual(q))) <= tol


class EndEffectorYManifold:
    def __init__(self, robot: Planar2LinkKinematics, target_y: float, name: str):
        self.robot = robot
        self.target_y = float(target_y)
        self.name = name

    def _coerce_point(self, q: np.ndarray) -> np.ndarray:
        q = np.asarray(q, dtype=float).reshape(-1)
        return q[:2].copy()

    def residual(self, q: np.ndarray) -> np.ndarray:
        q = self._coerce_point(q)
        return np.array([self.robot.fk(q)[1] - self.target_y], dtype=float)

    def jacobian(self, q: np.ndarray) -> np.ndarray:
        q = self._coerce_point(q)
        return self.robot.jacobian_xy(q)[1:2, :]

    def is_valid(self, q: np.ndarray, tol: float = 1e-6) -> bool:
        return float(np.linalg.norm(self.residual(q))) <= tol


class Joint2Manifold:
    """
    Connector family: q2 = lambda.
    For Example 41 we use lambda = 0, which is the branch-switch set.
    """
    def __init__(self, target_q2: float, name: str):
        self.target_q2 = float(target_q2)
        self.name = name

    def _coerce_point(self, q: np.ndarray) -> np.ndarray:
        q = np.asarray(q, dtype=float).reshape(-1)
        return q[:2].copy()

    def residual(self, q: np.ndarray) -> np.ndarray:
        q = self._coerce_point(q)
        return np.array([q[1] - self.target_q2], dtype=float)

    def jacobian(self, q: np.ndarray) -> np.ndarray:
        _ = self._coerce_point(q)
        return np.array([[0.0, 1.0]], dtype=float)

    def is_valid(self, q: np.ndarray, tol: float = 1e-6) -> bool:
        return float(np.linalg.norm(self.residual(q))) <= tol


# ============================================================
# Thin family wrappers
# ============================================================

class BenchmarkLeafFamily:
    def __init__(self, name: str, lambdas: List[float]):
        self.name = name
        self._lambdas = [float(v) for v in lambdas]

    def manifold(self, lam: float):
        raise NotImplementedError

    def sample_lambdas(self, context=None):
        return list(self._lambdas)

    def lambda_distance(self, lam_a, lam_b) -> float:
        return abs(float(lam_a) - float(lam_b))


class EndEffectorXFamily(BenchmarkLeafFamily):
    def __init__(self, name: str, robot: Planar2LinkKinematics, lambdas: List[float]):
        super().__init__(name=name, lambdas=lambdas)
        self.robot = robot

    def manifold(self, lam: float):
        return EndEffectorXManifold(
            robot=self.robot,
            target_x=float(lam),
            name=f"{self.name}_lambda_{lam:g}",
        )


class EndEffectorYFamily(BenchmarkLeafFamily):
    def __init__(self, name: str, robot: Planar2LinkKinematics, lambdas: List[float]):
        super().__init__(name=name, lambdas=lambdas)
        self.robot = robot

    def manifold(self, lam: float):
        return EndEffectorYManifold(
            robot=self.robot,
            target_y=float(lam),
            name=f"{self.name}_lambda_{lam:g}",
        )


class Joint2Family(BenchmarkLeafFamily):
    def manifold(self, lam: float):
        return Joint2Manifold(
            target_q2=float(lam),
            name=f"{self.name}_lambda_{lam:g}",
        )


# ============================================================
# Component-aware graph with explicit switch connector
# ============================================================

ComponentKey = Tuple[str, float, str]


@dataclass
class ComponentEdge:
    src: ComponentKey
    dst: ComponentKey
    transition_point: np.ndarray
    score: float
    candidate_index: int = 0


@dataclass
class ComponentGraph:
    adjacency: Dict[ComponentKey, List[ComponentEdge]] = field(default_factory=dict)

    def add_node(self, node: ComponentKey) -> None:
        self.adjacency.setdefault(node, [])

    def add_edge(self, edge: ComponentEdge) -> None:
        self.add_node(edge.src)
        self.add_node(edge.dst)
        self.adjacency[edge.src].append(edge)

    def neighbors(self, node: ComponentKey) -> List[ComponentEdge]:
        return self.adjacency.get(node, [])


@dataclass
class ComponentRouteStep:
    family_name: str
    lam: float
    component_id: str
    path: np.ndarray
    transition_point: Optional[np.ndarray] = None
    message: str = ""


@dataclass
class ComponentRouteResult:
    success: bool
    steps: List[ComponentRouteStep]
    final_state: Optional[LeafState]
    message: str = ""


# ============================================================
# Helpers
# ============================================================

def wrap_to_pi(angle: float) -> float:
    return (float(angle) + np.pi) % (2.0 * np.pi) - np.pi


def wrap_q(q: np.ndarray) -> np.ndarray:
    q = np.asarray(q, dtype=float).copy()
    q[0] = wrap_to_pi(q[0])
    q[1] = wrap_to_pi(q[1])
    return q


def torus_diff(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    a = np.asarray(a, dtype=float)
    b = np.asarray(b, dtype=float)
    d = a - b
    d[0] = wrap_to_pi(d[0])
    d[1] = wrap_to_pi(d[1])
    return d


def torus_distance(a: np.ndarray, b: np.ndarray) -> float:
    return float(np.linalg.norm(torus_diff(a, b)))


def component_of_q(q: np.ndarray) -> str:
    q = np.asarray(q, dtype=float)
    q2 = float(wrap_to_pi(q[1]))
    if abs(q2) < 1e-6:
        return "switch"
    return "up" if q2 > 0.0 else "down"


def compatible_component(node_comp: str, transition_q: np.ndarray) -> bool:
    q_comp = component_of_q(transition_q)
    if node_comp == "switch":
        return q_comp == "switch"
    if q_comp == "switch":
        return True
    return node_comp == q_comp


def two_link_ik_solutions(robot, x: float, y: float):
    l1 = float(robot.l1)
    l2 = float(robot.l2)

    r2 = x * x + y * y
    cos_q2 = (r2 - l1 * l1 - l2 * l2) / (2.0 * l1 * l2)

    if cos_q2 < -1.0 - 1e-10 or cos_q2 > 1.0 + 1e-10:
        return []

    cos_q2 = np.clip(cos_q2, -1.0, 1.0)
    q2_candidates = [np.arccos(cos_q2), -np.arccos(cos_q2)]

    sols = []
    for q2 in q2_candidates:
        k1 = l1 + l2 * np.cos(q2)
        k2 = l2 * np.sin(q2)
        q1 = np.arctan2(y, x) - np.arctan2(k2, k1)

        q1 = wrap_to_pi(q1)
        q2 = wrap_to_pi(q2)
        q = np.array([q1, q2], dtype=float)

        duplicate = False
        for s in sols:
            if np.linalg.norm(torus_diff(q, s)) < 1e-8:
                duplicate = True
                break
        if not duplicate:
            sols.append(q)

    return sols


def allowed_family_pair(fam_a_name: str, fam_b_name: str) -> bool:
    allowed = {
        ("left_x_family", "switch_q2_family"),
        ("switch_q2_family", "left_x_family"),
        ("switch_q2_family", "bridge_y_family"),
        ("bridge_y_family", "switch_q2_family"),
        ("bridge_y_family", "right_x_family"),
        ("right_x_family", "bridge_y_family"),
    }
    return (fam_a_name, fam_b_name) in allowed


def seed_points_fn(fam_a, lam_a, fam_b, lam_b, robot):
    seeds = []

    vals = np.linspace(-np.pi, np.pi, 9)
    for q1 in vals:
        for q2 in vals:
            seeds.append(np.array([q1, q2], dtype=float))

    def add_xy_ik_seeds(x_target: float, y_target: float):
        sols = two_link_ik_solutions(robot, x_target, y_target)
        eps = 0.05
        for q in sols:
            seeds.append(q.copy())
            seeds.append(q + np.array([eps, 0.0]))
            seeds.append(q + np.array([-eps, 0.0]))
            seeds.append(q + np.array([0.0, eps]))
            seeds.append(q + np.array([0.0, -eps]))

    def add_q2_zero_x_seeds(x_target: float):
        # Intersections of q2=0 with x(q)=x_target: x = 2 cos(q1)
        if abs(x_target / 2.0) <= 1.0 + 1e-10:
            c = np.clip(x_target / 2.0, -1.0, 1.0)
            q1a = np.arccos(c)
            q1b = -np.arccos(c)
            for q1 in [q1a, q1b]:
                q = np.array([wrap_to_pi(q1), 0.0], dtype=float)
                seeds.append(q.copy())
                seeds.append(q + np.array([0.05, 0.02]))
                seeds.append(q + np.array([-0.05, -0.02]))

    def add_q2_zero_y_seeds(y_target: float):
        # Intersections of q2=0 with y(q)=y_target: y = 2 sin(q1)
        if abs(y_target / 2.0) <= 1.0 + 1e-10:
            s = np.clip(y_target / 2.0, -1.0, 1.0)
            q1a = np.arcsin(s)
            q1b = np.pi - q1a
            for q1 in [q1a, q1b]:
                q = np.array([wrap_to_pi(q1), 0.0], dtype=float)
                seeds.append(q.copy())
                seeds.append(q + np.array([0.05, 0.02]))
                seeds.append(q + np.array([-0.05, -0.02]))

    if fam_a.name.endswith("x_family") and fam_b.name.endswith("y_family"):
        add_xy_ik_seeds(float(lam_a), float(lam_b))
    if fam_b.name.endswith("x_family") and fam_a.name.endswith("y_family"):
        add_xy_ik_seeds(float(lam_b), float(lam_a))

    if fam_a.name.endswith("x_family") and fam_b.name == "switch_q2_family":
        add_q2_zero_x_seeds(float(lam_a))
    if fam_b.name.endswith("x_family") and fam_a.name == "switch_q2_family":
        add_q2_zero_x_seeds(float(lam_b))

    if fam_a.name.endswith("y_family") and fam_b.name == "switch_q2_family":
        add_q2_zero_y_seeds(float(lam_a))
    if fam_b.name.endswith("y_family") and fam_a.name == "switch_q2_family":
        add_q2_zero_y_seeds(float(lam_b))

    uniq = []
    for s in seeds:
        s = wrap_q(s)
        if not any(np.linalg.norm(torus_diff(s, t)) < 1e-8 for t in uniq):
            uniq.append(s)

    return uniq


def build_component_switch_graph(
    families,
    robot,
    goal_point: np.ndarray,
    max_candidates_per_pair: int = 6,
):
    graph = ComponentGraph()

    family_nodes = []
    for fam in families:
        for lam in fam.sample_lambdas():
            family_nodes.append((fam, lam))

    for fam, lam in family_nodes:
        if fam.name == "switch_q2_family":
            graph.add_node((fam.name, float(lam), "switch"))
        else:
            graph.add_node((fam.name, float(lam), "up"))
            graph.add_node((fam.name, float(lam), "down"))

    for i, (fam_a, lam_a) in enumerate(family_nodes):
        for j in range(i + 1, len(family_nodes)):
            fam_b, lam_b = family_nodes[j]

            if not allowed_family_pair(fam_a.name, fam_b.name):
                continue

            result = find_leaf_transition(
                source_family=fam_a,
                source_lam=lam_a,
                target_family=fam_b,
                target_lam=lam_b,
                seeds=seed_points_fn(fam_a, lam_a, fam_b, lam_b, robot),
                project_newton=project_newton,
                goal=goal_point,
            )

            if not result.success:
                continue

            kept = result.candidates[:max_candidates_per_pair]
            for k, cand in enumerate(kept):
                q_cand = wrap_q(cand.x)
                possible_src = []
                possible_dst = []

                if fam_a.name == "switch_q2_family":
                    possible_src = [("switch_q2_family", float(lam_a), "switch")]
                else:
                    for comp in ["up", "down"]:
                        if compatible_component(comp, q_cand):
                            possible_src.append((fam_a.name, float(lam_a), comp))

                if fam_b.name == "switch_q2_family":
                    possible_dst = [("switch_q2_family", float(lam_b), "switch")]
                else:
                    for comp in ["up", "down"]:
                        if compatible_component(comp, q_cand):
                            possible_dst.append((fam_b.name, float(lam_b), comp))

                for src in possible_src:
                    for dst in possible_dst:
                        graph.add_edge(
                            ComponentEdge(
                                src=src,
                                dst=dst,
                                transition_point=q_cand.copy(),
                                score=float(cand.score),
                                candidate_index=k,
                            )
                        )
                        graph.add_edge(
                            ComponentEdge(
                                src=dst,
                                dst=src,
                                transition_point=q_cand.copy(),
                                score=float(cand.score),
                                candidate_index=k,
                            )
                        )

    return graph


def edge_cost_fn(edge: ComponentEdge) -> float:
    return 1.0 + edge.score


def shortest_component_route(
    graph: ComponentGraph,
    start: ComponentKey,
    goal: ComponentKey,
):
    pq = []
    heapq.heappush(pq, (0.0, start))

    dist = {start: 0.0}
    parent = {}
    parent_edge = {}

    while pq:
        g_cost, node = heapq.heappop(pq)

        if node == goal:
            break

        if g_cost > dist.get(node, float("inf")):
            continue

        for edge in graph.neighbors(node):
            step_cost = float(edge_cost_fn(edge))
            new_cost = g_cost + step_cost

            if new_cost < dist.get(edge.dst, float("inf")):
                dist[edge.dst] = new_cost
                parent[edge.dst] = node
                parent_edge[edge.dst] = edge
                heapq.heappush(pq, (new_cost, edge.dst))

    if start == goal:
        return []

    if goal not in parent_edge:
        return None

    route = []
    cur = goal
    while cur != start:
        edge = parent_edge[cur]
        route.append(edge)
        cur = parent[cur]
    route.reverse()
    return route


def node_sequence_from_route(start_key: ComponentKey, route_edges: List[ComponentEdge]) -> List[ComponentKey]:
    seq = [start_key]
    for e in route_edges:
        seq.append(e.dst)
    return seq


def select_reachable_edge_between_nodes(
    graph: ComponentGraph,
    src_node: ComponentKey,
    dst_node: ComponentKey,
    current_x: np.ndarray,
    families,
    step_size: float,
    local_planner_name: str,
    local_planner_kwargs: dict,
    downstream_hint: Optional[np.ndarray] = None,
):
    family_map = {f.name: f for f in families}
    current_family = family_map[src_node[0]]
    current_leaf = current_family.manifold(src_node[1])

    dst_family = family_map[dst_node[0]]
    dst_leaf = dst_family.manifold(dst_node[1])

    candidates = [e for e in graph.neighbors(src_node) if e.dst == dst_node]
    if len(candidates) == 0:
        return None, None

    def rank_key(edge: ComponentEdge):
        score = torus_distance(edge.transition_point, current_x)
        if downstream_hint is not None:
            score += 0.5 * torus_distance(edge.transition_point, downstream_hint)
        score += 0.5 * float(edge.score)
        return score

    candidates.sort(key=rank_key)

    for edge in candidates:
        q_edge = wrap_q(edge.transition_point)

        seg = run_local_planner(
            manifold=current_leaf,
            x_start=wrap_q(current_x),
            x_goal=q_edge,
            planner_name=local_planner_name,
            step_size=step_size,
            **local_planner_kwargs,
        )
        if not seg.success or len(seg.path) == 0:
            continue

        if downstream_hint is not None:
            downstream_trial = run_local_planner(
                manifold=dst_leaf,
                x_start=q_edge,
                x_goal=wrap_q(downstream_hint),
                planner_name=local_planner_name,
                step_size=step_size,
                **local_planner_kwargs,
            )
            if not downstream_trial.success or len(downstream_trial.path) == 0:
                continue

        return edge, seg

    return None, None


def realize_component_route_with_reachable_edge_selection(
    graph: ComponentGraph,
    start_state: LeafState,
    start_component: str,
    goal_q: np.ndarray,
    families,
    route_edges,
    step_size: float = 0.08,
    local_planner_name: str = "projection",
    local_planner_kwargs: Optional[dict] = None,
):
    local_planner_kwargs = dict(local_planner_kwargs or {})
    node_seq = node_sequence_from_route(
        (start_state.family_name, float(start_state.lam), start_component),
        route_edges,
    )

    current = LeafState(start_state.family_name, start_state.lam, wrap_q(start_state.x))
    current_component = start_component
    steps: List[ComponentRouteStep] = []

    nominal_edges = {(e.src, e.dst): e for e in route_edges}

    for i in range(len(node_seq) - 1):
        src_node = node_seq[i]
        dst_node = node_seq[i + 1]

        if i + 2 < len(node_seq):
            next_dst = node_seq[i + 2]
            nominal_next_edge = nominal_edges.get((dst_node, next_dst), None)
            downstream_hint = None if nominal_next_edge is None else wrap_q(nominal_next_edge.transition_point)
        else:
            downstream_hint = wrap_q(goal_q)

        chosen_edge, seg = select_reachable_edge_between_nodes(
            graph=graph,
            src_node=src_node,
            dst_node=dst_node,
            current_x=current.x,
            families=families,
            step_size=step_size,
            local_planner_name=local_planner_name,
            local_planner_kwargs=local_planner_kwargs,
            downstream_hint=downstream_hint,
        )

        if chosen_edge is None or seg is None:
            return ComponentRouteResult(
                success=False,
                steps=steps,
                final_state=current,
                message=(
                    f"Failed finding reachable exact transition from {src_node} to {dst_node} "
                    f"given current_x={np.round(current.x, 4)}."
                ),
            )

        q_edge = wrap_q(chosen_edge.transition_point)

        steps.append(
            ComponentRouteStep(
                family_name=current.family_name,
                lam=float(current.lam),
                component_id=current_component,
                path=np.asarray(seg.path),
                transition_point=q_edge.copy(),
                message=(
                    f"Used reachable candidate_index={chosen_edge.candidate_index} "
                    f"for node pair {src_node} -> {dst_node}."
                ),
            )
        )

        dst_family, dst_lam, dst_comp = chosen_edge.dst
        current = LeafState(dst_family, float(dst_lam), q_edge.copy())
        current_component = dst_comp

    family_map = {f.name: f for f in families}
    final_family = family_map[current.family_name]
    final_leaf = final_family.manifold(current.lam)

    final_seg = run_local_planner(
        manifold=final_leaf,
        x_start=wrap_q(current.x),
        x_goal=wrap_q(goal_q),
        planner_name=local_planner_name,
        step_size=step_size,
        **local_planner_kwargs,
    )
    if not final_seg.success:
        return ComponentRouteResult(
            success=False,
            steps=steps,
            final_state=current,
            message=f"Failed final motion on goal leaf: {final_seg.message}",
        )

    steps.append(
        ComponentRouteStep(
            family_name=current.family_name,
            lam=float(current.lam),
            component_id=current_component,
            path=np.asarray(final_seg.path),
            transition_point=None,
            message="Final goal segment.",
        )
    )

    return ComponentRouteResult(
        success=True,
        steps=steps,
        final_state=LeafState(current.family_name, current.lam, wrap_q(final_seg.path[-1])),
        message="Successfully realized explicit component-switch route with reachable transition selection.",
    )


# ============================================================
# Example setup
# ============================================================

@dataclass
class BenchmarkCase:
    start_family_name: str
    start_lam: float
    start_q: np.ndarray
    goal_family_name: str
    goal_lam: float
    goal_q: np.ndarray
    title: str


def build_benchmark():
    robot = Planar2LinkKinematics(l1=1.0, l2=1.0)

    start_q = np.array([0.5 * np.pi, 0.5 * np.pi], dtype=float)   # up
    goal_q = np.array([0.0, -0.5 * np.pi], dtype=float)           # down

    families = [
        EndEffectorXFamily("left_x_family", robot, [-1.00]),
        Joint2Family("switch_q2_family", [0.0]),
        EndEffectorYFamily("bridge_y_family", robot, [-1.00]),
        EndEffectorXFamily("right_x_family", robot, [1.00]),
    ]

    case = BenchmarkCase(
        start_family_name="left_x_family",
        start_lam=-1.0,
        start_q=start_q,
        goal_family_name="right_x_family",
        goal_lam=1.0,
        goal_q=goal_q,
        title="Example 41: explicit component-switch connector in 2D joint space",
    )
    return robot, families, case


# ============================================================
# Plot helpers
# ============================================================

def concatenate_steps(steps) -> np.ndarray:
    pts = []
    for i, step in enumerate(steps):
        path = np.asarray(step.path)
        if len(path) == 0:
            continue
        if i == 0:
            pts.extend(list(path))
        else:
            pts.extend(list(path[1:]))
    if not pts:
        return np.zeros((0, 2))
    return np.asarray(pts)


def total_path_length_from_steps(steps) -> float:
    total = 0.0
    for step in steps:
        path = np.asarray(step.path)
        if len(path) >= 2:
            total += float(np.sum(np.linalg.norm(np.diff(path, axis=0), axis=1)))
    return total


def summarize_component_route(route_edges, start_key):
    seq = [f"{start_key[0]}[{start_key[1]}|{start_key[2]}]"]
    for e in route_edges:
        fam, lam, comp = e.dst
        seq.append(f"{fam}[{lam}|{comp}]")
    return " -> ".join(seq)


def plot_jointspace_families(ax, robot, families):
    q1 = np.linspace(-np.pi, np.pi, 300)
    q2 = np.linspace(-np.pi, np.pi, 300)
    Q1, Q2 = np.meshgrid(q1, q2)

    X = robot.l1 * np.cos(Q1) + robot.l2 * np.cos(Q1 + Q2)
    Y = robot.l1 * np.sin(Q1) + robot.l2 * np.sin(Q1 + Q2)

    for fam in families:
        for lam in fam.sample_lambdas():
            if fam.name.endswith("x_family"):
                ax.contour(Q1, Q2, X, levels=[lam], linewidths=1.2, alpha=0.35)
            elif fam.name.endswith("y_family"):
                ax.contour(Q1, Q2, Y, levels=[lam], linewidths=1.2, alpha=0.35)
            elif fam.name == "switch_q2_family":
                ax.axhline(float(lam), linewidth=1.2, alpha=0.40)


def plot_workspace_path(ax, robot, q_path: np.ndarray, label: str):
    if len(q_path) == 0:
        return
    ee = np.asarray([robot.fk(q) for q in q_path])
    ax.plot(ee[:, 0], ee[:, 1], lw=2.5, label=label)


# ============================================================
# Main
# ============================================================

def main():
    np.random.seed(7)

    robot, families, case = build_benchmark()

    start_comp = component_of_q(case.start_q)
    goal_comp = component_of_q(case.goal_q)

    start_key = (case.start_family_name, case.start_lam, start_comp)
    goal_key = (case.goal_family_name, case.goal_lam, goal_comp)

    start_state = LeafState(
        family_name=case.start_family_name,
        lam=case.start_lam,
        x=case.start_q.copy(),
    )

    graph = build_component_switch_graph(
        families=families,
        robot=robot,
        goal_point=case.goal_q.copy(),
        max_candidates_per_pair=6,
    )

    print(f"\n{case.title}")
    print(f"start q = {np.round(case.start_q, 4)}  comp={start_comp}")
    print(f"goal  q = {np.round(case.goal_q, 4)}  comp={goal_comp}")
    print(f"start EE = {np.round(robot.fk(case.start_q), 4)}")
    print(f"goal  EE = {np.round(robot.fk(case.goal_q), 4)}")
    print(f"start_key = {start_key}")
    print(f"goal_key  = {goal_key}")

    route = shortest_component_route(
        graph=graph,
        start=start_key,
        goal=goal_key,
    )

    if route is None:
        print("\nNo explicit component-switch route found.")
        return

    print("\nSelected route with explicit switch connector:")
    print("  " + summarize_component_route(route, start_key))

    print("\nNominal transition edges from shortest path:")
    for i, e in enumerate(route):
        print(
            f"  edge {i}: {e.src} -> {e.dst}, "
            f"cand={e.candidate_index}, "
            f"q_transition={np.round(e.transition_point, 4)}, "
            f"score={e.score:.4f}, "
            f"EE={np.round(robot.fk(e.transition_point), 4)}, "
            f"q_comp={component_of_q(e.transition_point)}"
        )

    realized = realize_component_route_with_reachable_edge_selection(
        graph=graph,
        start_state=start_state,
        start_component=start_comp,
        goal_q=case.goal_q.copy(),
        families=families,
        route_edges=route,
        step_size=0.08,
        local_planner_name="projection",
        local_planner_kwargs=dict(
            goal_tol=1e-3,
            max_iters=1200,
            projection_tol=1e-10,
            projection_max_iters=50,
            projection_damping=1.0,
        ),
    )

    print("\nRealization result:")
    print(f"  success      : {realized.success}")
    print(f"  message      : {realized.message}")
    print(f"  path length  : {total_path_length_from_steps(realized.steps):.4f}")
    for i, step in enumerate(realized.steps):
        print(
            f"  step {i}: family={step.family_name}[{step.lam}|{step.component_id}], "
            f"transition={None if step.transition_point is None else np.round(step.transition_point, 4)}, "
            f"msg={step.message}"
        )

    q_path = concatenate_steps(realized.steps)

    fig, axes = plt.subplots(1, 2, figsize=(14, 6))

    ax = axes[0]
    plot_jointspace_families(ax, robot, families)
    if len(q_path) > 0:
        ax.plot(q_path[:, 0], q_path[:, 1], lw=3.0, label="component-switch joint-space path")
    for i, step in enumerate(realized.steps[:-1]):
        if step.transition_point is not None:
            ax.scatter(
                step.transition_point[0],
                step.transition_point[1],
                s=70,
                zorder=5,
                label="used exact transition" if i == 0 else None,
            )
    ax.scatter(case.start_q[0], case.start_q[1], s=90, marker="s", color="black", label="start")
    ax.scatter(case.goal_q[0], case.goal_q[1], s=120, marker="*", color="gold", edgecolor="black", label="goal")
    ax.set_title("Joint space with explicit branch-switch connector")
    ax.set_xlabel("q1 [rad]")
    ax.set_ylabel("q2 [rad]")
    ax.set_xlim([-np.pi, np.pi])
    ax.set_ylim([-np.pi, np.pi])
    ax.grid(True, alpha=0.25)
    ax.legend()

    ax = axes[1]
    plot_workspace_path(ax, robot, q_path, label="end-effector path")
    ax.scatter(*robot.fk(case.start_q), s=90, marker="s", color="black", label="start EE")
    ax.scatter(*robot.fk(case.goal_q), s=120, marker="*", color="gold", edgecolor="black", label="goal EE")
    ax.set_title("Workspace interpretation")
    ax.set_xlabel("x")
    ax.set_ylabel("y")
    ax.set_aspect("equal")
    ax.grid(True, alpha=0.25)
    ax.legend()

    plt.tight_layout()
    plt.show()


if __name__ == "__main__":
    main()