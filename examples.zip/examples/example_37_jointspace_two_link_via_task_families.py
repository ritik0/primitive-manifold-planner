from __future__ import annotations

from dataclasses import dataclass
from typing import List
import numpy as np
import matplotlib.pyplot as plt

from primitive_manifold_planner.families.leaf_state import LeafState
from primitive_manifold_planner.planners.leaf_graph import (
    build_leaf_graph,
    shortest_leaf_route,
)
from primitive_manifold_planner.planners.realize_leaf_route import realize_leaf_route
from primitive_manifold_planner.projection import project_newton


# ============================================================
# Simple 2-link planar arm kinematics
# Ambient state is q = [q1, q2]
# ============================================================

class Planar2LinkKinematics:
    def __init__(self, l1: float = 1.0, l2: float = 1.0):
        self.l1 = float(l1)
        self.l2 = float(l2)

    def fk(self, q: np.ndarray) -> np.ndarray:
        q = np.asarray(q, dtype=float)
        q1, q2 = q
        x = self.l1 * np.cos(q1) + self.l2 * np.cos(q1 + q2)
        y = self.l1 * np.sin(q1) + self.l2 * np.sin(q1 + q2)
        return np.array([x, y], dtype=float)

    def jacobian_xy(self, q: np.ndarray) -> np.ndarray:
        q = np.asarray(q, dtype=float)
        q1, q2 = q
        dx_dq1 = -self.l1 * np.sin(q1) - self.l2 * np.sin(q1 + q2)
        dx_dq2 = -self.l2 * np.sin(q1 + q2)
        dy_dq1 = self.l1 * np.cos(q1) + self.l2 * np.cos(q1 + q2)
        dy_dq2 = self.l2 * np.cos(q1 + q2)
        return np.array(
            [
                [dx_dq1, dx_dq2],
                [dy_dq1, dy_dq2],
            ],
            dtype=float,
        )


# ============================================================
# Implicit task manifolds in joint space
# ============================================================

class EndEffectorXManifold:
    def __init__(self, robot: Planar2LinkKinematics, target_x: float, name: str):
        self.robot = robot
        self.target_x = float(target_x)
        self.name = name

    def _coerce_point(self, q: np.ndarray) -> np.ndarray:
        q = np.asarray(q, dtype=float).reshape(-1)
        return q[:2].copy()

    def residual(self, q: np.ndarray) -> np.ndarray:
        q = self._coerce_point(q)
        x = self.robot.fk(q)[0]
        return np.array([x - self.target_x], dtype=float)

    def jacobian(self, q: np.ndarray) -> np.ndarray:
        q = self._coerce_point(q)
        return self.robot.jacobian_xy(q)[0:1, :]

    def is_valid(self, q: np.ndarray, tol: float = 1e-6) -> bool:
        return float(np.linalg.norm(self.residual(q))) <= tol


class EndEffectorYManifold:
    def __init__(self, robot: Planar2LinkKinematics, target_y: float, name: str):
        self.robot = robot
        self.target_y = float(target_y)
        self.name = name

    def _coerce_point(self, q: np.ndarray) -> np.ndarray:
        q = np.asarray(q, dtype=float).reshape(-1)
        return q[:2].copy()

    def residual(self, q: np.ndarray) -> np.ndarray:
        q = self._coerce_point(q)
        y = self.robot.fk(q)[1]
        return np.array([y - self.target_y], dtype=float)

    def jacobian(self, q: np.ndarray) -> np.ndarray:
        q = self._coerce_point(q)
        return self.robot.jacobian_xy(q)[1:2, :]

    def is_valid(self, q: np.ndarray, tol: float = 1e-6) -> bool:
        return float(np.linalg.norm(self.residual(q))) <= tol


# ============================================================
# Thin family wrappers
# ============================================================

class BenchmarkLeafFamily:
    def __init__(self, name: str, lambdas: List[float]):
        self.name = name
        self._lambdas = [float(v) for v in lambdas]

    def manifold(self, lam: float):
        raise NotImplementedError

    def sample_lambdas(self, context=None):
        return list(self._lambdas)

    def lambda_distance(self, lam_a, lam_b) -> float:
        return abs(float(lam_a) - float(lam_b))


class EndEffectorXFamily(BenchmarkLeafFamily):
    def __init__(self, name: str, robot: Planar2LinkKinematics, lambdas: List[float]):
        super().__init__(name=name, lambdas=lambdas)
        self.robot = robot

    def manifold(self, lam: float):
        return EndEffectorXManifold(
            robot=self.robot,
            target_x=float(lam),
            name=f"{self.name}_lambda_{lam:g}",
        )


class EndEffectorYFamily(BenchmarkLeafFamily):
    def __init__(self, name: str, robot: Planar2LinkKinematics, lambdas: List[float]):
        super().__init__(name=name, lambdas=lambdas)
        self.robot = robot

    def manifold(self, lam: float):
        return EndEffectorYManifold(
            robot=self.robot,
            target_y=float(lam),
            name=f"{self.name}_lambda_{lam:g}",
        )


# ============================================================
# Case definition
# ============================================================

@dataclass
class BenchmarkCase:
    start_family_name: str
    start_lam: float
    start_q: np.ndarray
    goal_family_name: str
    goal_lam: float
    goal_q: np.ndarray
    title: str


def build_benchmark():
    robot = Planar2LinkKinematics(l1=1.0, l2=1.0)

    # Updated to keep the route on a branch that realizes cleanly:
    # start EE = (-1, 1), goal EE = (1, 1)
    start_q = np.array([0.5 * np.pi, 0.5 * np.pi], dtype=float)
    goal_q = np.array([0.0, 0.5 * np.pi], dtype=float)

    families = [
        EndEffectorXFamily(
            name="left_x_family",
            robot=robot,
            lambdas=[-1.00, -0.80],
        ),
        EndEffectorYFamily(
            name="bridge_y_family",
            robot=robot,
            lambdas=[-1.00, -0.50, 0.00, 0.50, 1.00],
        ),
        EndEffectorXFamily(
            name="right_x_family",
            robot=robot,
            lambdas=[0.80, 1.00],
        ),
    ]

    case = BenchmarkCase(
        start_family_name="left_x_family",
        start_lam=-1.0,
        start_q=start_q,
        goal_family_name="right_x_family",
        goal_lam=1.0,
        goal_q=goal_q,
        title="Example 37: 2D joint-space multimodal planning via task families",
    )

    return robot, families, case


# ============================================================
# Graph helpers
# ============================================================

def get_family_map(families):
    return {f.name: f for f in families}


def allowed_family_pair(fam_a_name: str, fam_b_name: str) -> bool:
    allowed = {
        ("left_x_family", "bridge_y_family"),
        ("bridge_y_family", "left_x_family"),
        ("bridge_y_family", "right_x_family"),
        ("right_x_family", "bridge_y_family"),
    }
    return (fam_a_name, fam_b_name) in allowed


def wrap_to_pi(angle: float) -> float:
    return (float(angle) + np.pi) % (2.0 * np.pi) - np.pi


def two_link_ik_solutions(robot, x: float, y: float):
    l1 = float(robot.l1)
    l2 = float(robot.l2)

    r2 = x * x + y * y
    cos_q2 = (r2 - l1 * l1 - l2 * l2) / (2.0 * l1 * l2)

    if cos_q2 < -1.0 - 1e-10 or cos_q2 > 1.0 + 1e-10:
        return []

    cos_q2 = np.clip(cos_q2, -1.0, 1.0)
    q2_candidates = [np.arccos(cos_q2), -np.arccos(cos_q2)]

    sols = []
    for q2 in q2_candidates:
        k1 = l1 + l2 * np.cos(q2)
        k2 = l2 * np.sin(q2)
        q1 = np.arctan2(y, x) - np.arctan2(k2, k1)

        q1 = wrap_to_pi(q1)
        q2 = wrap_to_pi(q2)
        q = np.array([q1, q2], dtype=float)

        duplicate = False
        for s in sols:
            if np.linalg.norm(q - s) < 1e-8:
                duplicate = True
                break
        if not duplicate:
            sols.append(q)

    return sols


def seed_points_fn(fam_a, lam_a, fam_b, lam_b):
    seeds = []

    vals = np.linspace(-np.pi, np.pi, 9)
    for q1 in vals:
        for q2 in vals:
            seeds.append(np.array([q1, q2], dtype=float))

    def add_ik_seeds(robot, x_target: float, y_target: float):
        sols = two_link_ik_solutions(robot, x_target, y_target)
        eps = 0.05

        for q in sols:
            seeds.append(q.copy())
            seeds.append(q + np.array([eps, 0.0]))
            seeds.append(q + np.array([-eps, 0.0]))
            seeds.append(q + np.array([0.0, eps]))
            seeds.append(q + np.array([0.0, -eps]))
            seeds.append(q + np.array([eps, eps]))
            seeds.append(q + np.array([-eps, -eps]))

    if fam_a.name.endswith("x_family") and fam_b.name.endswith("y_family"):
        add_ik_seeds(fam_a.robot, float(lam_a), float(lam_b))

    if fam_b.name.endswith("x_family") and fam_a.name.endswith("y_family"):
        add_ik_seeds(fam_b.robot, float(lam_b), float(lam_a))

    uniq = []
    for s in seeds:
        s = np.array([wrap_to_pi(s[0]), wrap_to_pi(s[1])], dtype=float)
        if not any(np.linalg.norm(s - t) < 1e-8 for t in uniq):
            uniq.append(s)

    return uniq


def build_restricted_leaf_graph(families, goal_point):
    graph = build_leaf_graph(
        families=families,
        project_newton=project_newton,
        seed_points_fn=seed_points_fn,
        goal_point=goal_point,
        max_candidates_per_pair=2,
    )

    filtered = {}
    for src, edges in graph.adjacency.items():
        kept = []
        for e in edges:
            if allowed_family_pair(e.src[0], e.dst[0]):
                kept.append(e)
        filtered[src] = kept
    graph.adjacency = filtered
    return graph


def edge_cost_fn(edge):
    return 1.0 + edge.score


# ============================================================
# Plot helpers
# ============================================================

def concatenate_steps(steps) -> np.ndarray:
    pts = []
    for i, step in enumerate(steps):
        path = np.asarray(step.path)
        if len(path) == 0:
            continue
        if i == 0:
            pts.extend(list(path))
        else:
            pts.extend(list(path[1:]))
    if not pts:
        return np.zeros((0, 2))
    return np.asarray(pts)


def total_path_length_from_steps(steps) -> float:
    total = 0.0
    for step in steps:
        path = np.asarray(step.path)
        if len(path) >= 2:
            total += float(np.sum(np.linalg.norm(np.diff(path, axis=0), axis=1)))
    return total


def summarize_leaf_sequence(route_edges, start_key):
    seq = [f"{start_key[0]}[{start_key[1]}]"]
    for e in route_edges:
        seq.append(f"{e.dst[0]}[{e.dst[1]}]")
    return " -> ".join(seq)


def plot_jointspace_families(ax, robot, families):
    q1 = np.linspace(-np.pi, np.pi, 300)
    q2 = np.linspace(-np.pi, np.pi, 300)
    Q1, Q2 = np.meshgrid(q1, q2)

    X = robot.l1 * np.cos(Q1) + robot.l2 * np.cos(Q1 + Q2)
    Y = robot.l1 * np.sin(Q1) + robot.l2 * np.sin(Q1 + Q2)

    for fam in families:
        for lam in fam.sample_lambdas():
            if fam.name.endswith("x_family"):
                ax.contour(Q1, Q2, X, levels=[lam], linewidths=1.0, alpha=0.30)
            elif fam.name.endswith("y_family"):
                ax.contour(Q1, Q2, Y, levels=[lam], linewidths=1.0, alpha=0.30)


def plot_workspace_path(ax, robot, q_path: np.ndarray, label: str):
    if len(q_path) == 0:
        return
    ee = np.asarray([robot.fk(q) for q in q_path])
    ax.plot(ee[:, 0], ee[:, 1], lw=2.5, label=label)


# ============================================================
# Main
# ============================================================

def main():
    np.random.seed(7)

    robot, families, case = build_benchmark()
    family_map = get_family_map(families)

    start_key = (case.start_family_name, case.start_lam)
    goal_key = (case.goal_family_name, case.goal_lam)

    start_state = LeafState(
        family_name=case.start_family_name,
        lam=case.start_lam,
        x=case.start_q.copy(),
    )
    goal_family = family_map[case.goal_family_name]
    goal_lam = case.goal_lam
    goal_q = case.goal_q.copy()

    graph = build_restricted_leaf_graph(
        families=families,
        goal_point=goal_q,
    )

    print(f"\n{case.title}")
    print(f"start q = {np.round(case.start_q, 4)}")
    print(f"goal  q = {np.round(case.goal_q, 4)}")
    print(f"start EE = {np.round(robot.fk(case.start_q), 4)}")
    print(f"goal  EE = {np.round(robot.fk(case.goal_q), 4)}")
    print(f"start_key = {start_key}")
    print(f"goal_key  = {goal_key}")
    print(f"graph nodes = {sorted(graph.adjacency.keys(), key=lambda x: (x[0], x[1]))}")

    route = shortest_leaf_route(
        graph=graph,
        start=start_key,
        goal=goal_key,
        edge_cost_fn=edge_cost_fn,
    )

    if route is None:
        print("\nNo route found.")
        return

    print("\nSelected leaf route:")
    print("  " + summarize_leaf_sequence(route, start_key))

    print("\nTransition edges:")
    for i, e in enumerate(route):
        print(
            f"  edge {i}: {e.src} -> {e.dst}, "
            f"cand={e.candidate_index}, "
            f"q_transition={np.round(e.transition_point, 4)}, "
            f"score={e.score:.4f}, "
            f"EE={np.round(robot.fk(e.transition_point), 4)}"
        )

    realized = realize_leaf_route(
        start_state=start_state,
        goal_point=goal_q,
        goal_family=goal_family,
        goal_lam=goal_lam,
        families=families,
        route_edges=route,
        step_size=0.08,
        local_planner_name="projection",
        local_planner_kwargs=dict(
            goal_tol=1e-3,
            max_iters=800,
            projection_tol=1e-10,
            projection_max_iters=50,
            projection_damping=1.0,
        ),
    )

    print("\nRealization result:")
    print(f"  success      : {realized.success}")
    print(f"  message      : {realized.message}")
    print(f"  path length  : {total_path_length_from_steps(realized.steps):.4f}")

    q_path = concatenate_steps(realized.steps)

    fig, axes = plt.subplots(1, 2, figsize=(14, 6))

    ax = axes[0]
    plot_jointspace_families(ax, robot, families)
    if len(q_path) > 0:
        ax.plot(q_path[:, 0], q_path[:, 1], lw=3.0, label="joint-space path")
    for i, e in enumerate(route):
        ax.scatter(
            e.transition_point[0],
            e.transition_point[1],
            s=60,
            zorder=5,
            label="exact transition" if i == 0 else None,
        )
    ax.scatter(case.start_q[0], case.start_q[1], s=90, marker="s", color="black", label="start")
    ax.scatter(case.goal_q[0], case.goal_q[1], s=120, marker="*", color="gold", edgecolor="black", label="goal")
    ax.set_title("Joint space: leaves are implicit task manifolds")
    ax.set_xlabel("q1 [rad]")
    ax.set_ylabel("q2 [rad]")
    ax.set_xlim([-np.pi, np.pi])
    ax.set_ylim([-np.pi, np.pi])
    ax.grid(True, alpha=0.25)
    ax.legend()

    ax = axes[1]
    plot_workspace_path(ax, robot, q_path, label="end-effector path")
    ax.scatter(*robot.fk(case.start_q), s=90, marker="s", color="black", label="start EE")
    ax.scatter(*robot.fk(case.goal_q), s=120, marker="*", color="gold", edgecolor="black", label="goal EE")
    ax.set_title("Workspace meaning of the joint-space multimodal plan")
    ax.set_xlabel("x")
    ax.set_ylabel("y")
    ax.set_aspect("equal")
    ax.grid(True, alpha=0.25)
    ax.legend()

    plt.tight_layout()
    plt.show()


if __name__ == "__main__":
    main()