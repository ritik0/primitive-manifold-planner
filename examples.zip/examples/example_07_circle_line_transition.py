from __future__ import annotations

import numpy as np
import matplotlib
matplotlib.use("TkAgg")
import matplotlib.pyplot as plt

from primitive_manifold_planner.manifolds import CircleManifold, LineManifold
from primitive_manifold_planner.planning import find_transition_candidates
from primitive_manifold_planner.visualization import (
    finalize_2d_axes,
    plot_circle_manifold,
    plot_transition_candidates_2d,
)


def main() -> None:
    circle = CircleManifold(center=np.array([0.0, 0.0]), radius=2.0, name="circle")
    line = LineManifold(
        point=np.array([0.0, 1.0]),
        normal=np.array([0.0, 1.0]),  # y = 1
        name="line y=1",
    )

    rng = np.random.default_rng(123)
    result = find_transition_candidates(
        manifold_a=circle,
        manifold_b=line,
        bounds_min=np.array([-3.0, -3.0]),
        bounds_max=np.array([3.0, 3.0]),
        num_seeds=100,
        tol=1e-8,
        max_candidates=10,
        rng=rng,
    )

    print("=== Circle-line transition candidates ===")
    print(f"Success       : {result.success}")
    print(f"Message       : {result.message}")
    print(f"# candidates  : {len(result.candidates)}")

    for i, cand in enumerate(result.candidates):
        print(
            f"  Candidate {i}: "
            f"point={cand.point}, "
            f"residual={cand.residual_norm:.3e}, "
            f"score={cand.score:.6f}"
        )

    fig, ax = plt.subplots(figsize=(7, 7))

    plot_circle_manifold(ax, circle, label="circle")

    # Draw a finite line segment only for visualization
    xs = np.linspace(-3.0, 3.0, 200)
    ys = np.ones_like(xs)
    ax.plot(xs, ys, label="line y=1")

    selected_point = result.best_candidate.point if result.best_candidate is not None else None
    plot_transition_candidates_2d(
        ax,
        result.candidates,
        selected_point=selected_point,
        annotate=True,
    )

    finalize_2d_axes(ax, title="Circle-line transition candidates")

    out_path = "example_07_circle_line_transition.png"
    plt.savefig(out_path, dpi=200, bbox_inches="tight")
    print(f"Saved figure to: {out_path}")

    plt.show(block=True)


if __name__ == "__main__":
    main()