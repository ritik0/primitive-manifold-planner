from __future__ import annotations

import numpy as np
import matplotlib
matplotlib.use("TkAgg")
import matplotlib.pyplot as plt

from primitive_manifold_planner.manifolds import SphereManifold
from primitive_manifold_planner.planning import plan_constrained_rrt


def main() -> None:
    sphere = SphereManifold(center=np.array([0.0, 0.0, 0.0]), radius=2.0, name="sphere")

    start = np.array([2.0, 0.0, 0.0])
    goal = np.array([0.0, 2.0, 0.0])

    rng = np.random.default_rng(7)
    result = plan_constrained_rrt(
        manifold=sphere,
        start_point=start,
        goal_point=goal,
        bounds_min=np.array([-3.0, -3.0, -3.0]),
        bounds_max=np.array([3.0, 3.0, 3.0]),
        max_iters=500,
        step_size=0.25,
        goal_tol=1e-1,
        goal_sample_rate=0.2,
        rng=rng,
    )

    print("=== Constrained RRT on sphere ===")
    print(f"Success      : {result.success}")
    print(f"Iterations   : {result.iterations}")
    print(f"Message      : {result.message}")
    print(f"Tree size    : {len(result.tree_points)}")

    fig = plt.figure(figsize=(8, 7))
    ax = fig.add_subplot(111, projection="3d")

    # sphere surface
    u = np.linspace(0.0, 2.0 * np.pi, 50)
    v = np.linspace(0.0, np.pi, 25)
    uu, vv = np.meshgrid(u, v)

    x = sphere.center[0] + sphere.radius * np.cos(uu) * np.sin(vv)
    y = sphere.center[1] + sphere.radius * np.sin(uu) * np.sin(vv)
    z = sphere.center[2] + sphere.radius * np.cos(vv)
    ax.plot_surface(x, y, z, alpha=0.2)

    # start and goal
    ax.scatter([start[0]], [start[1]], [start[2]], s=100, label="start")
    ax.scatter([goal[0]], [goal[1]], [goal[2]], s=120, marker="*", label="goal")

    # tree nodes
    if result.tree_points.size > 0:
        ax.scatter(
            result.tree_points[:, 0],
            result.tree_points[:, 1],
            result.tree_points[:, 2],
            s=10,
            label="rrt tree nodes",
        )

    # path
    if result.path is not None:
        ax.plot(
            result.path[:, 0],
            result.path[:, 1],
            result.path[:, 2],
            label="rrt path",
        )
        ax.scatter(
            result.path[:, 0],
            result.path[:, 1],
            result.path[:, 2],
            s=18,
        )

    ax.set_title("Projection-based constrained RRT on a sphere")
    ax.set_xlabel("x")
    ax.set_ylabel("y")
    ax.set_zlabel("z")
    ax.legend()

    out_path = "example_15_constrained_rrt_sphere.png"
    plt.savefig(out_path, dpi=200, bbox_inches="tight")
    print(f"Saved figure to: {out_path}")

    plt.show(block=True)


if __name__ == "__main__":
    main()