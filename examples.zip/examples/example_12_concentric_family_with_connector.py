from __future__ import annotations

import numpy as np
import matplotlib
matplotlib.use("TkAgg")
import matplotlib.pyplot as plt

from primitive_manifold_planner.manifolds import CircleManifold, LineManifold
from primitive_manifold_planner.planning import build_mode_graph, plan_multimodal_route
from primitive_manifold_planner.visualization import (
    finalize_2d_axes,
    plot_circle_manifold,
    plot_path_2d,
    plot_start_goal,
    plot_transition_candidates_2d,
)


def main() -> None:
    # ------------------------------------------------------------
    # Define sampled concentric-circle leaves and one radial connector
    # ------------------------------------------------------------
    circle_1 = CircleManifold(center=np.array([0.0, 0.0]), radius=1.0, name="circle_1")
    circle_2 = CircleManifold(center=np.array([0.0, 0.0]), radius=2.0, name="circle_2")
    circle_3 = CircleManifold(center=np.array([0.0, 0.0]), radius=3.0, name="circle_3")

    # Radial connector: y = 0
    connector = LineManifold(
        point=np.array([0.0, -1.0]),
        normal=np.array([0.0, 1.0]),
        name="radial_connector",
    )

    manifolds = {
        "circle_1": circle_1,
        "circle_2": circle_2,
        "circle_3": circle_3,
        "radial_connector": connector,
    }

    start_point = np.array([1.0, 0.0])
    goal_point = np.array([0.0, 3.0])

    # ------------------------------------------------------------
    # Build mode graph
    # ------------------------------------------------------------
    rng = np.random.default_rng(321)
    graph, diagnostics = build_mode_graph(
        manifolds=manifolds,
        bounds_min=np.array([-4.0, -4.0]),
        bounds_max=np.array([4.0, 4.0]),
        num_seeds=120,
        tol=1e-8,
        rng=rng,
    )

    print("=== Mode graph ===")
    print(graph)
    print(f"Nodes: {list(graph.nodes.keys())}")
    print(f"Edges: {len(graph.edges)}")

    for pair, diag in diagnostics.items():
        print(f"\nPair {pair}")
        print(f"  success           : {diag.success}")
        print(f"  message           : {diag.message}")
        print(f"  # candidates      : {len(diag.candidates)}")
        if diag.best_candidate is not None:
            print(f"  best point        : {diag.best_candidate.point}")
            print(f"  best residual     : {diag.best_candidate.residual_norm:.3e}")
            print(f"  best score        : {diag.best_candidate.score:.6f}")

    # ------------------------------------------------------------
    # Plan full multimodal route
    # ------------------------------------------------------------
    result = plan_multimodal_route(
        graph=graph,
        start_mode="circle_1",
        goal_mode="circle_3",
        start_point=start_point,
        goal_point=goal_point,
        step_size=0.1,
        goal_tol=5e-2,
        max_iters=800,
    )

    print("\n=== Multimodal plan result ===")
    print(f"Success        : {result.success}")
    print(f"Message        : {result.message}")

    selected_transitions = []
    if result.route is not None:
        print(f"Mode sequence  : {result.route.mode_sequence}")
        print(f"# transitions  : {len(result.route.transition_steps)}")

        for i, step in enumerate(result.route.transition_steps):
            print(f"\n  Transition {i + 1}")
            print(f"    from       : {step.from_mode}")
            print(f"    to         : {step.to_mode}")
            print(f"    point      : {step.transition_point}")
            print(f"    residual   : {step.residual_norm:.3e}")
            selected_transitions.append(step.transition_point)

    print(f"\n# segments     : {len(result.segment_plans)}")
    for i, seg in enumerate(result.segment_plans):
        print(f"\n  Segment {i + 1}")
        print(f"    mode       : {seg.mode_name}")
        print(f"    success    : {seg.success}")
        print(f"    message    : {seg.message}")
        print(f"    start      : {seg.start_point}")
        print(f"    end        : {seg.end_point}")
        print(f"    path shape : {seg.path.shape}")

    # ------------------------------------------------------------
    # Plot
    # ------------------------------------------------------------
    fig, ax = plt.subplots(figsize=(8, 8))

    plot_circle_manifold(ax, circle_1, label="circle_1")
    plot_circle_manifold(ax, circle_2, label="circle_2")
    plot_circle_manifold(ax, circle_3, label="circle_3")

    xs = np.linspace(-4.0, 4.0, 400)
    ys = np.zeros_like(xs)
    ax.plot(xs, ys, label="radial connector y=0")

    plot_start_goal(ax, start_point, goal_point)

    # show connector candidates with diagnostics
    edge_13 = graph.get_edge("circle_1", "radial_connector")
    if edge_13 is not None:
        selected = selected_transitions[0] if len(selected_transitions) >= 1 else None
        plot_transition_candidates_2d(
            ax,
            edge_13.transition_candidates,
            selected_point=selected,
            annotate=True,
            label_all="circle_1 <-> connector candidates",
            label_selected="selected transition 1",
        )

    edge_33 = graph.get_edge("circle_3", "radial_connector")
    if edge_33 is not None:
        selected = selected_transitions[1] if len(selected_transitions) >= 2 else None
        plot_transition_candidates_2d(
            ax,
            edge_33.transition_candidates,
            selected_point=selected,
            annotate=True,
            label_all="circle_3 <-> connector candidates",
            label_selected="selected transition 2",
        )

    if result.full_path is not None:
        plot_path_2d(ax, result.full_path, show_points=True, label="full multimodal path")

    finalize_2d_axes(
        ax,
        title="Concentric-circle family with radial connector",
    )

    out_path = "example_12_concentric_family_with_connector.png"
    plt.savefig(out_path, dpi=200, bbox_inches="tight")
    print(f"\nSaved figure to: {out_path}")

    plt.show(block=True)


if __name__ == "__main__":
    main()