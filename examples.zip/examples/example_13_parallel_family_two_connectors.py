from __future__ import annotations

import numpy as np
import matplotlib
matplotlib.use("TkAgg")
import matplotlib.pyplot as plt

from primitive_manifold_planner.manifolds import LineManifold
from primitive_manifold_planner.planning import build_mode_graph, plan_multimodal_route
from primitive_manifold_planner.visualization import finalize_2d_axes, plot_path_2d, plot_start_goal


def main() -> None:
    # ------------------------------------------------------------
    # Define sampled horizontal leaves and two vertical connectors
    # ------------------------------------------------------------
    leaf_m1 = LineManifold(point=np.array([0.0, -1.0]), normal=np.array([0.0, 1.0]), name="leaf_-1")
    leaf_0 = LineManifold(point=np.array([0.0, 0.0]), normal=np.array([0.0, 1.0]), name="leaf_0")
    leaf_p1 = LineManifold(point=np.array([0.0, 1.0]), normal=np.array([0.0, 1.0]), name="leaf_1")

    connector_left = LineManifold(
        point=np.array([-1.0, 0.0]),
        normal=np.array([1.0, 0.0]),  # x = -1
        name="connector_left",
    )
    connector_right = LineManifold(
        point=np.array([1.0, 0.0]),
        normal=np.array([1.0, 0.0]),  # x = +1
        name="connector_right",
    )

    manifolds = {
        "leaf_-1": leaf_m1,
        "leaf_0": leaf_0,
        "leaf_1": leaf_p1,
        "connector_left": connector_left,
        "connector_right": connector_right,
    }

    # Change these to see route choice switch
    start_point = np.array([-2.5, -1.0])
    goal_point = np.array([-2.0, 1.0])

    # start_point = np.array([2.5, -1.0])
    # goal_point = np.array([2.0, 1.0])

    # ------------------------------------------------------------
    # Build mode graph
    # ------------------------------------------------------------
    rng = np.random.default_rng(123)
    graph, diagnostics = build_mode_graph(
        manifolds=manifolds,
        bounds_min=np.array([-3.0, -3.0]),
        bounds_max=np.array([3.0, 3.0]),
        num_seeds=100,
        tol=1e-8,
        rng=rng,
    )

    print("=== Mode graph ===")
    print(graph)
    print(f"Nodes: {list(graph.nodes.keys())}")
    print(f"Edges: {len(graph.edges)}")

    for pair, diag in diagnostics.items():
        print(f"Pair {pair}: success={diag.success}, #candidates={len(diag.candidates)}")

    # ------------------------------------------------------------
    # Plan full multimodal route
    # ------------------------------------------------------------
    result = plan_multimodal_route(
        graph=graph,
        start_mode="leaf_-1",
        goal_mode="leaf_1",
        start_point=start_point,
        goal_point=goal_point,
        step_size=0.15,
        goal_tol=5e-2,
        max_iters=800,
    )

    print("\n=== Multimodal plan result ===")
    print(f"Success        : {result.success}")
    print(f"Message        : {result.message}")

    if result.route is not None:
        print(f"Mode sequence  : {result.route.mode_sequence}")
        print(f"# transitions  : {len(result.route.transition_steps)}")

        for i, step in enumerate(result.route.transition_steps):
            print(f"\n  Transition {i + 1}")
            print(f"    from       : {step.from_mode}")
            print(f"    to         : {step.to_mode}")
            print(f"    point      : {step.transition_point}")
            print(f"    residual   : {step.residual_norm:.3e}")

    print(f"\n# segments     : {len(result.segment_plans)}")
    for i, seg in enumerate(result.segment_plans):
        print(f"\n  Segment {i + 1}")
        print(f"    mode       : {seg.mode_name}")
        print(f"    success    : {seg.success}")
        print(f"    message    : {seg.message}")
        print(f"    start      : {seg.start_point}")
        print(f"    end        : {seg.end_point}")
        print(f"    path shape : {seg.path.shape}")

    # ------------------------------------------------------------
    # Plot
    # ------------------------------------------------------------
    fig, ax = plt.subplots(figsize=(8, 6))

    xs = np.linspace(-3.0, 3.0, 200)
    for y in [-1.0, 0.0, 1.0]:
        ys = np.full_like(xs, y)
        ax.plot(xs, ys, label=f"leaf y={y:g}")

    ys = np.linspace(-2.0, 2.0, 200)
    ax.plot(np.full_like(ys, -1.0), ys, label="connector x=-1")
    ax.plot(np.full_like(ys, 1.0), ys, label="connector x=+1")

    plot_start_goal(ax, start_point, goal_point)

    if result.full_path is not None:
        plot_path_2d(ax, result.full_path, show_points=True, label="full multimodal path")

    if result.route is not None:
        for i, step in enumerate(result.route.transition_steps):
            tp = step.transition_point
            ax.scatter([tp[0]], [tp[1]], s=120, marker="s", label=f"transition {i+1}")

    finalize_2d_axes(
        ax,
        title="Parallel-line family with two competing connectors",
    )

    out_path = "example_13_parallel_family_two_connectors.png"
    plt.savefig(out_path, dpi=200, bbox_inches="tight")
    print(f"\nSaved figure to: {out_path}")

    plt.show(block=True)


if __name__ == "__main__":
    main()