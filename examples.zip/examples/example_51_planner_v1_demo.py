from __future__ import annotations

import numpy as np
import matplotlib.pyplot as plt

from primitive_manifold_planner.families.leaf_state import LeafState
from primitive_manifold_planner.planners.multimodal_component_planner import (
    MultimodalComponentPlanner,
    PlannerConfig,
)
from primitive_manifold_planner.projection import project_newton

from primitive_manifold_planner.examplesupport.planar2link import (
    Planar2LinkKinematics,
    component_of_q,
    wrap_q,
    torus_distance,
)
from primitive_manifold_planner.examplesupport.planar2link_families import (
    EndEffectorXFamily,
    EndEffectorYFamily,
    Joint2Family,
)
from primitive_manifold_planner.examplesupport.planar2link_helpers import (
    make_seed_points_fn,
    component_ids_for_family,
    compatible_components_for_leaf,
    allowed_switch_pair,
)


def concatenate_steps(steps) -> np.ndarray:
    pts = []
    for i, step in enumerate(steps):
        path = np.asarray(step.path)
        if len(path) == 0:
            continue
        if i == 0:
            pts.extend(list(path))
        else:
            pts.extend(list(path[1:]))
    if not pts:
        return np.zeros((0, 2))
    return np.asarray(pts)


def plot_jointspace_families(ax, robot, families):
    q1 = np.linspace(-np.pi, np.pi, 350)
    q2 = np.linspace(-np.pi, np.pi, 350)
    Q1, Q2 = np.meshgrid(q1, q2)

    X = robot.l1 * np.cos(Q1) + robot.l2 * np.cos(Q1 + Q2)
    Y = robot.l1 * np.sin(Q1) + robot.l2 * np.sin(Q1 + Q2)

    for fam in families:
        for lam in fam.sample_lambdas():
            if fam.name.endswith("x_family"):
                ax.contour(Q1, Q2, X, levels=[lam], linewidths=1.0, alpha=0.28)
            elif fam.name.endswith("y_family"):
                ax.contour(Q1, Q2, Y, levels=[lam], linewidths=1.0, alpha=0.28)
            elif fam.name == "switch_q2_family":
                ax.axhline(float(lam), linewidth=1.0, alpha=0.35)


def plot_workspace_path(ax, robot, q_path: np.ndarray, label: str):
    if len(q_path) == 0:
        return
    ee = np.asarray([robot.fk(q) for q in q_path])
    ax.plot(ee[:, 0], ee[:, 1], lw=2.5, label=label)


def main():
    np.random.seed(7)

    robot = Planar2LinkKinematics(l1=1.0, l2=1.0)

    families = [
        EndEffectorXFamily("left_x_family", robot, [-1.00]),
        Joint2Family("switch_q2_family", [0.0]),
        EndEffectorYFamily("bridge_y_family", robot, [-1.00]),
        EndEffectorXFamily("right_x_family", robot, [1.00]),
    ]

    start_q = wrap_q(np.array([0.5 * np.pi, 0.5 * np.pi], dtype=float))
    goal_q = wrap_q(np.array([0.0, -0.5 * np.pi], dtype=float))

    start_state = LeafState("left_x_family", -1.0, start_q.copy())
    start_comp = component_of_q(start_q)
    goal_comp = component_of_q(goal_q)

    config = PlannerConfig(
        max_candidates_per_pair=8,
        wrap_state_fn=wrap_q,
        state_distance_fn=torus_distance,
        local_planner_name="projection",
        local_planner_kwargs=dict(
            goal_tol=1e-3,
            max_iters=1200,
            projection_tol=1e-10,
            projection_max_iters=50,
            projection_damping=1.0,
        ),
        step_size=0.08,
    )

    planner = MultimodalComponentPlanner(
        families=families,
        project_newton=project_newton,
        seed_points_fn=make_seed_points_fn(robot),
        component_ids_for_family_fn=component_ids_for_family,
        compatible_components_fn=compatible_components_for_leaf,
        allowed_family_pair_fn=allowed_switch_pair,
        config=config,
    )

    result = planner.plan(
        start_state=start_state,
        start_component=start_comp,
        goal_family_name="right_x_family",
        goal_lam=1.0,
        goal_component=goal_comp,
        goal_q=goal_q.copy(),
    )

    print("\nExample 51: planner v1 demo")
    print(f"start q = {np.round(start_q, 4)} comp={start_comp}")
    print(f"goal  q = {np.round(goal_q, 4)} comp={goal_comp}")
    print(f"route_found = {result.route_found}")
    print(f"realization_success = {result.realization_success}")
    print(f"path_length = {result.path_length:.4f}")
    print(f"message = {result.message}")
    print(f"graph_nodes = {result.diagnostics.num_graph_nodes}")
    print(f"graph_edges = {result.diagnostics.num_graph_edges}")
    print(f"transition_pairs = {result.diagnostics.num_transition_pairs}")
    print(f"transition_candidates = {result.diagnostics.num_transition_candidates}")
    print(f"transition_cache_hits = {result.diagnostics.transition_cache_hits}")
    print(f"transition_cache_misses = {result.diagnostics.transition_cache_misses}")
    print(f"route = {result.diagnostics.selected_route_string}")
    print(f"selected_candidate_indices = {result.diagnostics.selected_candidate_indices}")
    print(f"realized_candidate_indices = {result.diagnostics.realized_candidate_indices}")
    print(f"realized_transition_deviations = {result.diagnostics.realized_transition_deviations}")

    if result.realization is not None:
        for i, step in enumerate(result.realization.steps):
            print(
                f"  step {i}: family={step.family_name}[{step.lam}|{step.component_id}], "
                f"transition={None if step.transition_point is None else np.round(step.transition_point, 4)}, "
                f"msg={step.message}"
            )

    q_path = (
        concatenate_steps(result.realization.steps)
        if result.realization is not None and result.realization.success
        else np.zeros((0, 2))
    )

    fig, axes = plt.subplots(1, 2, figsize=(14, 6))

    ax = axes[0]
    plot_jointspace_families(ax, robot, families)
    if len(q_path) > 0:
        ax.plot(q_path[:, 0], q_path[:, 1], lw=3.0, label="joint-space path")
    if result.realization is not None:
        for i, step in enumerate(result.realization.steps[:-1]):
            if step.transition_point is not None:
                ax.scatter(
                    step.transition_point[0],
                    step.transition_point[1],
                    s=60,
                    label="used transition" if i == 0 else None,
                )
    ax.scatter(start_q[0], start_q[1], s=90, marker="s", color="black", label="start")
    ax.scatter(goal_q[0], goal_q[1], s=120, marker="*", color="gold", edgecolor="black", label="goal")
    ax.set_title("Planner v1 in joint space")
    ax.set_xlim([-np.pi, np.pi])
    ax.set_ylim([-np.pi, np.pi])
    ax.grid(True, alpha=0.25)
    ax.legend()

    ax = axes[1]
    plot_workspace_path(ax, robot, q_path, label="end-effector path")
    ax.scatter(*robot.fk(start_q), s=90, marker="s", color="black", label="start EE")
    ax.scatter(*robot.fk(goal_q), s=120, marker="*", color="gold", edgecolor="black", label="goal EE")
    ax.set_title("Workspace interpretation")
    ax.set_aspect("equal")
    ax.grid(True, alpha=0.25)
    ax.legend()

    plt.tight_layout()
    plt.show()


if __name__ == "__main__":
    main()
