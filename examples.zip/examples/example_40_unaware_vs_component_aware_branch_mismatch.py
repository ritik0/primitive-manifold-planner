from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Tuple, Optional
import heapq
import numpy as np
import matplotlib.pyplot as plt

from primitive_manifold_planner.families.leaf_state import LeafState
from primitive_manifold_planner.planning.local import run_local_planner
from primitive_manifold_planner.planners.leaf_graph import (
    build_leaf_graph,
    shortest_leaf_route,
)
from primitive_manifold_planner.planners.realize_leaf_route import realize_leaf_route
from primitive_manifold_planner.projection import project_newton
from primitive_manifold_planner.transitions.leaf_transition import find_leaf_transition


# ============================================================
# Shared 2-link robot + manifolds
# ============================================================

class Planar2LinkKinematics:
    def __init__(self, l1: float = 1.0, l2: float = 1.0):
        self.l1 = float(l1)
        self.l2 = float(l2)

    def fk(self, q: np.ndarray) -> np.ndarray:
        q = np.asarray(q, dtype=float)
        q1, q2 = q
        x = self.l1 * np.cos(q1) + self.l2 * np.cos(q1 + q2)
        y = self.l1 * np.sin(q1) + self.l2 * np.sin(q1 + q2)
        return np.array([x, y], dtype=float)

    def jacobian_xy(self, q: np.ndarray) -> np.ndarray:
        q = np.asarray(q, dtype=float)
        q1, q2 = q
        dx_dq1 = -self.l1 * np.sin(q1) - self.l2 * np.sin(q1 + q2)
        dx_dq2 = -self.l2 * np.sin(q1 + q2)
        dy_dq1 = self.l1 * np.cos(q1) + self.l2 * np.cos(q1 + q2)
        dy_dq2 = self.l2 * np.cos(q1 + q2)
        return np.array(
            [
                [dx_dq1, dx_dq2],
                [dy_dq1, dy_dq2],
            ],
            dtype=float,
        )


class EndEffectorXManifold:
    def __init__(self, robot: Planar2LinkKinematics, target_x: float, name: str):
        self.robot = robot
        self.target_x = float(target_x)
        self.name = name

    def _coerce_point(self, q: np.ndarray) -> np.ndarray:
        q = np.asarray(q, dtype=float).reshape(-1)
        return q[:2].copy()

    def residual(self, q: np.ndarray) -> np.ndarray:
        q = self._coerce_point(q)
        return np.array([self.robot.fk(q)[0] - self.target_x], dtype=float)

    def jacobian(self, q: np.ndarray) -> np.ndarray:
        q = self._coerce_point(q)
        return self.robot.jacobian_xy(q)[0:1, :]

    def is_valid(self, q: np.ndarray, tol: float = 1e-6) -> bool:
        return float(np.linalg.norm(self.residual(q))) <= tol


class EndEffectorYManifold:
    def __init__(self, robot: Planar2LinkKinematics, target_y: float, name: str):
        self.robot = robot
        self.target_y = float(target_y)
        self.name = name

    def _coerce_point(self, q: np.ndarray) -> np.ndarray:
        q = np.asarray(q, dtype=float).reshape(-1)
        return q[:2].copy()

    def residual(self, q: np.ndarray) -> np.ndarray:
        q = self._coerce_point(q)
        return np.array([self.robot.fk(q)[1] - self.target_y], dtype=float)

    def jacobian(self, q: np.ndarray) -> np.ndarray:
        q = self._coerce_point(q)
        return self.robot.jacobian_xy(q)[1:2, :]

    def is_valid(self, q: np.ndarray, tol: float = 1e-6) -> bool:
        return float(np.linalg.norm(self.residual(q))) <= tol


class BenchmarkLeafFamily:
    def __init__(self, name: str, lambdas: List[float]):
        self.name = name
        self._lambdas = [float(v) for v in lambdas]

    def manifold(self, lam: float):
        raise NotImplementedError

    def sample_lambdas(self, context=None):
        return list(self._lambdas)

    def lambda_distance(self, lam_a, lam_b) -> float:
        return abs(float(lam_a) - float(lam_b))


class EndEffectorXFamily(BenchmarkLeafFamily):
    def __init__(self, name: str, robot: Planar2LinkKinematics, lambdas: List[float]):
        super().__init__(name=name, lambdas=lambdas)
        self.robot = robot

    def manifold(self, lam: float):
        return EndEffectorXManifold(
            robot=self.robot,
            target_x=float(lam),
            name=f"{self.name}_lambda_{lam:g}",
        )


class EndEffectorYFamily(BenchmarkLeafFamily):
    def __init__(self, name: str, robot: Planar2LinkKinematics, lambdas: List[float]):
        super().__init__(name=name, lambdas=lambdas)
        self.robot = robot

    def manifold(self, lam: float):
        return EndEffectorYManifold(
            robot=self.robot,
            target_y=float(lam),
            name=f"{self.name}_lambda_{lam:g}",
        )


# ============================================================
# Component-aware graph
# ============================================================

ComponentKey = Tuple[str, float, str]


@dataclass
class ComponentEdge:
    src: ComponentKey
    dst: ComponentKey
    transition_point: np.ndarray
    score: float
    candidate_index: int = 0


@dataclass
class ComponentGraph:
    adjacency: Dict[ComponentKey, List[ComponentEdge]] = field(default_factory=dict)

    def add_node(self, node: ComponentKey) -> None:
        self.adjacency.setdefault(node, [])

    def add_edge(self, edge: ComponentEdge) -> None:
        self.add_node(edge.src)
        self.add_node(edge.dst)
        self.adjacency[edge.src].append(edge)

    def neighbors(self, node: ComponentKey) -> List[ComponentEdge]:
        return self.adjacency.get(node, [])


# ============================================================
# Helpers
# ============================================================

def wrap_to_pi(angle: float) -> float:
    return (float(angle) + np.pi) % (2.0 * np.pi) - np.pi


def component_of_q(q: np.ndarray) -> str:
    q = np.asarray(q, dtype=float)
    return "up" if float(q[1]) >= 0.0 else "down"


def two_link_ik_solutions(robot, x: float, y: float):
    l1 = float(robot.l1)
    l2 = float(robot.l2)

    r2 = x * x + y * y
    cos_q2 = (r2 - l1 * l1 - l2 * l2) / (2.0 * l1 * l2)

    if cos_q2 < -1.0 - 1e-10 or cos_q2 > 1.0 + 1e-10:
        return []

    cos_q2 = np.clip(cos_q2, -1.0, 1.0)
    q2_candidates = [np.arccos(cos_q2), -np.arccos(cos_q2)]

    sols = []
    for q2 in q2_candidates:
        k1 = l1 + l2 * np.cos(q2)
        k2 = l2 * np.sin(q2)
        q1 = np.arctan2(y, x) - np.arctan2(k2, k1)

        q1 = wrap_to_pi(q1)
        q2 = wrap_to_pi(q2)
        q = np.array([q1, q2], dtype=float)

        duplicate = False
        for s in sols:
            if np.linalg.norm(q - s) < 1e-8:
                duplicate = True
                break
        if not duplicate:
            sols.append(q)

    return sols


def allowed_family_pair(fam_a_name: str, fam_b_name: str) -> bool:
    allowed = {
        ("left_x_family", "bridge_y_family"),
        ("bridge_y_family", "left_x_family"),
        ("bridge_y_family", "right_x_family"),
        ("right_x_family", "bridge_y_family"),
    }
    return (fam_a_name, fam_b_name) in allowed


def seed_points_fn(fam_a, lam_a, fam_b, lam_b):
    seeds = []

    vals = np.linspace(-np.pi, np.pi, 9)
    for q1 in vals:
        for q2 in vals:
            seeds.append(np.array([q1, q2], dtype=float))

    def add_ik_seeds(robot, x_target: float, y_target: float):
        sols = two_link_ik_solutions(robot, x_target, y_target)
        eps = 0.05
        for q in sols:
            seeds.append(q.copy())
            seeds.append(q + np.array([eps, 0.0]))
            seeds.append(q + np.array([-eps, 0.0]))
            seeds.append(q + np.array([0.0, eps]))
            seeds.append(q + np.array([0.0, -eps]))
            seeds.append(q + np.array([eps, eps]))
            seeds.append(q + np.array([-eps, -eps]))

    if fam_a.name.endswith("x_family") and fam_b.name.endswith("y_family"):
        add_ik_seeds(fam_a.robot, float(lam_a), float(lam_b))

    if fam_b.name.endswith("x_family") and fam_a.name.endswith("y_family"):
        add_ik_seeds(fam_b.robot, float(lam_b), float(lam_a))

    uniq = []
    for s in seeds:
        s = np.array([wrap_to_pi(s[0]), wrap_to_pi(s[1])], dtype=float)
        if not any(np.linalg.norm(s - t) < 1e-8 for t in uniq):
            uniq.append(s)

    return uniq


def build_restricted_leaf_graph_unaware(families, goal_point):
    graph = build_leaf_graph(
        families=families,
        project_newton=project_newton,
        seed_points_fn=seed_points_fn,
        goal_point=goal_point,
        max_candidates_per_pair=2,
    )

    filtered = {}
    for src, edges in graph.adjacency.items():
        kept = []
        for e in edges:
            if allowed_family_pair(e.src[0], e.dst[0]):
                kept.append(e)
        filtered[src] = kept
    graph.adjacency = filtered
    return graph


def build_component_aware_graph(
    families,
    goal_point: np.ndarray,
    max_candidates_per_pair: int = 4,
):
    graph = ComponentGraph()
    component_ids = ["up", "down"]

    family_nodes = []
    for fam in families:
        for lam in fam.sample_lambdas():
            family_nodes.append((fam, lam))

    for fam, lam in family_nodes:
        for comp in component_ids:
            graph.add_node((fam.name, float(lam), comp))

    for i, (fam_a, lam_a) in enumerate(family_nodes):
        for j in range(i + 1, len(family_nodes)):
            fam_b, lam_b = family_nodes[j]

            if not allowed_family_pair(fam_a.name, fam_b.name):
                continue

            result = find_leaf_transition(
                source_family=fam_a,
                source_lam=lam_a,
                target_family=fam_b,
                target_lam=lam_b,
                seeds=seed_points_fn(fam_a, lam_a, fam_b, lam_b),
                project_newton=project_newton,
                goal=goal_point,
            )

            if not result.success:
                continue

            kept = result.candidates[:max_candidates_per_pair]
            for k, cand in enumerate(kept):
                comp = component_of_q(cand.x)

                src = (fam_a.name, float(lam_a), comp)
                dst = (fam_b.name, float(lam_b), comp)

                graph.add_edge(
                    ComponentEdge(
                        src=src,
                        dst=dst,
                        transition_point=cand.x.copy(),
                        score=float(cand.score),
                        candidate_index=k,
                    )
                )
                graph.add_edge(
                    ComponentEdge(
                        src=dst,
                        dst=src,
                        transition_point=cand.x.copy(),
                        score=float(cand.score),
                        candidate_index=k,
                    )
                )

    return graph


def edge_cost_fn_unaware(edge) -> float:
    return 1.0 + edge.score


def edge_cost_fn_aware(edge: ComponentEdge) -> float:
    return 1.0 + edge.score


def shortest_component_route(graph: ComponentGraph, start: ComponentKey, goal: ComponentKey):
    pq = []
    heapq.heappush(pq, (0.0, start))

    dist = {start: 0.0}
    parent = {}
    parent_edge = {}

    while pq:
        g_cost, node = heapq.heappop(pq)

        if node == goal:
            break

        if g_cost > dist.get(node, float("inf")):
            continue

        for edge in graph.neighbors(node):
            step_cost = float(edge_cost_fn_aware(edge))
            new_cost = g_cost + step_cost

            if new_cost < dist.get(edge.dst, float("inf")):
                dist[edge.dst] = new_cost
                parent[edge.dst] = node
                parent_edge[edge.dst] = edge
                heapq.heappush(pq, (new_cost, edge.dst))

    if start == goal:
        return []

    if goal not in parent_edge:
        return None

    route = []
    cur = goal
    while cur != start:
        edge = parent_edge[cur]
        route.append(edge)
        cur = parent[cur]
    route.reverse()
    return route


def concatenate_steps(steps) -> np.ndarray:
    pts = []
    for i, step in enumerate(steps):
        path = np.asarray(step.path)
        if len(path) == 0:
            continue
        if i == 0:
            pts.extend(list(path))
        else:
            pts.extend(list(path[1:]))
    if not pts:
        return np.zeros((0, 2))
    return np.asarray(pts)


def plot_jointspace_families(ax, robot, families):
    q1 = np.linspace(-np.pi, np.pi, 300)
    q2 = np.linspace(-np.pi, np.pi, 300)
    Q1, Q2 = np.meshgrid(q1, q2)

    X = robot.l1 * np.cos(Q1) + robot.l2 * np.cos(Q1 + Q2)
    Y = robot.l1 * np.sin(Q1) + robot.l2 * np.sin(Q1 + Q2)

    for fam in families:
        for lam in fam.sample_lambdas():
            if fam.name.endswith("x_family"):
                ax.contour(Q1, Q2, X, levels=[lam], linewidths=1.0, alpha=0.30)
            elif fam.name.endswith("y_family"):
                ax.contour(Q1, Q2, Y, levels=[lam], linewidths=1.0, alpha=0.30)


def plot_workspace_path(ax, robot, q_path: np.ndarray, label: str, style="-"):
    if len(q_path) == 0:
        return
    ee = np.asarray([robot.fk(q) for q in q_path])
    ax.plot(ee[:, 0], ee[:, 1], style, lw=2.5, label=label)


# ============================================================
# Benchmark case
# ============================================================

@dataclass
class BenchmarkCase:
    start_family_name: str
    start_lam: float
    start_q: np.ndarray
    goal_family_name: str
    goal_lam: float
    goal_q: np.ndarray
    title: str


def build_benchmark():
    robot = Planar2LinkKinematics(l1=1.0, l2=1.0)

    # This is the earlier branch-mismatch case:
    # start is on the up branch of x=-1, goal is on the down branch of x=+1.
    # The component-unaware graph finds a nominal route,
    # but realization can fail because the first chosen transition lies on the wrong branch.
    start_q = np.array([0.5 * np.pi, 0.5 * np.pi], dtype=float)   # EE = (-1, 1), up
    goal_q = np.array([0.0, -0.5 * np.pi], dtype=float)           # EE = ( 1,-1), down

    families = [
        EndEffectorXFamily("left_x_family", robot, [-1.00, -0.80]),
        EndEffectorYFamily("bridge_y_family", robot, [-1.00, -0.50, 0.00, 0.50, 1.00]),
        EndEffectorXFamily("right_x_family", robot, [0.80, 1.00]),
    ]

    case = BenchmarkCase(
        start_family_name="left_x_family",
        start_lam=-1.0,
        start_q=start_q,
        goal_family_name="right_x_family",
        goal_lam=1.0,
        goal_q=goal_q,
        title="Example 40: component-unaware vs component-aware routing on branch mismatch",
    )
    return robot, families, case


# ============================================================
# Main
# ============================================================

def main():
    np.random.seed(7)

    robot, families, case = build_benchmark()

    start_state = LeafState(
        family_name=case.start_family_name,
        lam=case.start_lam,
        x=case.start_q.copy(),
    )

    # --------------------------------------------------------
    # Unaware graph
    # --------------------------------------------------------
    unaware_graph = build_restricted_leaf_graph_unaware(
        families=families,
        goal_point=case.goal_q.copy(),
    )

    unaware_start_key = (case.start_family_name, case.start_lam)
    unaware_goal_key = (case.goal_family_name, case.goal_lam)

    unaware_route = shortest_leaf_route(
        graph=unaware_graph,
        start=unaware_start_key,
        goal=unaware_goal_key,
        edge_cost_fn=edge_cost_fn_unaware,
    )

    unaware_realized = None
    if unaware_route is not None:
        family_map = {f.name: f for f in families}
        unaware_realized = realize_leaf_route(
            start_state=start_state,
            goal_point=case.goal_q.copy(),
            goal_family=family_map[case.goal_family_name],
            goal_lam=case.goal_lam,
            families=families,
            route_edges=unaware_route,
            step_size=0.08,
            local_planner_name="projection",
            local_planner_kwargs=dict(
                goal_tol=1e-3,
                max_iters=800,
                projection_tol=1e-10,
                projection_max_iters=50,
                projection_damping=1.0,
            ),
        )

    # --------------------------------------------------------
    # Aware graph
    # --------------------------------------------------------
    aware_graph = build_component_aware_graph(
        families=families,
        goal_point=case.goal_q.copy(),
        max_candidates_per_pair=4,
    )

    aware_start_key = (case.start_family_name, case.start_lam, component_of_q(case.start_q))
    aware_goal_key = (case.goal_family_name, case.goal_lam, component_of_q(case.goal_q))

    aware_route = shortest_component_route(
        graph=aware_graph,
        start=aware_start_key,
        goal=aware_goal_key,
    )

    print(f"\n{case.title}")
    print(f"start q = {np.round(case.start_q, 4)}  comp={component_of_q(case.start_q)}")
    print(f"goal  q = {np.round(case.goal_q, 4)}  comp={component_of_q(case.goal_q)}")
    print(f"start EE = {np.round(robot.fk(case.start_q), 4)}")
    print(f"goal  EE = {np.round(robot.fk(case.goal_q), 4)}")

    print("\n--- Component-unaware result ---")
    print(f"start_key = {unaware_start_key}")
    print(f"goal_key  = {unaware_goal_key}")
    if unaware_route is None:
        print("No nominal unaware route found.")
    else:
        seq = [f"{unaware_start_key[0]}[{unaware_start_key[1]}]"]
        for e in unaware_route:
            seq.append(f"{e.dst[0]}[{e.dst[1]}]")
        print("route = " + " -> ".join(seq))
        for i, e in enumerate(unaware_route):
            print(
                f"  edge {i}: {e.src} -> {e.dst}, "
                f"q_transition={np.round(e.transition_point, 4)}, "
                f"EE={np.round(robot.fk(e.transition_point), 4)}, "
                f"score={e.score:.4f}"
            )
        print(f"realization_success = {unaware_realized.success}")
        print(f"realization_message = {unaware_realized.message}")

    print("\n--- Component-aware result ---")
    print(f"start_key = {aware_start_key}")
    print(f"goal_key  = {aware_goal_key}")
    if aware_route is None:
        print("No component-aware route found.")
    else:
        seq = [f"{aware_start_key[0]}[{aware_start_key[1]}|{aware_start_key[2]}]"]
        for e in aware_route:
            fam, lam, comp = e.dst
            seq.append(f"{fam}[{lam}|{comp}]")
        print("route = " + " -> ".join(seq))
        for i, e in enumerate(aware_route):
            print(
                f"  edge {i}: {e.src} -> {e.dst}, "
                f"q_transition={np.round(e.transition_point, 4)}, "
                f"EE={np.round(robot.fk(e.transition_point), 4)}, "
                f"score={e.score:.4f}"
            )

    q_unaware = (
        concatenate_steps(unaware_realized.steps)
        if (unaware_realized is not None and unaware_realized.success)
        else np.zeros((0, 2))
    )

    fig, axes = plt.subplots(1, 2, figsize=(14, 6))

    ax = axes[0]
    plot_jointspace_families(ax, robot, families)
    if unaware_route is not None:
        for i, e in enumerate(unaware_route):
            ax.scatter(
                e.transition_point[0],
                e.transition_point[1],
                s=70,
                zorder=5,
                label="unaware transition" if i == 0 else None,
            )
    ax.scatter(case.start_q[0], case.start_q[1], s=90, marker="s", color="black", label="start")
    ax.scatter(case.goal_q[0], case.goal_q[1], s=120, marker="*", color="gold", edgecolor="black", label="goal")
    if len(q_unaware) > 0:
        ax.plot(q_unaware[:, 0], q_unaware[:, 1], "--", lw=2.5, label="unaware realized path")
    ax.set_title("Component-unaware route and realization")
    ax.set_xlabel("q1 [rad]")
    ax.set_ylabel("q2 [rad]")
    ax.set_xlim([-np.pi, np.pi])
    ax.set_ylim([-np.pi, np.pi])
    ax.grid(True, alpha=0.25)
    ax.legend()

    ax = axes[1]
    plot_jointspace_families(ax, robot, families)
    ax.scatter(case.start_q[0], case.start_q[1], s=90, marker="s", color="black", label="start")
    ax.scatter(case.goal_q[0], case.goal_q[1], s=120, marker="*", color="gold", edgecolor="black", label="goal")
    if aware_route is not None:
        for i, e in enumerate(aware_route):
            ax.scatter(
                e.transition_point[0],
                e.transition_point[1],
                s=70,
                zorder=5,
                label="aware transition" if i == 0 else None,
            )
    ax.set_title("Component-aware route selection")
    ax.set_xlabel("q1 [rad]")
    ax.set_ylabel("q2 [rad]")
    ax.set_xlim([-np.pi, np.pi])
    ax.set_ylim([-np.pi, np.pi])
    ax.grid(True, alpha=0.25)
    ax.legend()

    plt.tight_layout()
    plt.show()


if __name__ == "__main__":
    main()