from __future__ import annotations

from dataclasses import dataclass
from typing import Any
import numpy as np
import matplotlib.pyplot as plt

from primitive_manifold_planner.families.leaf_state import LeafState
from primitive_manifold_planner.planners.component_leaf_graph import shortest_component_route
from primitive_manifold_planner.planners.component_graph_with_transitions import (
    build_component_graph_with_transition_manager,
)
from primitive_manifold_planner.planners.realize_component_route_with_manager import (
    realize_component_route_with_manager,
)
from primitive_manifold_planner.projection import project_newton

from primitive_manifold_planner.examplesupport.planar2link import (
    Planar2LinkKinematics,
    component_of_q,
    wrap_q,
    torus_distance,
)
from primitive_manifold_planner.examplesupport.planar2link_families import (
    EndEffectorXFamily,
    EndEffectorYFamily,
    Joint2Family,
)
from primitive_manifold_planner.examplesupport.planar2link_helpers import (
    make_seed_points_fn,
    component_ids_for_family,
    compatible_components_for_leaf,
)


@dataclass
class RunResult:
    name: str
    route: Any | None
    realized: Any | None
    path_length: float


# Penalize the central switch connector neighborhood
FORBIDDEN_CENTER = np.array([2.0944, 0.0], dtype=float)
FORBIDDEN_RADIUS = 0.45


def in_forbidden_region(q: np.ndarray) -> bool:
    return torus_distance(q, FORBIDDEN_CENTER) <= FORBIDDEN_RADIUS


def graph_cost_nominal(edge) -> float:
    return 1.0 + float(edge.score)


def graph_cost_forbidden(edge) -> float:
    cost = 1.0 + float(edge.score)
    if in_forbidden_region(edge.transition_point):
        cost += 1000.0
    return cost


def transition_penalty_none(q: np.ndarray) -> float:
    return 0.0


def transition_penalty_forbidden(q: np.ndarray) -> float:
    return 1000.0 if in_forbidden_region(q) else 0.0


def total_path_length_from_steps(steps) -> float:
    total = 0.0
    for step in steps:
        path = np.asarray(step.path)
        if len(path) >= 2:
            total += float(np.sum(np.linalg.norm(np.diff(path, axis=0), axis=1)))
    return total


def concatenate_steps(steps) -> np.ndarray:
    pts = []
    for i, step in enumerate(steps):
        path = np.asarray(step.path)
        if len(path) == 0:
            continue
        if i == 0:
            pts.extend(list(path))
        else:
            pts.extend(list(path[1:]))
    if not pts:
        return np.zeros((0, 2))
    return np.asarray(pts)


def summarize_component_route(route_edges, start_key):
    seq = [f"{start_key[0]}[{start_key[1]}|{start_key[2]}]"]
    for e in route_edges:
        fam, lam, comp = e.dst
        seq.append(f"{fam}[{lam}|{comp}]")
    return " -> ".join(seq)


def plot_jointspace_families(ax, robot, families):
    q1 = np.linspace(-np.pi, np.pi, 400)
    q2 = np.linspace(-np.pi, np.pi, 400)
    Q1, Q2 = np.meshgrid(q1, q2)

    X = robot.l1 * np.cos(Q1) + robot.l2 * np.cos(Q1 + Q2)
    Y = robot.l1 * np.sin(Q1) + robot.l2 * np.sin(Q1 + Q2)

    for fam in families:
        for lam in fam.sample_lambdas():
            if fam.name.endswith("x_family"):
                ax.contour(Q1, Q2, X, levels=[lam], linewidths=1.0, alpha=0.28)
            elif fam.name.endswith("y_family"):
                ax.contour(Q1, Q2, Y, levels=[lam], linewidths=1.0, alpha=0.28)
            elif fam.name == "switch_q2_family":
                ax.axhline(float(lam), linewidth=1.0, alpha=0.35)


def plot_workspace_path(ax, robot, q_path: np.ndarray, label: str, style="-"):
    if len(q_path) == 0:
        return
    ee = np.asarray([robot.fk(q) for q in q_path])
    ax.plot(ee[:, 0], ee[:, 1], style, lw=2.3, label=label)


def component_ids_for_multi_switch_family(fam, lam: float):
    if fam.name == "switch_q2_family":
        # Still treated as switch-mode leaves
        return ["switch"]
    return ["up", "down"]


def compatible_components_for_multi_switch_leaf(fam, lam: float, q_transition: np.ndarray):
    q_comp = component_of_q(q_transition)

    if fam.name == "switch_q2_family":
        # Any transition on these switch-family leaves belongs to switch mode
        return ["switch"]

    if q_comp == "switch":
        return ["up", "down"]

    return [q_comp]


def allowed_multi_switch_pair(a: str, b: str) -> bool:
    allowed = {
        ("left_x_family", "switch_q2_family"),
        ("switch_q2_family", "left_x_family"),
        ("switch_q2_family", "bridge_y_family"),
        ("bridge_y_family", "switch_q2_family"),
        ("bridge_y_family", "right_x_family"),
        ("right_x_family", "bridge_y_family"),
    }
    return (a, b) in allowed


def build_problem():
    robot = Planar2LinkKinematics(l1=1.0, l2=1.0)

    start_q = np.array([0.5 * np.pi, 0.5 * np.pi], dtype=float)   # up
    goal_q = np.array([0.0, -0.5 * np.pi], dtype=float)           # down

    families = [
        EndEffectorXFamily("left_x_family", robot, [-1.00]),
        Joint2Family("switch_q2_family", [-0.2, 0.0, 0.2]),
        EndEffectorYFamily("bridge_y_family", robot, [-1.00]),
        EndEffectorXFamily("right_x_family", robot, [1.00]),
    ]

    return robot, families, wrap_q(start_q), wrap_q(goal_q)


def run_once(name, graph, manager, families, start_state, start_comp, goal_q, goal_comp, graph_edge_cost, transition_penalty_fn):
    route = shortest_component_route(
        graph=graph,
        start=(start_state.family_name, float(start_state.lam), start_comp),
        goal=("right_x_family", 1.0, goal_comp),
        edge_cost_fn=graph_edge_cost,
    )

    if route is None:
        return RunResult(name=name, route=None, realized=None, path_length=0.0)

    realized = realize_component_route_with_manager(
        transition_manager=manager,
        start_state=start_state,
        start_component=start_comp,
        goal_q=goal_q.copy(),
        families=families,
        route_edges=route,
        step_size=0.08,
        local_planner_name="projection",
        local_planner_kwargs=dict(
            goal_tol=1e-3,
            max_iters=1200,
            projection_tol=1e-10,
            projection_max_iters=50,
            projection_damping=1.0,
        ),
        wrap_state_fn=wrap_q,
        state_distance_fn=torus_distance,
        transition_penalty_fn=transition_penalty_fn,
    )

    path_length = total_path_length_from_steps(realized.steps) if realized.success else 0.0
    return RunResult(name=name, route=route, realized=realized, path_length=path_length)


def main():
    np.random.seed(7)

    robot, families, start_q, goal_q = build_problem()
    start_state = LeafState("left_x_family", -1.0, start_q.copy())
    start_comp = component_of_q(start_q)
    goal_comp = component_of_q(goal_q)

    graph, manager = build_component_graph_with_transition_manager(
        families=families,
        project_newton=project_newton,
        seed_points_fn=make_seed_points_fn(robot),
        goal_point=goal_q.copy(),
        component_ids_for_family_fn=component_ids_for_multi_switch_family,
        compatible_components_fn=compatible_components_for_multi_switch_leaf,
        allowed_family_pair_fn=allowed_multi_switch_pair,
        max_candidates_per_pair=12,
    )

    nominal = run_once(
        name="nominal",
        graph=graph,
        manager=manager,
        families=families,
        start_state=start_state,
        start_comp=start_comp,
        goal_q=goal_q,
        goal_comp=goal_comp,
        graph_edge_cost=graph_cost_nominal,
        transition_penalty_fn=transition_penalty_none,
    )

    penalty_aware = run_once(
        name="penalty-aware",
        graph=graph,
        manager=manager,
        families=families,
        start_state=start_state,
        start_comp=start_comp,
        goal_q=goal_q,
        goal_comp=goal_comp,
        graph_edge_cost=graph_cost_forbidden,
        transition_penalty_fn=transition_penalty_forbidden,
    )

    print("\nExample 50: multi-switch family demo\n")
    print(f"start q = {np.round(start_q, 4)} comp={start_comp}")
    print(f"goal  q = {np.round(goal_q, 4)} comp={goal_comp}")
    print(f"switch family lambdas = [-0.2, 0.0, 0.2]")
    print(f"forbidden center = {np.round(FORBIDDEN_CENTER, 4)}")
    print(f"forbidden radius = {FORBIDDEN_RADIUS:.3f}\n")

    for result in [nominal, penalty_aware]:
        print(f"--- {result.name} ---")
        print("route_found         =", result.route is not None)
        if result.route is not None:
            print("route               =", summarize_component_route(
                result.route,
                ("left_x_family", -1.0, start_comp),
            ))
        if result.realized is not None:
            print("realization_success =", result.realized.success)
            print("path_length         =", f"{result.path_length:.4f}")
            print("message             =", result.realized.message)
            for i, step in enumerate(result.realized.steps):
                print(
                    f"  step {i}: family={step.family_name}[{step.lam}|{step.component_id}], "
                    f"transition={None if step.transition_point is None else np.round(step.transition_point, 4)}, "
                    f"msg={step.message}"
                )
        print()

    q_nominal = (
        concatenate_steps(nominal.realized.steps)
        if (nominal.realized is not None and nominal.realized.success)
        else np.zeros((0, 2))
    )
    q_penalty = (
        concatenate_steps(penalty_aware.realized.steps)
        if (penalty_aware.realized is not None and penalty_aware.realized.success)
        else np.zeros((0, 2))
    )

    fig, axes = plt.subplots(1, 3, figsize=(18, 6))

    ax = axes[0]
    plot_jointspace_families(ax, robot, families)
    circle = plt.Circle(FORBIDDEN_CENTER, FORBIDDEN_RADIUS, fill=False, linestyle="--")
    ax.add_patch(circle)

    if len(q_nominal) > 0:
        ax.plot(q_nominal[:, 0], q_nominal[:, 1], "--", lw=2.3, label="nominal path")
    if len(q_penalty) > 0:
        ax.plot(q_penalty[:, 0], q_penalty[:, 1], lw=2.8, label="penalty-aware path")

    if nominal.realized is not None:
        for i, step in enumerate(nominal.realized.steps[:-1]):
            if step.transition_point is not None:
                ax.scatter(
                    step.transition_point[0],
                    step.transition_point[1],
                    s=60,
                    marker="o",
                    label="nominal transitions" if i == 0 else None,
                )

    if penalty_aware.realized is not None:
        for i, step in enumerate(penalty_aware.realized.steps[:-1]):
            if step.transition_point is not None:
                ax.scatter(
                    step.transition_point[0],
                    step.transition_point[1],
                    s=70,
                    marker="x",
                    label="penalty-aware transitions" if i == 0 else None,
                )

    ax.scatter(start_q[0], start_q[1], s=90, marker="s", color="black", label="start")
    ax.scatter(goal_q[0], goal_q[1], s=120, marker="*", color="gold", edgecolor="black", label="goal")
    ax.set_title("Joint space")
    ax.set_xlim([-np.pi, np.pi])
    ax.set_ylim([-np.pi, np.pi])
    ax.grid(True, alpha=0.25)
    ax.legend()

    ax = axes[1]
    plot_workspace_path(ax, robot, q_nominal, label="nominal EE path", style="--")
    plot_workspace_path(ax, robot, q_penalty, label="penalty-aware EE path", style="-")
    ax.scatter(*robot.fk(start_q), s=90, marker="s", color="black", label="start EE")
    ax.scatter(*robot.fk(goal_q), s=120, marker="*", color="gold", edgecolor="black", label="goal EE")
    ax.set_title("Workspace interpretation")
    ax.set_aspect("equal")
    ax.grid(True, alpha=0.25)
    ax.legend()

    ax = axes[2]
    names = ["nominal", "penalty-aware"]
    vals = [
        nominal.path_length if nominal.realized is not None and nominal.realized.success else 0.0,
        penalty_aware.path_length if penalty_aware.realized is not None and penalty_aware.realized.success else 0.0,
    ]
    ax.bar(names, vals)
    for i, v in enumerate(vals):
        ax.text(i, v + 0.15, f"{v:.2f}", ha="center", va="bottom")
    ax.set_ylabel("Path length")
    ax.set_title("Path length comparison")

    plt.tight_layout()
    plt.show()


if __name__ == "__main__":
    main()