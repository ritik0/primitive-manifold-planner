from __future__ import annotations

from dataclasses import dataclass
import numpy as np
import matplotlib.pyplot as plt

from primitive_manifold_planner.families.leaf_state import LeafState
from primitive_manifold_planner.families.standard import PlaneFamily, SphereFamily
from primitive_manifold_planner.manifolds import PlaneManifold, SphereManifold
from primitive_manifold_planner.planners.admissibility import (
    build_semantic_target_progress_point_fn,
    ProgressTargetSelectionConfig,
)
from primitive_manifold_planner.planners.plan_foliated_route import plan_foliated_route
from primitive_manifold_planner.projection import project_newton


@dataclass
class Transfer3DCase:
    start_family_name: str
    start_lam: float
    start_point: np.ndarray
    goal_family_name: str
    goal_lam: float
    goal_point: np.ndarray
    title: str


def sphere_point(center: np.ndarray, radius: float, azimuth_deg: float, elevation_deg: float) -> np.ndarray:
    az = np.deg2rad(float(azimuth_deg))
    el = np.deg2rad(float(elevation_deg))
    direction = np.array(
        [
            np.cos(el) * np.cos(az),
            np.cos(el) * np.sin(az),
            np.sin(el),
        ],
        dtype=float,
    )
    return np.asarray(center, dtype=float) + float(radius) * direction


def build_minimal_3d_transfer_benchmark():
    def transfer_cost(
        lam: float,
        point: np.ndarray,
        goal_point: np.ndarray | None = None,
        metadata: dict | None = None,
    ) -> float:
        _ = lam, metadata
        q = np.asarray(point, dtype=float)
        goal = None if goal_point is None else np.asarray(goal_point, dtype=float)
        cost = 0.20 * abs(float(q[1]))
        if goal is not None:
            cost += 0.08 * float(np.linalg.norm(q - goal))
        return float(cost)

    def transfer_feasibility(
        lam: float,
        point: np.ndarray,
        goal_point: np.ndarray | None = None,
        metadata: dict | None = None,
    ) -> bool:
        _ = lam, goal_point, metadata
        q = np.asarray(point, dtype=float)
        return bool(-1.05 <= float(q[0]) <= 1.05 and -0.75 <= float(q[1]) <= 0.75)

    left_support = SphereFamily(
        name="left_support_3d",
        center=np.array([-1.80, 0.0, 0.45], dtype=float),
        radii={1.20: 1.20},
    )
    transfer_plane = PlaneFamily(
        name="transfer_plane_3d",
        base_point=np.array([0.0, 0.0, 0.0], dtype=float),
        normal=np.array([0.0, 0.0, 1.0], dtype=float),
        offsets=[0.0],
        anchor_span=1.0,
        admissibility_cost_fn=transfer_cost,
        feasibility_fn=transfer_feasibility,
    )
    right_support = SphereFamily(
        name="right_support_3d",
        center=np.array([1.80, 0.0, 0.45], dtype=float),
        radii={1.20: 1.20},
    )

    families = [left_support, transfer_plane, right_support]

    start_point = sphere_point(left_support.center, 1.20, azimuth_deg=-30.0, elevation_deg=-35.0)
    goal_point = sphere_point(right_support.center, 1.20, azimuth_deg=210.0, elevation_deg=-35.0)

    case = Transfer3DCase(
        start_family_name="left_support_3d",
        start_lam=1.20,
        start_point=start_point,
        goal_family_name="right_support_3d",
        goal_lam=1.20,
        goal_point=goal_point,
        title="Minimal 3D support-transfer-support pilot",
    )

    allowed_family_transitions = {
        "left_support_3d": ["transfer_plane_3d"],
        "transfer_plane_3d": ["right_support_3d"],
        "right_support_3d": [],
    }

    return families, case, allowed_family_transitions


def concatenate_steps(steps) -> np.ndarray:
    pts = []
    for i, step in enumerate(steps):
        path = np.asarray(step.path)
        if len(path) == 0:
            continue
        if i == 0:
            pts.extend(list(path))
        else:
            pts.extend(list(path[1:]))
    if not pts:
        return np.zeros((0, 3))
    return np.asarray(pts)


def total_path_length_from_steps(steps) -> float:
    total = 0.0
    for step in steps:
        path = np.asarray(step.path)
        if len(path) >= 2:
            total += float(np.sum(np.linalg.norm(np.diff(path, axis=0), axis=1)))
    return total


def summarize_leaf_sequence(result) -> str:
    seq = []
    for step in result.steps:
        node = f"{step.family_name}[{step.lam}]"
        if not seq or seq[-1] != node:
            seq.append(node)
    return " -> ".join(seq)


def print_plan_summary(result):
    print("\n=== Example 57 result ===")
    print(f"success      : {result.success}")
    print(f"message      : {result.message}")
    print(f"num steps    : {len(result.steps)}")
    print(f"path length  : {total_path_length_from_steps(result.steps):.4f}")
    print(f"leaf sequence: {summarize_leaf_sequence(result)}")

    for i, step in enumerate(result.steps):
        step_path = np.asarray(step.path)
        path_len = 0.0
        if len(step_path) >= 2:
            path_len = float(np.sum(np.linalg.norm(np.diff(step_path, axis=0), axis=1)))
        print(
            f"  step {i:02d} | kind={step.kind:>6s} | "
            f"family={step.family_name}[{step.lam}] | "
            f"planner={getattr(step, 'planner_name', 'unknown')} | "
            f"len={path_len:.4f}"
        )


def plot_manifold_3d(ax, manifold, color="lightgray", alpha=0.16):
    if isinstance(manifold, SphereManifold):
        u = np.linspace(0.0, 2.0 * np.pi, 40)
        v = np.linspace(0.0, np.pi, 25)
        x = manifold.center[0] + manifold.radius * np.outer(np.cos(u), np.sin(v))
        y = manifold.center[1] + manifold.radius * np.outer(np.sin(u), np.sin(v))
        z = manifold.center[2] + manifold.radius * np.outer(np.ones_like(u), np.cos(v))
        ax.plot_wireframe(x, y, z, color=color, alpha=alpha, rstride=2, cstride=2, linewidth=0.7)
    elif isinstance(manifold, PlaneManifold):
        span = 1.15
        xx = np.linspace(-span, span, 15)
        yy = np.linspace(-0.8, 0.8, 12)
        X, Y = np.meshgrid(xx, yy)
        Z = np.zeros_like(X) + manifold.point[2]
        ax.plot_surface(X, Y, Z, color=color, alpha=alpha, linewidth=0.0, shade=False)


def main():
    np.random.seed(13)

    families, case, allowed_family_transitions = build_minimal_3d_transfer_benchmark()
    family_map = {f.name: f for f in families}
    goal_family = family_map[case.goal_family_name]

    start_state = LeafState(
        family_name=case.start_family_name,
        lam=case.start_lam,
        x=case.start_point.copy(),
    )

    result = plan_foliated_route(
        start_state=start_state,
        goal_point=case.goal_point.copy(),
        goal_family=goal_family,
        goal_lam=case.goal_lam,
        families=families,
        project_newton=project_newton,
        max_switches=3,
        local_step_size=0.10,
        progress_tol=1e-4,
        local_planner_name="projection",
        local_planner_kwargs=dict(
            goal_tol=1e-3,
            max_iters=800,
            projection_tol=1e-10,
            projection_max_iters=60,
            projection_damping=1.0,
        ),
        allowed_family_transitions=allowed_family_transitions,
        goal_leaf_mismatch_penalty=10.0,
        target_progress_point_fn=build_semantic_target_progress_point_fn(
            ProgressTargetSelectionConfig(
                goal_distance_weight=1.0,
                admissibility_weight=1.5,
            )
        ),
    )

    print(f"\nRunning {case.title}")
    print(f"start = {case.start_family_name}[{case.start_lam}] at {np.round(case.start_point, 4)}")
    print(f"goal  = {case.goal_family_name}[{case.goal_lam}] at {np.round(case.goal_point, 4)}")
    print(f"allowed transitions = {allowed_family_transitions}")
    print_plan_summary(result)

    fig = plt.figure(figsize=(10, 8))
    ax = fig.add_subplot(111, projection="3d")

    color_map = {
        "left_support_3d": "#b87333",
        "transfer_plane_3d": "#7fa7c6",
        "right_support_3d": "#b87333",
    }
    for fam in families:
        for lam in fam.sample_lambdas():
            plot_manifold_3d(ax, fam.manifold(lam), color=color_map.get(fam.name, "lightgray"))

    q_path = concatenate_steps(result.steps)
    if len(q_path) > 0:
        ax.plot(q_path[:, 0], q_path[:, 1], q_path[:, 2], color="#1565c0", linewidth=3.0, label="realized path")

    for step in result.steps:
        if step.transition is not None:
            tp = np.asarray(step.transition.x, dtype=float)
            ax.scatter(tp[0], tp[1], tp[2], s=65, marker="x", color="black")

    ax.scatter(case.start_point[0], case.start_point[1], case.start_point[2], s=90, marker="s", color="black", label="start")
    ax.scatter(case.goal_point[0], case.goal_point[1], case.goal_point[2], s=130, marker="*", color="gold", edgecolor="black", label="goal")

    ax.set_xlabel("x")
    ax.set_ylabel("y")
    ax.set_zlabel("z")
    ax.set_title("Example 57: minimal 3D support-transfer-support pilot")
    ax.legend()
    ax.view_init(elev=24, azim=-58)
    plt.tight_layout()
    plt.show()


if __name__ == "__main__":
    main()
