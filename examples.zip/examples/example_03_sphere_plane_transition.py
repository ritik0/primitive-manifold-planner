from __future__ import annotations

import numpy as np
import matplotlib.pyplot as plt

from primitive_manifold_planner.manifolds import SphereManifold, PlaneManifold
from primitive_manifold_planner.planning import random_transition_search
from primitive_manifold_planner.visualization import (
    finalize_3d_axes,
    plot_plane_patch,
    plot_point_3d,
    plot_sphere_manifold,
)


def main() -> None:
    # Define manifolds
    sphere = SphereManifold(
        center=np.array([0.0, 0.0, 0.0]),
        radius=2.0,
        name="sphere",
    )

    plane = PlaneManifold(
        point=np.array([0.0, 0.0, 1.0]),
        normal=np.array([0.0, 0.0, 1.0]),
        name="plane z=1",
    )

    # Search for a transition point
    rng = np.random.default_rng(42)
    result = random_transition_search(
        manifold_a=sphere,
        manifold_b=plane,
        bounds_min=np.array([-3.0, -3.0, -3.0]),
        bounds_max=np.array([3.0, 3.0, 3.0]),
        num_seeds=40,
        tol=1e-8,
        rng=rng,
    )

    print("=== Sphere-plane transition search ===")
    print(f"Success        : {result.success}")
    print(f"Residual norm  : {result.residual_norm:.6e}")
    print(f"Message        : {result.message}")
    print(f"Seed used      : {result.seed_used}")

    if result.x_transition is not None:
        x = result.x_transition
        print(f"Transition     : {x}")
        print(f"Sphere residual: {sphere.residual(x)[0]:.6e}")
        print(f"Plane residual : {plane.residual(x)[0]:.6e}")

    # Plot
    fig = plt.figure(figsize=(8, 7))
    ax = fig.add_subplot(111, projection="3d")

    plot_sphere_manifold(ax, sphere, alpha=0.25, label="sphere")
    plot_plane_patch(ax, plane, xlim=(-2.5, 2.5), ylim=(-2.5, 2.5), alpha=0.25, label="plane")

    if result.x_transition is not None:
        plot_point_3d(ax, result.x_transition, label="transition", s=80)

    finalize_3d_axes(ax, title="Sphere-plane transition point")
    plt.show()


if __name__ == "__main__":
    main()