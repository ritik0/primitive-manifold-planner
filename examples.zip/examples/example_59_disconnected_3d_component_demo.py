from __future__ import annotations

from dataclasses import dataclass
import numpy as np
import matplotlib.pyplot as plt

from primitive_manifold_planner.families.leaf_state import LeafState
from primitive_manifold_planner.families.standard import MaskedFamily, PlaneFamily, SphereFamily
from primitive_manifold_planner.manifolds import MaskedManifold, PlaneManifold, SphereManifold
from primitive_manifold_planner.planners.component_discovery import (
    StaticComponentModel,
    build_component_model_registry,
)
from primitive_manifold_planner.planners.mode_semantics import PlanningSemanticContext
from primitive_manifold_planner.planners.multimodal_component_planner import (
    MultimodalComponentPlanner,
    PlannerConfig,
)
from primitive_manifold_planner.planners.semantic_templates import (
    build_support_transfer_goal_semantic_model,
)
from primitive_manifold_planner.projection import project_newton


@dataclass
class DemoCase:
    name: str
    start_state: LeafState
    goal_family_name: str
    goal_lam: float
    goal_q: np.ndarray


def sample_leaf_points_3d(manifold, grid_x, grid_y, grid_z, tol=1e-3):
    pts = []
    for x in grid_x:
        for y in grid_y:
            for z in grid_z:
                q = np.array([x, y, z], dtype=float)
                try:
                    proj = project_newton(
                        manifold=manifold,
                        x0=q,
                        tol=1e-10,
                        max_iters=60,
                        damping=1.0,
                    )
                except Exception:
                    continue
                if not proj.success:
                    continue
                q_proj = np.asarray(proj.x_projected, dtype=float)
                if not manifold.is_valid(q_proj, tol=tol):
                    continue
                duplicate = False
                for p in pts:
                    if np.linalg.norm(q_proj - p) < 8e-2:
                        duplicate = True
                        break
                if not duplicate:
                    pts.append(q_proj)
    if len(pts) == 0:
        return np.zeros((0, 3))
    return np.asarray(pts)


def sphere_point(center: np.ndarray, radius: float, azimuth_deg: float, elevation_deg: float) -> np.ndarray:
    az = np.deg2rad(float(azimuth_deg))
    el = np.deg2rad(float(elevation_deg))
    direction = np.array(
        [
            np.cos(el) * np.cos(az),
            np.cos(el) * np.sin(az),
            np.sin(el),
        ],
        dtype=float,
    )
    return np.asarray(center, dtype=float) + float(radius) * direction


def build_demo():
    base_support = SphereFamily(
        name="support_surface_3d",
        center=np.array([-1.50, 0.0, 0.35], dtype=float),
        radii={1.05: 1.05},
    )

    def support_mask(lam: float, q: np.ndarray) -> bool:
        _ = lam
        x = float(q[0])
        y = float(q[1])
        return bool(
            ((-2.55 <= x <= -1.85) and (-0.60 <= y <= 0.60))
            or ((-1.10 <= x <= -0.30) and (-0.60 <= y <= 0.60))
        )

    disconnected_support = MaskedFamily(
        base_family=base_support,
        validity_mask_fn=support_mask,
        name="disconnected_support_3d",
    )
    transfer_plane = PlaneFamily(
        name="transfer_plane_3d",
        base_point=np.array([0.0, 0.0, 0.0], dtype=float),
        normal=np.array([0.0, 0.0, 1.0], dtype=float),
        offsets=[0.0],
        anchor_span=1.0,
        feasibility_fn=lambda lam, point, goal, meta: bool(-0.95 <= float(point[0]) <= 1.1 and -0.7 <= float(point[1]) <= 0.7),
    )
    goal_support = SphereFamily(
        name="goal_support_3d",
        center=np.array([1.65, 0.0, 0.35], dtype=float),
        radii={1.00: 1.00},
    )
    families = [disconnected_support, transfer_plane, goal_support]

    goal_q = sphere_point(goal_support.center, 1.00, azimuth_deg=210.0, elevation_deg=-32.0)

    reachable_start = sphere_point(base_support.center, 1.05, azimuth_deg=-18.0, elevation_deg=-38.0)
    unreachable_start = sphere_point(base_support.center, 1.05, azimuth_deg=192.0, elevation_deg=-38.0)

    cases = [
        DemoCase(
            name="reachable component",
            start_state=LeafState("disconnected_support_3d", 1.05, reachable_start.copy()),
            goal_family_name="goal_support_3d",
            goal_lam=1.00,
            goal_q=goal_q.copy(),
        ),
        DemoCase(
            name="unreachable component",
            start_state=LeafState("disconnected_support_3d", 1.05, unreachable_start.copy()),
            goal_family_name="goal_support_3d",
            goal_lam=1.00,
            goal_q=goal_q.copy(),
        ),
    ]

    return families, cases, support_mask, base_support


def build_semantic_model():
    def semantic_feasibility(context: PlanningSemanticContext) -> bool:
        if context.point is None:
            return True
        involved = {context.source_family_name, context.target_family_name}
        if "transfer_plane_3d" not in involved:
            return True
        q = np.asarray(context.point, dtype=float)
        return bool(-0.95 <= float(q[0]) <= 1.1 and -0.7 <= float(q[1]) <= 0.7)

    def semantic_admissibility(context: PlanningSemanticContext) -> float:
        if context.point is None:
            return 0.0
        involved = {context.source_family_name, context.target_family_name}
        if "transfer_plane_3d" not in involved:
            return 0.0
        q = np.asarray(context.point, dtype=float)
        goal = None if context.goal_point is None else np.asarray(context.goal_point, dtype=float)
        cost = 0.08 * abs(float(q[1]))
        if goal is not None:
            cost += 0.05 * float(np.linalg.norm(q - goal))
        return float(cost)

    return build_support_transfer_goal_semantic_model(
        support_families=["disconnected_support_3d"],
        transfer_families=["transfer_plane_3d"],
        goal_support_families=["goal_support_3d"],
        transition_feasibility_fn=semantic_feasibility,
        transition_admissibility_fn=semantic_admissibility,
    )


def build_component_registry(families):
    grid_x = np.linspace(-3.0, 2.8, 19)
    grid_y = np.linspace(-1.3, 1.3, 15)
    grid_z = np.linspace(-0.8, 1.6, 15)

    def seed_samples_for_leaf(fam, lam: float):
        return sample_leaf_points_3d(fam.manifold(lam), grid_x, grid_y, grid_z, tol=1e-3)

    def should_discover(fam, lam: float) -> bool:
        _ = lam
        return fam.name == "disconnected_support_3d"

    def static_model_for_leaf(fam, lam: float):
        _ = lam
        if fam.name in {"transfer_plane_3d", "goal_support_3d"}:
            return StaticComponentModel(ids=["0"])
        return None

    registry, discovered = build_component_model_registry(
        families=families,
        seed_samples_for_leaf_fn=seed_samples_for_leaf,
        should_discover_fn=should_discover,
        static_model_fn=static_model_for_leaf,
        local_planner_name="projection",
        local_planner_kwargs=dict(
            goal_tol=1e-3,
            max_iters=500,
            projection_tol=1e-10,
            projection_max_iters=60,
            projection_damping=1.0,
        ),
        step_size=0.10,
        neighbor_radius=0.38,
    )
    return registry, discovered


def seed_points_fn(source_family, source_lam, target_family, target_lam):
    src = source_family.transition_seed_anchors(source_lam)
    dst = target_family.transition_seed_anchors(target_lam)
    return [np.asarray(p, dtype=float).copy() for p in list(src) + list(dst)]


def plot_manifold(ax, manifold, color="lightgray", alpha=0.14):
    if isinstance(manifold, SphereManifold):
        u = np.linspace(0.0, 2.0 * np.pi, 36)
        v = np.linspace(0.0, np.pi, 20)
        x = manifold.center[0] + manifold.radius * np.outer(np.cos(u), np.sin(v))
        y = manifold.center[1] + manifold.radius * np.outer(np.sin(u), np.sin(v))
        z = manifold.center[2] + manifold.radius * np.outer(np.ones_like(u), np.cos(v))
        ax.plot_wireframe(x, y, z, color=color, alpha=alpha, rstride=2, cstride=2, linewidth=0.6)
    elif isinstance(manifold, PlaneManifold):
        xx = np.linspace(-0.95, 1.1, 14)
        yy = np.linspace(-0.7, 0.7, 10)
        X, Y = np.meshgrid(xx, yy)
        Z = np.zeros_like(X) + manifold.point[2]
        ax.plot_surface(X, Y, Z, color=color, alpha=alpha, linewidth=0.0, shade=False)
    elif isinstance(manifold, MaskedManifold) and isinstance(manifold.base_manifold, SphereManifold):
        base = manifold.base_manifold
        u = np.linspace(0.0, 2.0 * np.pi, 40)
        v = np.linspace(0.0, np.pi, 24)
        pts = []
        for uu in u:
            for vv in v:
                p = base.center + base.radius * np.array(
                    [np.cos(uu) * np.sin(vv), np.sin(uu) * np.sin(vv), np.cos(vv)],
                    dtype=float,
                )
                if manifold.within_bounds(p):
                    pts.append(p)
        if pts:
            pts = np.asarray(pts)
            ax.scatter(pts[:, 0], pts[:, 1], pts[:, 2], s=6, color=color, alpha=alpha)


def concatenate_realization(realization):
    pts = []
    for i, step in enumerate(realization.steps):
        path = np.asarray(step.path)
        if len(path) == 0:
            continue
        if i == 0:
            pts.extend(list(path))
        else:
            pts.extend(list(path[1:]))
    if not pts:
        return np.zeros((0, 3))
    return np.asarray(pts)


def main():
    np.random.seed(19)

    families, cases, _, _ = build_demo()
    component_registry, discovered = build_component_registry(families)
    semantic_model = build_semantic_model()

    planner = MultimodalComponentPlanner(
        families=families,
        project_newton=project_newton,
        seed_points_fn=seed_points_fn,
        component_model_registry=component_registry,
        config=PlannerConfig(
            semantic_model=semantic_model,
            local_planner_name="projection",
            local_planner_kwargs=dict(
                goal_tol=1e-3,
                max_iters=900,
                projection_tol=1e-10,
                projection_max_iters=60,
                projection_damping=1.0,
            ),
            step_size=0.10,
            max_candidates_per_pair=8,
        ),
    )

    results = []
    for case in cases:
        result = planner.plan_with_inferred_components(
            start_state=case.start_state,
            goal_family_name=case.goal_family_name,
            goal_lam=case.goal_lam,
            goal_q=case.goal_q.copy(),
        )
        start_comp = planner.infer_component(case.start_state.family_name, case.start_state.lam, case.start_state.x)
        goal_comp = planner.infer_component(case.goal_family_name, case.goal_lam, case.goal_q)
        results.append((case, result, start_comp, goal_comp))

        print(f"\nExample 59: {case.name}")
        print(f"start component = {start_comp}")
        print(f"goal component  = {goal_comp}")
        print(f"route_found = {result.route_found}")
        print(f"realization_success = {result.realization_success}")
        print(f"message = {result.message}")
        print(f"route = {result.diagnostics.selected_route_string}")

    fig = plt.figure(figsize=(11, 8))
    ax = fig.add_subplot(111, projection="3d")
    colors = {
        "disconnected_support_3d": "#c58b4c",
        "transfer_plane_3d": "#88a8c6",
        "goal_support_3d": "#c58b4c",
    }
    for fam in families:
        for lam in fam.sample_lambdas():
            plot_manifold(ax, fam.manifold(lam), color=colors.get(fam.name, "lightgray"))

    disc = discovered.get(("disconnected_support_3d", 1.05))
    if disc is not None:
        comp_colors = ["#1f77b4", "#2ca02c", "#d62728"]
        for comp in disc.components:
            pts = np.asarray(comp.samples)
            ax.scatter(
                pts[:, 0], pts[:, 1], pts[:, 2],
                s=18,
                alpha=0.55,
                color=comp_colors[comp.component_id % len(comp_colors)],
                label=f"discovered comp {comp.component_id}",
            )

    line_styles = ["-", "--"]
    for idx, (case, result, _, _) in enumerate(results):
        if result.realization is not None and result.realization.success:
            path = concatenate_realization(result.realization)
            if len(path) > 0:
                ax.plot(
                    path[:, 0], path[:, 1], path[:, 2],
                    linewidth=3.0,
                    linestyle=line_styles[idx % len(line_styles)],
                    label=f"{case.name} path",
                )
        ax.scatter(case.start_state.x[0], case.start_state.x[1], case.start_state.x[2], s=80, marker="s", color="black")
        ax.scatter(case.goal_q[0], case.goal_q[1], case.goal_q[2], s=120, marker="*", color="gold", edgecolor="black")

    ax.set_xlabel("x")
    ax.set_ylabel("y")
    ax.set_zlabel("z")
    ax.set_title("Example 59: disconnected valid regions on a 3D support leaf")
    ax.legend(loc="upper right")
    ax.view_init(elev=24, azim=-58)
    plt.tight_layout()
    plt.show()


if __name__ == "__main__":
    main()
