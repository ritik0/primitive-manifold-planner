from __future__ import annotations

import numpy as np
import matplotlib
matplotlib.use("TkAgg")
import matplotlib.pyplot as plt

from primitive_manifold_planner.manifolds import ConcentricCircleFamily
from primitive_manifold_planner.visualization import finalize_2d_axes, plot_circle_manifold


def main() -> None:
    family = ConcentricCircleFamily(name="concentric_circles")
    lambdas = family.sample_lambdas(1.0, 3.0, 5)

    print("=== Concentric circle family ===")
    print("Sampled lambdas:", lambdas)

    fig, ax = plt.subplots(figsize=(8, 8))

    for lam in lambdas:
        leaf = family.leaf(lam)
        plot_circle_manifold(ax, leaf, label=leaf.name)

    ax.scatter([0.0], [0.0], s=80, label="center")
    finalize_2d_axes(ax, title="Concentric circle family: curved leaf-family benchmark")

    out_path = "example_09_concentric_circle_family.png"
    plt.savefig(out_path, dpi=200, bbox_inches="tight")
    print(f"Saved figure to: {out_path}")

    plt.show(block=True)


if __name__ == "__main__":
    main()