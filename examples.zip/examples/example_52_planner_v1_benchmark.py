from __future__ import annotations

from dataclasses import dataclass
from typing import List
import numpy as np

from primitive_manifold_planner.families.leaf_state import LeafState
from primitive_manifold_planner.planners.multimodal_component_planner import (
    MultimodalComponentPlanner,
    PlannerConfig,
)
from primitive_manifold_planner.projection import project_newton

from primitive_manifold_planner.examplesupport.planar2link import (
    Planar2LinkKinematics,
    component_of_q,
    wrap_q,
    torus_distance,
)
from primitive_manifold_planner.examplesupport.planar2link_families import (
    EndEffectorXFamily,
    EndEffectorYFamily,
    Joint2Family,
)
from primitive_manifold_planner.examplesupport.planar2link_helpers import (
    make_seed_points_fn,
    component_ids_for_family,
    compatible_components_for_leaf,
    allowed_unaware_pair,
    allowed_switch_pair,
)


@dataclass
class BenchmarkRow:
    case_name: str
    planner_name: str
    route_found: bool
    realization_success: bool
    route_string: str
    num_edges: int
    path_length: float
    graph_nodes: int
    graph_edges: int
    transition_pairs: int
    transition_candidates: int
    selected_candidate_indices: list[int]
    message: str


def build_cases():
    return [
        ("up_to_up", np.array([0.5 * np.pi, 0.5 * np.pi]), np.array([0.0, 0.5 * np.pi])),
        ("up_to_down", np.array([0.5 * np.pi, 0.5 * np.pi]), np.array([0.0, -0.5 * np.pi])),
        ("down_to_down", np.array([-0.5 * np.pi, -0.5 * np.pi]), np.array([0.0, -0.5 * np.pi])),
        ("down_to_up", np.array([-0.5 * np.pi, -0.5 * np.pi]), np.array([0.0, 0.5 * np.pi])),
    ]


def main():
    np.random.seed(7)

    robot = Planar2LinkKinematics(l1=1.0, l2=1.0)

    config = PlannerConfig(
        max_candidates_per_pair=8,
        wrap_state_fn=wrap_q,
        state_distance_fn=torus_distance,
        local_planner_name="projection",
        local_planner_kwargs=dict(
            goal_tol=1e-3,
            max_iters=1200,
            projection_tol=1e-10,
            projection_max_iters=50,
            projection_damping=1.0,
        ),
        step_size=0.08,
    )

    seed_points_fn = make_seed_points_fn(robot)

    aware_families = [
        EndEffectorXFamily("left_x_family", robot, [-1.00]),
        EndEffectorYFamily("bridge_y_family", robot, [-1.00, 1.00]),
        EndEffectorXFamily("right_x_family", robot, [1.00]),
    ]
    aware_planner = MultimodalComponentPlanner(
        families=aware_families,
        project_newton=project_newton,
        seed_points_fn=seed_points_fn,
        component_ids_for_family_fn=component_ids_for_family,
        compatible_components_fn=compatible_components_for_leaf,
        allowed_family_pair_fn=allowed_unaware_pair,
        config=config,
    )

    switch_families = [
        EndEffectorXFamily("left_x_family", robot, [-1.00]),
        Joint2Family("switch_q2_family", [0.0]),
        EndEffectorYFamily("bridge_y_family", robot, [-1.00, 1.00]),
        EndEffectorXFamily("right_x_family", robot, [1.00]),
    ]
    switch_planner = MultimodalComponentPlanner(
        families=switch_families,
        project_newton=project_newton,
        seed_points_fn=seed_points_fn,
        component_ids_for_family_fn=component_ids_for_family,
        compatible_components_fn=compatible_components_for_leaf,
        allowed_family_pair_fn=allowed_switch_pair,
        config=config,
    )

    rows: List[BenchmarkRow] = []

    for case_name, start_q_raw, goal_q_raw in build_cases():
        start_q = wrap_q(start_q_raw)
        goal_q = wrap_q(goal_q_raw)

        start_state = LeafState("left_x_family", -1.0, start_q.copy())
        start_comp = component_of_q(start_q)
        goal_comp = component_of_q(goal_q)

        aware_result = aware_planner.plan(
            start_state=start_state,
            start_component=start_comp,
            goal_family_name="right_x_family",
            goal_lam=1.0,
            goal_component=goal_comp,
            goal_q=goal_q.copy(),
        )

        rows.append(
            BenchmarkRow(
                case_name=case_name,
                planner_name="planner_v1_aware",
                route_found=aware_result.route_found,
                realization_success=aware_result.realization_success,
                route_string=aware_result.diagnostics.selected_route_string,
                num_edges=len(aware_result.route_edges) if aware_result.route_edges is not None else 0,
                path_length=aware_result.path_length,
                graph_nodes=aware_result.diagnostics.num_graph_nodes,
                graph_edges=aware_result.diagnostics.num_graph_edges,
                transition_pairs=aware_result.diagnostics.num_transition_pairs,
                transition_candidates=aware_result.diagnostics.num_transition_candidates,
                selected_candidate_indices=list(aware_result.diagnostics.selected_candidate_indices),
                message=aware_result.message,
            )
        )

        switch_result = switch_planner.plan(
            start_state=start_state,
            start_component=start_comp,
            goal_family_name="right_x_family",
            goal_lam=1.0,
            goal_component=goal_comp,
            goal_q=goal_q.copy(),
        )

        rows.append(
            BenchmarkRow(
                case_name=case_name,
                planner_name="planner_v1_aware+switch",
                route_found=switch_result.route_found,
                realization_success=switch_result.realization_success,
                route_string=switch_result.diagnostics.selected_route_string,
                num_edges=len(switch_result.route_edges) if switch_result.route_edges is not None else 0,
                path_length=switch_result.path_length,
                graph_nodes=switch_result.diagnostics.num_graph_nodes,
                graph_edges=switch_result.diagnostics.num_graph_edges,
                transition_pairs=switch_result.diagnostics.num_transition_pairs,
                transition_candidates=switch_result.diagnostics.num_transition_candidates,
                selected_candidate_indices=list(switch_result.diagnostics.selected_candidate_indices),
                message=switch_result.message,
            )
        )

    print("\nExample 52: planner v1 benchmark\n")
    for r in rows:
        print(
            f"{r.case_name:12s} | {r.planner_name:24s} | "
            f"route={str(r.route_found):5s} | "
            f"realized={str(r.realization_success):5s} | "
            f"edges={r.num_edges:d} | "
            f"length={r.path_length:7.4f} | "
            f"nodes={r.graph_nodes:d} | "
            f"cand={r.transition_candidates:d} | "
            f"{r.message}"
        )
        if r.route_string:
            print(f"  route: {r.route_string}")
        if r.selected_candidate_indices:
            print(f"  selected_candidate_indices: {r.selected_candidate_indices}")
    print("")
    print(
        "aware cache stats:",
        aware_planner.transition_generator.cache_hits,
        aware_planner.transition_generator.cache_misses,
    )
    print(
        "aware+switch cache stats:",
        switch_planner.transition_generator.cache_hits,
        switch_planner.transition_generator.cache_misses,
    )


if __name__ == "__main__":
    main()
