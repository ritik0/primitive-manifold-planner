from __future__ import annotations

import numpy as np
import matplotlib
matplotlib.use("TkAgg")
import matplotlib.pyplot as plt

from primitive_manifold_planner.families.base import ManifoldFamily
from primitive_manifold_planner.families.leaf_state import LeafState
from primitive_manifold_planner.manifolds import LineManifold, CircleManifold, EllipseManifold
from primitive_manifold_planner.planning.local import constrained_interpolate
from primitive_manifold_planner.projection import project_newton
from primitive_manifold_planner.planners.leaf_graph import (
    build_leaf_graph,
    shortest_leaf_route,
)
from primitive_manifold_planner.planners.realize_leaf_route import realize_leaf_route
from primitive_manifold_planner.planners.leaf_graph_plot import plot_leaf_graph


class HorizontalLineFamily(ManifoldFamily):
    def __init__(self, name: str, lambdas=None):
        super().__init__(name)
        self._lambdas = lambdas if lambdas is not None else [-1.0, 1.0]

    def manifold(self, lam):
        return LineManifold(
            point=np.array([0.0, lam], dtype=float),
            normal=np.array([0.0, 1.0], dtype=float),
            name=f"{self.name}_y_{lam}",
        )

    def sample_lambdas(self, context=None):
        return list(self._lambdas)


class CircleLeafFamily(ManifoldFamily):
    def __init__(self, name: str, center=(0.0, 0.0), radii=None):
        super().__init__(name)
        self.center = np.array(center, dtype=float)
        self._radii = radii if radii is not None else [1.05]

    def manifold(self, lam):
        return CircleManifold(
            center=self.center,
            radius=float(lam),
            name=f"{self.name}_r_{lam}",
        )

    def sample_lambdas(self, context=None):
        return list(self._radii)


class EllipseLeafFamily(ManifoldFamily):
    def __init__(self, name: str, center=(0.0, 0.0), a=1.0, b=0.7, lambdas=None):
        """
        lam is just a label here; we keep one ellipse leaf for now.
        """
        super().__init__(name)
        self.center = np.array(center, dtype=float)
        self.a = float(a)
        self.b = float(b)
        self._lambdas = lambdas if lambdas is not None else [0]

    def manifold(self, lam):
        # adapt if your EllipseManifold API differs
        return EllipseManifold(
            center=self.center,
            a=self.a,
            b=self.b,
            name=f"{self.name}_ellipse_{lam}",
        )

    def sample_lambdas(self, context=None):
        return list(self._lambdas)


def plot_family(ax, fam, color="lightgray", n=400):
    if isinstance(fam, HorizontalLineFamily):
        xs = np.linspace(-3.5, 3.5, n)
        for lam in fam.sample_lambdas():
            ys = np.full_like(xs, lam)
            ax.plot(xs, ys, "--", color=color, linewidth=1.2)

    elif isinstance(fam, CircleLeafFamily):
        ts = np.linspace(0.0, 2.0 * np.pi, n)
        for r in fam.sample_lambdas():
            xs = fam.center[0] + r * np.cos(ts)
            ys = fam.center[1] + r * np.sin(ts)
            ax.plot(xs, ys, "--", color=color, linewidth=1.4)

    elif isinstance(fam, EllipseLeafFamily):
        ts = np.linspace(0.0, 2.0 * np.pi, n)
        xs = fam.center[0] + fam.a * np.cos(ts)
        ys = fam.center[1] + fam.b * np.sin(ts)
        ax.plot(xs, ys, "--", color=color, linewidth=1.4)


def plot_graph_edges_in_workspace(ax, graph):
    seen = set()
    for src, edges in graph.adjacency.items():
        for e in edges:
            key = (src, e.dst, tuple(np.round(e.transition_point, 6)))
            if key in seen:
                continue
            seen.add(key)
            p = e.transition_point
            ax.scatter(p[0], p[1], color="red", s=20, alpha=0.55)


def plot_realized_result(ax, result):
    color_map = {
        "start_family": "tab:blue",
        "goal_family": "tab:cyan",
        "left_bridge": "tab:orange",
        "right_bridge": "tab:green",
        "ellipse_bridge": "tab:purple",
    }

    for step in result.steps:
        pts = np.asarray(step.path)
        if len(pts) == 0:
            continue

        ax.plot(
            pts[:, 0],
            pts[:, 1],
            "-",
            color=color_map.get(step.family_name, "tab:brown"),
            linewidth=3.0,
        )

        if step.transition_point is not None:
            tp = step.transition_point
            ax.scatter(tp[0], tp[1], color="black", s=75, marker="x")


def informed_seed_points_fn(fam_a, lam_a, fam_b, lam_b):
    """
    General-purpose informed seed generator for:
    - line <-> circle
    - line <-> ellipse
    - circle <-> ellipse
    - circle <-> circle
    - line <-> line
    """
    seeds = []

    def add_unique(arr):
        for s in arr:
            if not any(np.linalg.norm(s - u) < 1e-8 for u in seeds):
                seeds.append(s)

    # helper: sample points on ellipse
    def ellipse_points(center, a, b, m=20):
        ts = np.linspace(0.0, 2.0 * np.pi, m, endpoint=False)
        return [center + np.array([a * np.cos(t), b * np.sin(t)], dtype=float) for t in ts]

    # line vs circle
    if isinstance(fam_a, HorizontalLineFamily) and isinstance(fam_b, CircleLeafFamily):
        y = float(lam_a)
        c = fam_b.center
        r = float(lam_b)
        dy = y - c[1]
        if abs(dy) <= r + 1e-9:
            dx = np.sqrt(max(r * r - dy * dy, 0.0))
            add_unique([
                np.array([c[0] + dx, y], dtype=float),
                np.array([c[0] - dx, y], dtype=float),
            ])
        xs = np.linspace(c[0] - 1.5 * r, c[0] + 1.5 * r, 12)
        add_unique([np.array([x, y], dtype=float) for x in xs])
        add_unique([c + r * np.array([np.cos(t), np.sin(t)], dtype=float)
                    for t in np.linspace(0, 2*np.pi, 16, endpoint=False)])
        return seeds

    if isinstance(fam_a, CircleLeafFamily) and isinstance(fam_b, HorizontalLineFamily):
        return informed_seed_points_fn(fam_b, lam_b, fam_a, lam_a)

    # line vs ellipse
    if isinstance(fam_a, HorizontalLineFamily) and isinstance(fam_b, EllipseLeafFamily):
        y = float(lam_a)
        c = fam_b.center
        a = fam_b.a
        b = fam_b.b
        dy = y - c[1]
        if abs(dy) <= b + 1e-9:
            val = 1.0 - (dy * dy) / (b * b)
            if val >= 0.0:
                dx = a * np.sqrt(val)
                add_unique([
                    np.array([c[0] + dx, y], dtype=float),
                    np.array([c[0] - dx, y], dtype=float),
                ])
        xs = np.linspace(c[0] - 1.5 * a, c[0] + 1.5 * a, 14)
        add_unique([np.array([x, y], dtype=float) for x in xs])
        add_unique(ellipse_points(c, a, b, m=20))
        return seeds

    if isinstance(fam_a, EllipseLeafFamily) and isinstance(fam_b, HorizontalLineFamily):
        return informed_seed_points_fn(fam_b, lam_b, fam_a, lam_a)

    # circle vs circle
    if isinstance(fam_a, CircleLeafFamily) and isinstance(fam_b, CircleLeafFamily):
        c1, r1 = fam_a.center, float(lam_a)
        c2, r2 = fam_b.center, float(lam_b)
        add_unique([c1 + r1 * np.array([np.cos(t), np.sin(t)], dtype=float)
                    for t in np.linspace(0, 2*np.pi, 18, endpoint=False)])
        add_unique([c2 + r2 * np.array([np.cos(t), np.sin(t)], dtype=float)
                    for t in np.linspace(0, 2*np.pi, 18, endpoint=False)])
        for t in np.linspace(0, 2*np.pi, 10, endpoint=False):
            p1 = c1 + r1 * np.array([np.cos(t), np.sin(t)], dtype=float)
            p2 = c2 + r2 * np.array([np.cos(t), np.sin(t)], dtype=float)
            add_unique([0.5 * (p1 + p2)])
        return seeds

    # circle vs ellipse
    if isinstance(fam_a, CircleLeafFamily) and isinstance(fam_b, EllipseLeafFamily):
        c, r = fam_a.center, float(lam_a)
        add_unique([c + r * np.array([np.cos(t), np.sin(t)], dtype=float)
                    for t in np.linspace(0, 2*np.pi, 20, endpoint=False)])
        add_unique(ellipse_points(fam_b.center, fam_b.a, fam_b.b, m=20))
        return seeds

    if isinstance(fam_a, EllipseLeafFamily) and isinstance(fam_b, CircleLeafFamily):
        return informed_seed_points_fn(fam_b, lam_b, fam_a, lam_a)

    # ellipse vs ellipse
    if isinstance(fam_a, EllipseLeafFamily) and isinstance(fam_b, EllipseLeafFamily):
        add_unique(ellipse_points(fam_a.center, fam_a.a, fam_a.b, m=20))
        add_unique(ellipse_points(fam_b.center, fam_b.a, fam_b.b, m=20))
        return seeds

    # line vs line
    if isinstance(fam_a, HorizontalLineFamily) and isinstance(fam_b, HorizontalLineFamily):
        y1 = float(lam_a)
        y2 = float(lam_b)
        if abs(y1 - y2) < 1e-9:
            xs = np.linspace(-3.0, 3.0, 10)
            add_unique([np.array([x, y1], dtype=float) for x in xs])
        return seeds

    add_unique([
        np.array([0.0, 0.0], dtype=float),
        np.array([1.0, 0.0], dtype=float),
        np.array([-1.0, 0.0], dtype=float),
        np.array([0.0, 1.0], dtype=float),
        np.array([0.0, -1.0], dtype=float),
    ])
    return seeds


def main():
    np.random.seed(7)

    start_family = HorizontalLineFamily("start_family", lambdas=[-1.0])
    goal_family = HorizontalLineFamily("goal_family", lambdas=[1.0])

    left_bridge = CircleLeafFamily(
        "left_bridge",
        center=(-1.0, 0.0),
        radii=[1.05],
    )
    right_bridge = CircleLeafFamily(
        "right_bridge",
        center=(1.0, 0.0),
        radii=[1.05],
    )
    ellipse_bridge = EllipseLeafFamily(
        "ellipse_bridge",
        center=(0.0, 0.15),
        a=1.25,
        b=0.85,
        lambdas=[0],
    )

    families = [start_family, goal_family, left_bridge, right_bridge, ellipse_bridge]

    start_x = np.array([0.0, -1.0], dtype=float)
    goal_point = np.array([2.3, 1.0], dtype=float)

    start_state = LeafState("start_family", -1.0, start_x)
    goal_lam = 1.0

    graph = build_leaf_graph(
        families=families,
        project_newton=project_newton,
        seed_points_fn=informed_seed_points_fn,
        goal_point=goal_point,
        max_candidates_per_pair=4,
    )

    print("\n=== Example 28 graph adjacency ===")
    for node, edges in graph.adjacency.items():
        print(f"{node}: {len(edges)} edge(s)")
        for e in edges:
            print(
                f"    -> {e.dst}, cand={e.candidate_index}, "
                f"transition={np.round(e.transition_point, 4)}, score={e.score:.4f}"
            )

    route = shortest_leaf_route(
        graph,
        start=(start_state.family_name, start_state.lam),
        goal=(goal_family.name, goal_lam),
    )

    print("\n=== Example 28 chosen route ===")
    if route is None:
        print("No route found.")
        return

    for i, edge in enumerate(route):
        print(
            f"  edge {i}: {edge.src} -> {edge.dst}, "
            f"cand={edge.candidate_index}, "
            f"transition={np.round(edge.transition_point, 4)}, score={edge.score:.4f}"
        )

    realized = realize_leaf_route(
        start_state=start_state,
        goal_point=goal_point,
        goal_family=goal_family,
        goal_lam=goal_lam,
        families=families,
        route_edges=route,
        constrained_interpolate=constrained_interpolate,
        step_size=0.08,
    )

    print("\n=== Example 28 realized route ===")
    print("success:", realized.success)
    print("message:", realized.message)
    print("num steps:", len(realized.steps))

    # ------------------------------------------------------------
    # Figure 1: Workspace geometry + realized path
    # ------------------------------------------------------------
    fig1, ax1 = plt.subplots(figsize=(10, 8))
    plot_family(ax1, start_family, color="lightblue")
    plot_family(ax1, goal_family, color="powderblue")
    plot_family(ax1, left_bridge, color="moccasin")
    plot_family(ax1, right_bridge, color="honeydew")
    plot_family(ax1, ellipse_bridge, color="thistle")

    plot_graph_edges_in_workspace(ax1, graph)
    plot_realized_result(ax1, realized)

    ax1.scatter(start_x[0], start_x[1], color="purple", s=95, label="start")
    ax1.scatter(goal_point[0], goal_point[1], color="green", s=95, label="goal")

    ax1.set_aspect("equal", adjustable="box")
    ax1.set_title("Example 28: Multi-shape competing routes (workspace)")
    ax1.legend()
    ax1.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig("example_28_multishape_competing_routes_workspace.png", dpi=180)

    # ------------------------------------------------------------
    # Figure 2: Leaf graph
    # ------------------------------------------------------------
    fig2, ax2 = plot_leaf_graph(
        graph,
        route=route,
        title="Example 28: Leaf graph / chosen route",
    )
    fig2.savefig("example_28_multishape_competing_routes_graph.png", dpi=180)

    plt.show()


if __name__ == "__main__":
    main()