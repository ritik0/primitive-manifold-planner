from __future__ import annotations

import numpy as np
import matplotlib.pyplot as plt

from primitive_manifold_planner.families.leaf_state import LeafState
from primitive_manifold_planner.planners.multimodal_component_planner import (
    MultimodalComponentPlanner,
    PlannerConfig,
)
from primitive_manifold_planner.projection import project_newton

from primitive_manifold_planner.examplesupport.planar2link import (
    Planar2LinkKinematics,
    component_of_q,
    wrap_q,
    torus_distance,
)
from primitive_manifold_planner.examplesupport.planar2link_families import (
    EndEffectorXFamily,
    EndEffectorYFamily,
    Joint2Family,
)
from primitive_manifold_planner.examplesupport.planar2link_helpers import (
    make_seed_points_fn,
    component_ids_for_family,
    compatible_components_for_leaf,
    allowed_switch_pair,
)


def concatenate_steps(steps) -> np.ndarray:
    pts = []
    for i, step in enumerate(steps):
        path = np.asarray(step.path)
        if len(path) == 0:
            continue
        if i == 0:
            pts.extend(list(path))
        else:
            pts.extend(list(path[1:]))
    if not pts:
        return np.zeros((0, 2))
    return np.asarray(pts)


def plot_jointspace_families(ax, robot, families):
    q1 = np.linspace(-np.pi, np.pi, 350)
    q2 = np.linspace(-np.pi, np.pi, 350)
    Q1, Q2 = np.meshgrid(q1, q2)

    X = robot.l1 * np.cos(Q1) + robot.l2 * np.cos(Q1 + Q2)
    Y = robot.l1 * np.sin(Q1) + robot.l2 * np.sin(Q1 + Q2)

    for fam in families:
        for lam in fam.sample_lambdas():
            if fam.name.endswith("x_family"):
                ax.contour(Q1, Q2, X, levels=[lam], linewidths=1.0, alpha=0.25)
            elif fam.name.endswith("y_family"):
                ax.contour(Q1, Q2, Y, levels=[lam], linewidths=1.0, alpha=0.25)
            elif fam.name == "switch_q2_family":
                ax.axhline(float(lam), linewidth=1.0, alpha=0.30)


def build_cases():
    return [
        ("up_to_up", np.array([0.5 * np.pi, 0.5 * np.pi]), np.array([0.0, 0.5 * np.pi])),
        ("up_to_down", np.array([0.5 * np.pi, 0.5 * np.pi]), np.array([0.0, -0.5 * np.pi])),
        ("down_to_down", np.array([-0.5 * np.pi, -0.5 * np.pi]), np.array([0.0, -0.5 * np.pi])),
        ("down_to_up", np.array([-0.5 * np.pi, -0.5 * np.pi]), np.array([0.0, 0.5 * np.pi])),
    ]


def main():
    np.random.seed(7)

    robot = Planar2LinkKinematics(l1=1.0, l2=1.0)

    families = [
        EndEffectorXFamily("left_x_family", robot, [-1.00]),
        Joint2Family("switch_q2_family", [0.0]),
        EndEffectorYFamily("bridge_y_family", robot, [-1.00, 1.00]),
        EndEffectorXFamily("right_x_family", robot, [1.00]),
    ]

    config = PlannerConfig(
        max_candidates_per_pair=8,
        wrap_state_fn=wrap_q,
        state_distance_fn=torus_distance,
        local_planner_name="projection",
        local_planner_kwargs=dict(
            goal_tol=1e-3,
            max_iters=1200,
            projection_tol=1e-10,
            projection_max_iters=50,
            projection_damping=1.0,
        ),
        step_size=0.08,
    )

    planner = MultimodalComponentPlanner(
        families=families,
        project_newton=project_newton,
        seed_points_fn=make_seed_points_fn(robot),
        component_ids_for_family_fn=component_ids_for_family,
        compatible_components_fn=compatible_components_for_leaf,
        allowed_family_pair_fn=allowed_switch_pair,
        config=config,
    )

    cases = build_cases()

    fig, axes = plt.subplots(2, 2, figsize=(14, 12))
    axes = axes.ravel()

    print("\nExample 53: four-case single figure\n")

    for ax, (case_name, start_q_raw, goal_q_raw) in zip(axes, cases):
        start_q = wrap_q(start_q_raw)
        goal_q = wrap_q(goal_q_raw)

        start_state = LeafState("left_x_family", -1.0, start_q.copy())
        start_comp = component_of_q(start_q)
        goal_comp = component_of_q(goal_q)

        result = planner.plan(
            start_state=start_state,
            start_component=start_comp,
            goal_family_name="right_x_family",
            goal_lam=1.0,
            goal_component=goal_comp,
            goal_q=goal_q.copy(),
        )

        print(f"{case_name}: success={result.success}, path_length={result.path_length:.4f}")
        print(f"  route: {result.diagnostics.selected_route_string}")
        print(f"  realized candidate indices: {[step.message for step in result.realization.steps[:-1]] if result.realization else []}")

        plot_jointspace_families(ax, robot, families)

        q_path = (
            concatenate_steps(result.realization.steps)
            if result.realization is not None and result.realization.success
            else np.zeros((0, 2))
        )

        if len(q_path) > 0:
            ax.plot(q_path[:, 0], q_path[:, 1], lw=3.0, label="realized path")

        if result.realization is not None:
            for i, step in enumerate(result.realization.steps[:-1]):
                if step.transition_point is not None:
                    ax.scatter(
                        step.transition_point[0],
                        step.transition_point[1],
                        s=60,
                        zorder=5,
                        label="used transition" if i == 0 else None,
                    )

        ax.scatter(start_q[0], start_q[1], s=90, marker="s", color="black", label="start")
        ax.scatter(goal_q[0], goal_q[1], s=120, marker="*", color="gold", edgecolor="black", label="goal")

        title = (
            f"{case_name}\n"
            f"success={result.realization_success}, "
            f"L={result.path_length:.2f}"
        )
        ax.set_title(title)
        ax.set_xlabel("q1 [rad]")
        ax.set_ylabel("q2 [rad]")
        ax.set_xlim([-np.pi, np.pi])
        ax.set_ylim([-np.pi, np.pi])
        ax.grid(True, alpha=0.25)

    handles, labels = axes[0].get_legend_handles_labels()
    if handles:
        fig.legend(handles, labels, loc="upper center", ncol=4)

    plt.suptitle("Four start-goal cases with planner v1 (joint-space comparison)", y=0.98)
    plt.tight_layout(rect=[0, 0, 1, 0.96])
    plt.show()


if __name__ == "__main__":
    main()