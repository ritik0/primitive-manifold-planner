from __future__ import annotations

from dataclasses import dataclass
from typing import List
import numpy as np
import matplotlib.pyplot as plt

from primitive_manifold_planner.families.standard import (
    EllipseFamily,
    RoundedRectangleConnectorFamily,
)
from primitive_manifold_planner.families.leaf_state import LeafState
from primitive_manifold_planner.manifolds import EllipseManifold, RoundedRectangleManifold
from primitive_manifold_planner.planners.mode_semantics import PlanningSemanticContext
from primitive_manifold_planner.planners.admissibility import (
    build_semantic_target_progress_point_fn,
    ProgressTargetSelectionConfig,
)
from primitive_manifold_planner.planners.semantic_templates import (
    build_support_transfer_goal_semantic_model,
)
from primitive_manifold_planner.planners.plan_foliated_route import plan_foliated_route
from primitive_manifold_planner.projection import project_newton
from primitive_manifold_planner.planners.leaf_graph_plot import plot_leaf_graph_from_routes


@dataclass
class TransferCase:
    start_family_name: str
    start_lam: float
    start_point: np.ndarray
    goal_family_name: str
    goal_lam: float
    goal_point: np.ndarray
    title: str


def build_two_table_benchmark():
    def connector_admissibility_cost(
        lam: float,
        point: np.ndarray,
        goal_point: np.ndarray | None = None,
        metadata: dict | None = None,
    ) -> float:
        """
        Mild preference for transfer connectors that are closer to the table height
        and for points that make progress toward the goal side of the scene.
        """
        _ = metadata
        q = np.asarray(point, dtype=float)
        goal = None if goal_point is None else np.asarray(goal_point, dtype=float)
        cost = 0.25 * abs(float(lam) - 1.10)
        if goal is not None:
            cost += 0.10 * float(np.linalg.norm(q - goal))
        return float(cost)

    def connector_transition_feasibility(
        lam: float,
        point: np.ndarray,
        goal_point: np.ndarray | None = None,
        metadata: dict | None = None,
    ) -> bool:
        """
        Reusable local feasibility rule for connector usage.
        Only the central horizontal band of the bounded connector is admissible
        for transition contact in this scenario.
        """
        _ = lam, goal_point, metadata
        q = np.asarray(point, dtype=float)
        return bool(-0.25 <= float(q[1]) <= 0.50)

    left_table = EllipseFamily(
        name="left_table",
        center=np.array([-1.75, 0.35], dtype=float),
        a_scales={
            0.90: 0.95,
            1.10: 1.10,
            1.30: 1.25,
        },
        b_scales={
            0.90: 1.10,
            1.10: 1.28,
            1.30: 1.42,
        },
    )
    transfer_zone = RoundedRectangleConnectorFamily(
        name="transfer_zone",
        center=np.array([0.0, 0.15], dtype=float),
        a_scales={
            0.90: 1.00,
            1.10: 1.15,
            1.30: 1.30,
        },
        b_scales={
            0.90: 0.28,
            1.10: 0.34,
            1.30: 0.40,
        },
        power=4.0,
        admissibility_cost_fn=connector_admissibility_cost,
        feasibility_fn=connector_transition_feasibility,
    )
    right_table = EllipseFamily(
        name="right_table",
        center=np.array([1.75, 0.35], dtype=float),
        a_scales={
            0.95: 0.95,
            1.10: 1.10,
            1.25: 1.25,
        },
        b_scales={
            0.95: 1.10,
            1.10: 1.28,
            1.25: 1.42,
        },
    )

    families = [left_table, transfer_zone, right_table]

    start_leaf = left_table.manifold(1.10)
    goal_leaf = right_table.manifold(1.10)

    case = TransferCase(
        start_family_name="left_table",
        start_lam=1.10,
        start_point=start_leaf.point_from_angle(np.deg2rad(228.0)),
        goal_family_name="right_table",
        goal_lam=1.10,
        goal_point=goal_leaf.point_from_angle(np.deg2rad(-48.0)),
        title="Two-table slide-lift-transfer-slide scenario",
    )

    allowed_family_transitions = {
        "left_table": ["transfer_zone"],
        "transfer_zone": ["right_table"],
        "right_table": [],
    }

    return families, case, allowed_family_transitions


def build_two_table_semantic_model():
    def semantic_feasibility(context: PlanningSemanticContext) -> bool:
        if context.point is None:
            return True
        involved = {context.source_family_name, context.target_family_name}
        if "transfer_zone" not in involved:
            return True
        q = np.asarray(context.point, dtype=float)
        return bool(-1.05 <= float(q[0]) <= 1.05 and -0.25 <= float(q[1]) <= 0.50)

    def semantic_admissibility(context: PlanningSemanticContext) -> float:
        if context.point is None:
            return 0.0
        involved = {context.source_family_name, context.target_family_name}
        if "transfer_zone" not in involved:
            return 0.0
        q = np.asarray(context.point, dtype=float)
        goal = None if context.goal_point is None else np.asarray(context.goal_point, dtype=float)
        cost = 0.12 * abs(float(q[1]) - 0.15)
        if goal is not None:
            cost += 0.06 * float(np.linalg.norm(q - goal))
        return float(cost)

    return build_support_transfer_goal_semantic_model(
        support_families=["left_table"],
        transfer_families=["transfer_zone"],
        goal_support_families=["right_table"],
        transition_feasibility_fn=semantic_feasibility,
        transition_admissibility_fn=semantic_admissibility,
    )


def get_family_map(families):
    return {f.name: f for f in families}


def concatenate_steps(steps) -> np.ndarray:
    pts = []
    for i, step in enumerate(steps):
        path = np.asarray(step.path)
        if len(path) == 0:
            continue
        if i == 0:
            pts.extend(list(path))
        else:
            pts.extend(list(path[1:]))
    if not pts:
        return np.zeros((0, 2))
    return np.asarray(pts)


def total_path_length_from_steps(steps) -> float:
    total = 0.0
    for step in steps:
        path = np.asarray(step.path)
        if len(path) >= 2:
            total += float(np.sum(np.linalg.norm(np.diff(path, axis=0), axis=1)))
    return total


def summarize_leaf_sequence(result) -> str:
    seq = []
    for step in result.steps:
        node = f"{step.family_name}[{step.lam}]"
        if not seq or seq[-1] != node:
            seq.append(node)
    return " -> ".join(seq)


def route_nodes_from_result(result):
    nodes = []
    for step in result.steps:
        node = (step.family_name, step.lam)
        if not nodes or nodes[-1] != node:
            nodes.append(node)
    return nodes


def build_leaf_graph_for_plot(families, allowed_family_transitions):
    nodes = []
    fam_to_lams = {}

    for fam in families:
        fam_to_lams[fam.name] = list(fam.sample_lambdas())
        for lam in fam.sample_lambdas():
            nodes.append((fam.name, lam))

    edges = []
    edge_labels = {}
    for src_family, dst_families in allowed_family_transitions.items():
        for dst_family in dst_families:
            for lam_a in fam_to_lams.get(src_family, []):
                for lam_b in fam_to_lams.get(dst_family, []):
                    a = (src_family, lam_a)
                    b = (dst_family, lam_b)
                    edges.append((a, b))
                    key = (a, b) if str(a) <= str(b) else (b, a)
                    edge_labels[key] = ""

    return nodes, edges, edge_labels


def plot_manifold(ax, manifold, color="lightgray", lw=1.2, alpha=0.30):
    if isinstance(manifold, EllipseManifold):
        th = np.linspace(0.0, 2.0 * np.pi, 300)
        pts = np.array([manifold.point_from_angle(t) for t in th])
        ax.plot(pts[:, 0], pts[:, 1], color=color, lw=lw, alpha=alpha)
    elif isinstance(manifold, RoundedRectangleManifold):
        th = np.linspace(0.0, 2.0 * np.pi, 300)
        pts = np.array([manifold.point_from_angle(t) for t in th])
        ax.plot(pts[:, 0], pts[:, 1], color=color, lw=lw, alpha=alpha)


def plot_all_families(ax, families):
    color_map = {
        "left_table": "#c58b4c",
        "transfer_zone": "#88a8c6",
        "right_table": "#c58b4c",
    }
    for fam in families:
        for lam in fam.sample_lambdas():
            plot_manifold(
                ax,
                fam.manifold(lam),
                color=color_map.get(fam.name, "lightgray"),
                alpha=0.22 if fam.name != "transfer_zone" else 0.30,
            )


def selected_transfer_lambda(result):
    for step in result.steps:
        if step.family_name == "transfer_zone":
            return float(step.lam)
    return None


def print_plan_summary(result):
    print("\n=== Example 56 result ===")
    print(f"success      : {result.success}")
    print(f"message      : {result.message}")
    print(f"num steps    : {len(result.steps)}")
    print(f"path length  : {total_path_length_from_steps(result.steps):.4f}")
    print(f"leaf sequence: {summarize_leaf_sequence(result)}")

    for i, step in enumerate(result.steps):
        step_path = np.asarray(step.path)
        path_len = 0.0
        if len(step_path) >= 2:
            path_len = float(np.sum(np.linalg.norm(np.diff(step_path, axis=0), axis=1)))
        print(
            f"  step {i:02d} | kind={step.kind:>6s} | "
            f"family={step.family_name}[{step.lam}] | "
            f"planner={getattr(step, 'planner_name', 'unknown')} | "
            f"len={path_len:.4f}"
        )


def main():
    np.random.seed(11)

    families, case, allowed_family_transitions = build_two_table_benchmark()
    family_map = get_family_map(families)
    semantic_model = build_two_table_semantic_model()

    start_state = LeafState(
        family_name=case.start_family_name,
        lam=case.start_lam,
        x=case.start_point.copy(),
    )
    goal_family = family_map[case.goal_family_name]

    result = plan_foliated_route(
        start_state=start_state,
        goal_point=case.goal_point.copy(),
        goal_family=goal_family,
        goal_lam=case.goal_lam,
        families=families,
        project_newton=project_newton,
        max_switches=3,
        local_step_size=0.08,
        progress_tol=1e-4,
        local_planner_name="projection",
        local_planner_kwargs=dict(
            goal_tol=1e-3,
            max_iters=600,
            projection_tol=1e-10,
            projection_max_iters=50,
            projection_damping=1.0,
        ),
        allowed_family_transitions=allowed_family_transitions,
        semantic_model=semantic_model,
        goal_leaf_mismatch_penalty=8.0,
        target_progress_point_fn=build_semantic_target_progress_point_fn(
            ProgressTargetSelectionConfig(
                goal_distance_weight=1.0,
                admissibility_weight=1.5,
            )
        ),
    )

    print(f"\nRunning {case.title}")
    print(f"start = {case.start_family_name}[{case.start_lam}] at {np.round(case.start_point, 4)}")
    print(f"goal  = {case.goal_family_name}[{case.goal_lam}] at {np.round(case.goal_point, 4)}")
    print(f"allowed transitions = {allowed_family_transitions}")
    print_plan_summary(result)

    fig, ax = plt.subplots(figsize=(10, 7))
    plot_all_families(ax, families)

    q_path = concatenate_steps(result.steps)
    if len(q_path) > 0:
        ax.plot(
            q_path[:, 0],
            q_path[:, 1],
            color="#1565c0",
            lw=3.0,
            label="realized path",
        )

    for step in result.steps:
        if step.transition is not None:
            tp = np.asarray(step.transition.x, dtype=float)
            ax.scatter(tp[0], tp[1], s=70, marker="x", color="black")

    chosen_transfer_lam = selected_transfer_lambda(result)
    if chosen_transfer_lam is not None:
        transfer_family = next(f for f in families if f.name == "transfer_zone")
        transfer_leaf = transfer_family.manifold(chosen_transfer_lam)
        th = np.linspace(0.0, 2.0 * np.pi, 300)
        pts = np.array([transfer_leaf.point_from_angle(t) for t in th])
        ax.plot(
            pts[:, 0],
            pts[:, 1],
            color="#0d47a1",
            lw=3.0,
            alpha=0.9,
            label=f"selected transfer connector [{chosen_transfer_lam:.2f}]",
        )

    ax.scatter(case.start_point[0], case.start_point[1], s=90, marker="s", color="black", label="start")
    ax.scatter(case.goal_point[0], case.goal_point[1], s=130, marker="*", color="gold", edgecolor="black", label="goal")

    ax.text(-2.75, 1.80, "left table support", fontsize=10)
    ax.text(1.05, 1.80, "right table support", fontsize=10)
    ax.text(-0.95, 0.92, "candidate transfer-family rectangles", fontsize=10)
    if chosen_transfer_lam is not None:
        ax.text(
            -0.70,
            0.02,
            f"chosen bounded connector [{chosen_transfer_lam:.2f}]",
            fontsize=10,
            color="#0d47a1",
        )

    ax.set_title("Example 56: support motion with a bounded rounded-rectangle connector")
    ax.set_aspect("equal")
    ax.grid(True, alpha=0.25)
    ax.legend()
    plt.tight_layout()
    plt.show()

    graph_nodes, graph_edges, edge_labels = build_leaf_graph_for_plot(
        families=families,
        allowed_family_transitions=allowed_family_transitions,
    )
    plot_leaf_graph_from_routes(
        nodes=graph_nodes,
        edges=graph_edges,
        primary_route=route_nodes_from_result(result),
        edge_labels=edge_labels,
        title="Example 56 leaf graph: left support -> transfer zone -> right support",
        primary_label="selected route",
    )
    plt.show()


if __name__ == "__main__":
    main()
