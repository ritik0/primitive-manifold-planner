from __future__ import annotations

from dataclasses import dataclass
from typing import List
import numpy as np
import matplotlib.pyplot as plt

from primitive_manifold_planner.families.leaf_state import LeafState
from primitive_manifold_planner.manifolds import CircleManifold, LineManifold
from primitive_manifold_planner.planners.leaf_graph import (
    build_leaf_graph,
    shortest_leaf_route,
)
from primitive_manifold_planner.planners.realize_leaf_route import realize_leaf_route
from primitive_manifold_planner.planners.refine_route_with_attraction import (
    realize_leaf_route_with_state_attraction,
)
from primitive_manifold_planner.planners.leaf_graph_plot import plot_leaf_graph
from primitive_manifold_planner.projection import project_newton


# ============================================================
# Thin benchmark family wrappers
# ============================================================

class BenchmarkLeafFamily:
    def __init__(self, name: str, lambdas: List[float]):
        self.name = name
        self._lambdas = [float(l) for l in lambdas]

    def manifold(self, lam: float):
        raise NotImplementedError

    def sample_lambdas(self, context=None):
        return list(self._lambdas)

    def lambda_distance(self, lam_a, lam_b) -> float:
        return abs(float(lam_a) - float(lam_b))


class CircleFamilyAdapter(BenchmarkLeafFamily):
    def __init__(self, name: str, center: np.ndarray, lambdas: List[float]):
        super().__init__(name=name, lambdas=lambdas)
        self.center = np.asarray(center, dtype=float)

    def manifold(self, lam: float):
        return CircleManifold(
            center=self.center.copy(),
            radius=float(lam),
            name=f"{self.name}_lambda_{lam:g}",
        )


class HorizontalLineFamily(BenchmarkLeafFamily):
    def manifold(self, lam: float):
        return LineManifold(
            point=np.array([0.0, float(lam)]),
            normal=np.array([0.0, 1.0]),
            name=f"{self.name}_lambda_{lam:g}",
        )


# ============================================================
# Case definition
# ============================================================

@dataclass
class BenchmarkCase:
    start_family_name: str
    start_lam: float
    start_point: np.ndarray
    goal_family_name: str
    goal_lam: float
    goal_point: np.ndarray
    title: str


def point_on_circle(center: np.ndarray, radius: float, angle_deg: float) -> np.ndarray:
    th = np.deg2rad(float(angle_deg))
    return np.array(
        [
            center[0] + radius * np.cos(th),
            center[1] + radius * np.sin(th),
        ],
        dtype=float,
    )


def build_benchmark():
    families = [
        CircleFamilyAdapter(
            name="left_circle_family",
            center=np.array([-2.0, 0.0]),
            lambdas=[1.40],
        ),
        HorizontalLineFamily(
            name="bridge_line_family",
            lambdas=[-1.00, -0.60, -0.20, 0.00, 0.20, 0.60, 1.00],
        ),
        CircleFamilyAdapter(
            name="right_circle_family",
            center=np.array([2.0, 0.0]),
            lambdas=[1.40],
        ),
    ]

    # Start is intentionally biased toward the left side of the source circle.
    # This makes Example 36 interesting: the nominal graph transition is still chosen
    # goal-aware, but refinement may choose a different exact intersection from the
    # actual current state.
    left_center = np.array([-2.0, 0.0])
    start_point = point_on_circle(left_center, 1.40, 170.0)

    case = BenchmarkCase(
        start_family_name="left_circle_family",
        start_lam=1.40,
        start_point=start_point,
        goal_family_name="right_circle_family",
        goal_lam=1.40,
        goal_point=np.array([3.40, 0.00]),   # rightmost point of right circle
        title="Example 36: state-dependent refinement on a nominal leaf-graph route",
    )

    return families, case


# ============================================================
# Graph-building helpers
# ============================================================

def get_family_map(families):
    return {f.name: f for f in families}


def allowed_family_pair(fam_a_name: str, fam_b_name: str) -> bool:
    allowed = {
        ("left_circle_family", "bridge_line_family"),
        ("bridge_line_family", "left_circle_family"),
        ("bridge_line_family", "right_circle_family"),
        ("right_circle_family", "bridge_line_family"),
    }
    return (fam_a_name, fam_b_name) in allowed


def seed_points_fn(fam_a, lam_a, fam_b, lam_b):
    seeds = [
        np.array([0.0, 0.0], dtype=float),
        np.array([1.0, 0.0], dtype=float),
        np.array([-1.0, 0.0], dtype=float),
        np.array([0.0, 1.0], dtype=float),
        np.array([0.0, -1.0], dtype=float),
    ]

    def add_circle_line_seeds(circle_family, radius, line_y):
        cx, cy = circle_family.center
        r = float(radius)
        y = float(line_y)
        dy = y - cy

        if abs(dy) <= r + 1e-12:
            dx = np.sqrt(max(r * r - dy * dy, 0.0))
            seeds.append(np.array([cx - dx, y], dtype=float))
            seeds.append(np.array([cx + dx, y], dtype=float))

            eps = 0.05
            seeds.append(np.array([cx - dx - eps, y], dtype=float))
            seeds.append(np.array([cx - dx + eps, y], dtype=float))
            seeds.append(np.array([cx + dx - eps, y], dtype=float))
            seeds.append(np.array([cx + dx + eps, y], dtype=float))

        seeds.append(np.array([cx, y], dtype=float))

    if fam_a.name.endswith("circle_family") and fam_b.name == "bridge_line_family":
        add_circle_line_seeds(fam_a, lam_a, lam_b)

    if fam_b.name.endswith("circle_family") and fam_a.name == "bridge_line_family":
        add_circle_line_seeds(fam_b, lam_b, lam_a)

    uniq = []
    for s in seeds:
        if not any(np.linalg.norm(s - t) < 1e-8 for t in uniq):
            uniq.append(s)

    return uniq


def build_restricted_leaf_graph(families, goal_point):
    graph = build_leaf_graph(
        families=families,
        project_newton=project_newton,
        seed_points_fn=seed_points_fn,
        goal_point=goal_point,
        max_candidates_per_pair=2,
    )

    filtered = {}
    for src, edges in graph.adjacency.items():
        kept = []
        for e in edges:
            if allowed_family_pair(e.src[0], e.dst[0]):
                kept.append(e)
        filtered[src] = kept

    graph.adjacency = filtered
    return graph


def edge_cost_fn(edge):
    return 1.0 + edge.score


# ============================================================
# Plot helpers
# ============================================================

def plot_manifold(ax, manifold, color="lightgray", lw=1.2, alpha=0.30):
    if isinstance(manifold, LineManifold):
        p = manifold.point
        n = manifold.normal
        t = np.array([-n[1], n[0]], dtype=float)
        s = np.linspace(-6.0, 6.0, 400)
        pts = p[None, :] + s[:, None] * t[None, :]
        ax.plot(pts[:, 0], pts[:, 1], color=color, lw=lw, alpha=alpha)

    elif isinstance(manifold, CircleManifold):
        th = np.linspace(0.0, 2.0 * np.pi, 400)
        pts = np.column_stack([
            manifold.center[0] + manifold.radius * np.cos(th),
            manifold.center[1] + manifold.radius * np.sin(th),
        ])
        ax.plot(pts[:, 0], pts[:, 1], color=color, lw=lw, alpha=alpha)


def plot_all_families(ax, families):
    for fam in families:
        for lam in fam.sample_lambdas():
            plot_manifold(ax, fam.manifold(lam))


def concatenate_steps(steps) -> np.ndarray:
    pts = []
    for i, step in enumerate(steps):
        path = np.asarray(step.path)
        if len(path) == 0:
            continue
        if i == 0:
            pts.extend(list(path))
        else:
            pts.extend(list(path[1:]))
    if not pts:
        return np.zeros((0, 2))
    return np.asarray(pts)


def total_path_length_from_steps(steps) -> float:
    total = 0.0
    for step in steps:
        path = np.asarray(step.path)
        if len(path) >= 2:
            total += float(np.sum(np.linalg.norm(np.diff(path, axis=0), axis=1)))
    return total


def summarize_leaf_sequence(route_edges, start_key):
    seq = [f"{start_key[0]}[{start_key[1]}]"]
    for e in route_edges:
        seq.append(f"{e.dst[0]}[{e.dst[1]}]")
    return " -> ".join(seq)


# ============================================================
# Main
# ============================================================

def main():
    np.random.seed(7)

    families, case = build_benchmark()
    family_map = get_family_map(families)

    start_key = (case.start_family_name, case.start_lam)
    goal_key = (case.goal_family_name, case.goal_lam)

    start_state = LeafState(
        family_name=case.start_family_name,
        lam=case.start_lam,
        x=case.start_point.copy(),
    )
    goal_family = family_map[case.goal_family_name]
    goal_lam = case.goal_lam
    goal_point = case.goal_point.copy()

    graph = build_restricted_leaf_graph(
        families=families,
        goal_point=goal_point,
    )

    route = shortest_leaf_route(
        graph=graph,
        start=start_key,
        goal=goal_key,
        edge_cost_fn=edge_cost_fn,
    )

    print(f"\n{case.title}")
    print(f"start = {start_state.family_name}[{start_state.lam}] at {np.round(start_state.x, 4)}")
    print(f"goal  = {case.goal_family_name}[{case.goal_lam}] at {np.round(goal_point, 4)}")

    if route is None:
        print("\nNo nominal leaf-graph route found.")
        plot_leaf_graph(graph, route=None, title="Example 36 leaf graph (no route found)")
        plt.show()
        return

    print("\nSelected nominal leaf route:")
    print("  " + summarize_leaf_sequence(route, start_key))

    print("\nNominal graph transition edges:")
    for i, e in enumerate(route):
        print(
            f"  edge {i}: {e.src} -> {e.dst}, "
            f"cand={e.candidate_index}, "
            f"transition={np.round(e.transition_point, 4)}, "
            f"score={e.score:.4f}"
        )

    nominal = realize_leaf_route(
        start_state=start_state,
        goal_point=goal_point,
        goal_family=goal_family,
        goal_lam=goal_lam,
        families=families,
        route_edges=route,
        step_size=0.08,
        local_planner_name="projection",
        local_planner_kwargs=dict(
            goal_tol=1e-3,
            max_iters=500,
            projection_tol=1e-10,
            projection_max_iters=50,
            projection_damping=1.0,
        ),
    )

    refined = realize_leaf_route_with_state_attraction(
        start_state=start_state,
        goal_point=goal_point,
        goal_family=goal_family,
        goal_lam=goal_lam,
        families=families,
        route_edges=route,
        project_newton=project_newton,
        step_size=0.08,
        ambient_local_radius=0.7,
        n_local_samples=45,
        n_goal_bias_samples=30,
        goal_band_width=0.20,
        target_residual_threshold=0.25,
        min_transition_separation=1e-5,
        local_planner_name="projection",
        local_planner_kwargs=dict(
            goal_tol=1e-3,
            max_iters=500,
            projection_tol=1e-10,
            projection_max_iters=50,
            projection_damping=1.0,
        ),
    )

    print("\nNominal realization result:")
    print(f"  success     : {nominal.success}")
    print(f"  message     : {nominal.message}")
    print(f"  total length: {total_path_length_from_steps(nominal.steps):.4f}")

    print("\nRefined realization result:")
    print(f"  success     : {refined.success}")
    print(f"  message     : {refined.message}")
    print(f"  total length: {total_path_length_from_steps(refined.steps):.4f}")

    print("\nRefined step diagnostics:")
    for i, step in enumerate(refined.steps):
        path = np.asarray(step.path)
        seg_len = 0.0
        if len(path) >= 2:
            seg_len = float(np.sum(np.linalg.norm(np.diff(path, axis=0), axis=1)))

        nominal_tp = getattr(step, "nominal_transition_point", None)
        refined_flag = getattr(step, "transition_was_refined", False)
        fallback_flag = getattr(step, "used_fallback", False)
        candidate_count = getattr(step, "candidate_count", 0)

        print(
            f"  step {i}: family={step.family_name}[{step.lam}], "
            f"len={seg_len:.4f}, "
            f"nominal={None if nominal_tp is None else np.round(nominal_tp, 4)}, "
            f"chosen={None if step.transition_point is None else np.round(step.transition_point, 4)}, "
            f"refined={refined_flag}, "
            f"fallback={fallback_flag}, "
            f"cands={candidate_count}, "
            f"msg={step.message}"
        )

    fig, ax = plt.subplots(figsize=(10, 7))
    plot_all_families(ax, families)

    nominal_pts = concatenate_steps(nominal.steps)
    if len(nominal_pts) > 0:
        ax.plot(
            nominal_pts[:, 0],
            nominal_pts[:, 1],
            "--",
            lw=2.0,
            color="tab:gray",
            label="nominal realized route",
        )

    refined_pts = concatenate_steps(refined.steps)
    if len(refined_pts) > 0:
        ax.plot(
            refined_pts[:, 0],
            refined_pts[:, 1],
            lw=3.0,
            color="tab:red",
            label="refined realized route",
        )

    # Nominal graph transitions
    for i, e in enumerate(route):
        ax.scatter(
            e.transition_point[0],
            e.transition_point[1],
            s=60,
            marker="o",
            color="tab:blue",
            edgecolor="black",
            zorder=5,
            label="nominal graph transition" if i == 0 else None,
        )

    # Chosen refined transitions
    for i, step in enumerate(refined.steps[:-1]):  # final goal segment has no switch
        if step.transition_point is None:
            continue
        ax.scatter(
            step.transition_point[0],
            step.transition_point[1],
            s=90,
            marker="x",
            color="tab:orange",
            zorder=6,
            label="chosen refined transition" if i == 0 else None,
        )

    ax.scatter(
        case.start_point[0], case.start_point[1],
        s=90, marker="s", color="black", label="start"
    )
    ax.scatter(
        case.goal_point[0], case.goal_point[1],
        s=140, marker="*", color="gold", edgecolor="black", label="goal"
    )

    ax.set_title(
        "Example 36: nominal leaf-graph route with state-dependent refinement\n"
        "blue circles = nominal graph transitions, orange x = chosen refined transitions"
    )
    ax.set_aspect("equal")
    ax.grid(True, alpha=0.25)
    ax.legend()
    plt.tight_layout()
    plt.show()

    plot_leaf_graph(
        graph,
        route=route,
        title="Example 36 leaf graph: nominal route selected first, refined during realization",
    )
    plt.show()


if __name__ == "__main__":
    main()