from __future__ import annotations

import os
import csv
import numpy as np
import matplotlib
matplotlib.use("TkAgg")
import matplotlib.pyplot as plt

from primitive_manifold_planner.families.base import ManifoldFamily
from primitive_manifold_planner.families.leaf_state import LeafState
from primitive_manifold_planner.manifolds import LineManifold, CircleManifold
from primitive_manifold_planner.planning.local import constrained_interpolate
from primitive_manifold_planner.projection import project_newton
from primitive_manifold_planner.planners.leaf_graph import (
    build_leaf_graph,
    shortest_leaf_route,
)
from primitive_manifold_planner.planners.realize_leaf_route import realize_leaf_route


class ParallelLineLeafFamily(ManifoldFamily):
    def __init__(self, name: str, lambdas=None):
        super().__init__(name)
        self._lambdas = lambdas if lambdas is not None else [-1.0, 1.0]

    def manifold(self, lam):
        return LineManifold(
            point=np.array([0.0, lam], dtype=float),
            normal=np.array([0.0, 1.0], dtype=float),
            name=f"{self.name}_lam_{lam}",
        )

    def sample_lambdas(self, context=None):
        return list(self._lambdas)


class SingleCircleLeafFamily(ManifoldFamily):
    def __init__(self, name: str, center=(0.0, 0.0), radii=None):
        super().__init__(name)
        self.center = np.array(center, dtype=float)
        self._radii = radii if radii is not None else [1.05]

    def manifold(self, lam):
        return CircleManifold(
            center=self.center,
            radius=float(lam),
            name=f"{self.name}_r_{lam}",
        )

    def sample_lambdas(self, context=None):
        return list(self._radii)


def informed_seed_points_fn(fam_a, lam_a, fam_b, lam_b):
    seeds = []

    def add_unique(arr):
        for s in arr:
            if not any(np.linalg.norm(s - u) < 1e-8 for u in seeds):
                seeds.append(s)

    if isinstance(fam_a, ParallelLineLeafFamily) and isinstance(fam_b, SingleCircleLeafFamily):
        y = float(lam_a)
        c = fam_b.center
        r = float(lam_b)

        dy = y - c[1]
        if abs(dy) <= r + 1e-9:
            dx_sq = max(r * r - dy * dy, 0.0)
            dx = np.sqrt(dx_sq)
            add_unique([
                np.array([c[0] + dx, y], dtype=float),
                np.array([c[0] - dx, y], dtype=float),
            ])

        xs = np.linspace(c[0] - 1.5 * r, c[0] + 1.5 * r, 11)
        add_unique([np.array([x, y], dtype=float) for x in xs])

        thetas = np.linspace(0.0, 2.0 * np.pi, 14, endpoint=False)
        add_unique([c + r * np.array([np.cos(t), np.sin(t)], dtype=float) for t in thetas])
        return seeds

    if isinstance(fam_a, SingleCircleLeafFamily) and isinstance(fam_b, ParallelLineLeafFamily):
        return informed_seed_points_fn(fam_b, lam_b, fam_a, lam_a)

    if isinstance(fam_a, SingleCircleLeafFamily) and isinstance(fam_b, SingleCircleLeafFamily):
        c1, r1 = fam_a.center, float(lam_a)
        c2, r2 = fam_b.center, float(lam_b)

        thetas = np.linspace(0.0, 2.0 * np.pi, 16, endpoint=False)
        add_unique([c1 + r1 * np.array([np.cos(t), np.sin(t)], dtype=float) for t in thetas])
        add_unique([c2 + r2 * np.array([np.cos(t), np.sin(t)], dtype=float) for t in thetas])

        for t in np.linspace(0.0, 2.0 * np.pi, 8, endpoint=False):
            p1 = c1 + r1 * np.array([np.cos(t), np.sin(t)], dtype=float)
            p2 = c2 + r2 * np.array([np.cos(t), np.sin(t)], dtype=float)
            add_unique([0.5 * (p1 + p2)])
        return seeds

    add_unique([
        np.array([0.0, 0.0], dtype=float),
        np.array([1.0, 0.0], dtype=float),
        np.array([-1.0, 0.0], dtype=float),
        np.array([0.0, 1.0], dtype=float),
        np.array([0.0, -1.0], dtype=float),
    ])
    return seeds


def compute_path_length(realized) -> float:
    total = 0.0
    for step in realized.steps:
        pts = np.asarray(step.path)
        if len(pts) < 2:
            continue
        total += float(sum(np.linalg.norm(pts[i + 1] - pts[i]) for i in range(len(pts) - 1)))
    return total


def route_to_string(route) -> str:
    if route is None or len(route) == 0:
        return ""
    nodes = [route[0].src] + [e.dst for e in route]
    return " -> ".join([f"{fam}[{lam}]" for fam, lam in nodes])


def dominant_bridge_from_route(route) -> str:
    if route is None or len(route) == 0:
        return ""
    for edge in route:
        fam, _ = edge.dst
        if fam in ("left_bridge", "right_bridge"):
            return fam
    return ""


def main():
    np.random.seed(7)

    line_family = ParallelLineLeafFamily("line_family", lambdas=[-1.0, 1.0])
    left_bridge = SingleCircleLeafFamily("left_bridge", center=(-0.9, 0.0), radii=[1.05])
    right_bridge = SingleCircleLeafFamily("right_bridge", center=(0.9, 0.0), radii=[1.05])
    families = [line_family, left_bridge, right_bridge]

    start_state = LeafState("line_family", -1.0, np.array([0.0, -1.0], dtype=float))
    goal_family = line_family
    goal_lam = 1.0

    goal_xs = np.linspace(-2.5, 2.5, 21)

    rows = []

    for gx in goal_xs:
        goal_point = np.array([gx, 1.0], dtype=float)

        graph = build_leaf_graph(
            families=families,
            project_newton=project_newton,
            seed_points_fn=informed_seed_points_fn,
            goal_point=goal_point,
            max_candidates_per_pair=3,
        )

        route = shortest_leaf_route(
            graph,
            start=(start_state.family_name, start_state.lam),
            goal=(goal_family.name, goal_lam),
        )

        if route is None:
            rows.append({
                "goal_x": gx,
                "success": False,
                "chosen_bridge": "",
                "leaf_sequence": "",
                "path_length": np.nan,
                "transition_points": "",
            })
            continue

        realized = realize_leaf_route(
            start_state=start_state,
            goal_point=goal_point,
            goal_family=goal_family,
            goal_lam=goal_lam,
            families=families,
            route_edges=route,
            constrained_interpolate=constrained_interpolate,
            step_size=0.08,
        )

        bridge = dominant_bridge_from_route(route)
        transitions = " ; ".join(
            [f"({np.round(e.transition_point[0],4)}, {np.round(e.transition_point[1],4)})" for e in route]
        )

        rows.append({
            "goal_x": gx,
            "success": bool(realized.success),
            "chosen_bridge": bridge,
            "leaf_sequence": route_to_string(route),
            "path_length": compute_path_length(realized) if realized.success else np.nan,
            "transition_points": transitions,
        })

    out_dir = "outputs/benchmark_results"
    os.makedirs(out_dir, exist_ok=True)
    out_csv = os.path.join(out_dir, "example_24_goal_sweep.csv")

    with open(out_csv, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(
            f,
            fieldnames=[
                "goal_x",
                "success",
                "chosen_bridge",
                "leaf_sequence",
                "path_length",
                "transition_points",
            ],
        )
        writer.writeheader()
        writer.writerows(rows)

    print(f"\nSaved sweep CSV to: {out_csv}")
    print("\n=== Goal sweep summary ===")
    for row in rows:
        print(
            f"goal_x={row['goal_x']:+.2f} | success={row['success']} | "
            f"bridge={row['chosen_bridge']} | path_length={row['path_length']}"
        )

    # Plot 1: goal_x vs chosen bridge
    fig1, ax1 = plt.subplots(figsize=(10, 4))
    yvals = []
    for row in rows:
        if not row["success"]:
            yvals.append(np.nan)
        elif row["chosen_bridge"] == "left_bridge":
            yvals.append(-1)
        elif row["chosen_bridge"] == "right_bridge":
            yvals.append(+1)
        else:
            yvals.append(0)

    ax1.plot(goal_xs, yvals, "o-")
    ax1.set_yticks([-1, 0, 1])
    ax1.set_yticklabels(["left_bridge", "none/other", "right_bridge"])
    ax1.set_xlabel("Goal x-position on top leaf")
    ax1.set_ylabel("Chosen bridge family")
    ax1.set_title("Example 24: Goal position vs chosen bridge family")
    ax1.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig(os.path.join(out_dir, "example_24_goal_sweep_bridge_choice.png"), dpi=180)

    # Plot 2: goal_x vs path length
    fig2, ax2 = plt.subplots(figsize=(10, 4))
    path_lengths = [row["path_length"] for row in rows]
    ax2.plot(goal_xs, path_lengths, "o-")
    ax2.set_xlabel("Goal x-position on top leaf")
    ax2.set_ylabel("Realized path length")
    ax2.set_title("Example 24: Goal position vs realized path length")
    ax2.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig(os.path.join(out_dir, "example_24_goal_sweep_path_length.png"), dpi=180)

    plt.show()


if __name__ == "__main__":
    main()