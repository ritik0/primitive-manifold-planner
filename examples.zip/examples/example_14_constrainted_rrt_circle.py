from __future__ import annotations

import numpy as np
import matplotlib
matplotlib.use("TkAgg")
import matplotlib.pyplot as plt

from primitive_manifold_planner.manifolds import CircleManifold
from primitive_manifold_planner.planning import plan_constrained_rrt
from primitive_manifold_planner.visualization import (
    finalize_2d_axes,
    plot_circle_manifold,
    plot_path_2d,
    plot_start_goal,
)


def main() -> None:
    circle = CircleManifold(center=np.array([0.0, 0.0]), radius=2.0, name="circle")

    start = np.array([2.0, 0.0])
    goal = np.array([0.0, 2.0])

    rng = np.random.default_rng(42)
    result = plan_constrained_rrt(
        manifold=circle,
        start_point=start,
        goal_point=goal,
        bounds_min=np.array([-3.0, -3.0]),
        bounds_max=np.array([3.0, 3.0]),
        max_iters=300,
        step_size=0.2,
        goal_tol=5e-2,
        goal_sample_rate=0.2,
        rng=rng,
    )

    print("=== Constrained RRT on circle ===")
    print(f"Success      : {result.success}")
    print(f"Iterations   : {result.iterations}")
    print(f"Message      : {result.message}")
    print(f"Tree size    : {len(result.tree_points)}")

    fig, ax = plt.subplots(figsize=(7, 7))

    plot_circle_manifold(ax, circle, label="circle manifold")
    plot_start_goal(ax, start, goal)

    if result.tree_points.size > 0:
        ax.scatter(result.tree_points[:, 0], result.tree_points[:, 1], s=15, label="rrt tree nodes")

    if result.path is not None:
        plot_path_2d(ax, result.path, show_points=True, label="rrt path")

    finalize_2d_axes(ax, title="Projection-based constrained RRT on a circle")

    out_path = "example_14_constrained_rrt_circle.png"
    plt.savefig(out_path, dpi=200, bbox_inches="tight")
    print(f"Saved figure to: {out_path}")

    plt.show(block=True)


if __name__ == "__main__":
    main()