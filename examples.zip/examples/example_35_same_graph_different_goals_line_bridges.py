from __future__ import annotations

from dataclasses import dataclass
from typing import List, Tuple
import numpy as np
import matplotlib.pyplot as plt

from primitive_manifold_planner.families.leaf_state import LeafState
from primitive_manifold_planner.manifolds import (
    CircleManifold,
    LineManifold,
)
from primitive_manifold_planner.planners.leaf_graph import (
    build_leaf_graph,
    shortest_leaf_route,
)
from primitive_manifold_planner.planners.realize_leaf_route import realize_leaf_route
from primitive_manifold_planner.projection import project_newton


# ============================================================
# Thin benchmark family wrappers
# ============================================================

class BenchmarkLeafFamily:
    def __init__(self, name: str, lambdas: List[float]):
        self.name = name
        self._lambdas = [float(l) for l in lambdas]

    def manifold(self, lam: float):
        raise NotImplementedError

    def sample_lambdas(self, context=None):
        return list(self._lambdas)

    def lambda_distance(self, lam_a, lam_b) -> float:
        return abs(float(lam_a) - float(lam_b))


class CircleFamilyAdapter(BenchmarkLeafFamily):
    def __init__(self, name: str, center: np.ndarray, lambdas: List[float]):
        super().__init__(name=name, lambdas=lambdas)
        self.center = np.asarray(center, dtype=float)

    def manifold(self, lam: float):
        return CircleManifold(
            center=self.center.copy(),
            radius=float(lam),
            name=f"{self.name}_lambda_{lam:g}",
        )


class HorizontalLineFamily(BenchmarkLeafFamily):
    def manifold(self, lam: float):
        return LineManifold(
            point=np.array([0.0, float(lam)]),
            normal=np.array([0.0, 1.0]),
            name=f"{self.name}_lambda_{lam:g}",
        )


# ============================================================
# Case definition
# ============================================================

@dataclass
class GoalCase:
    goal_point: np.ndarray
    title: str


def build_benchmark():
    families = [
        CircleFamilyAdapter(
            name="left_circle_family",
            center=np.array([-2.0, 0.0]),
            lambdas=[1.40],
        ),
        HorizontalLineFamily(
            name="bridge_line_family",
            lambdas=[-1.00, -0.60, -0.20, 0.20, 0.60, 1.00],
        ),
        CircleFamilyAdapter(
            name="right_circle_family",
            center=np.array([2.0, 0.0]),
            lambdas=[1.40],
        ),
    ]

    start_state = LeafState(
        family_name="left_circle_family",
        lam=1.40,
        x=np.array([-2.0, 1.40]),
    )

    goal_cases = [
        GoalCase(
            goal_point=np.array([2.0, 1.40]),
            title="Goal A: top of right circle",
        ),
        GoalCase(
            goal_point=np.array([3.40, 0.00]),
            title="Goal B: rightmost point of right circle",
        ),
        GoalCase(
            goal_point=np.array([2.0, -1.40]),
            title="Goal C: bottom of right circle",
        ),
    ]

    return families, start_state, goal_cases


# ============================================================
# Graph helpers
# ============================================================

def allowed_family_pair(fam_a_name: str, fam_b_name: str) -> bool:
    allowed = {
        ("left_circle_family", "bridge_line_family"),
        ("bridge_line_family", "left_circle_family"),
        ("bridge_line_family", "right_circle_family"),
        ("right_circle_family", "bridge_line_family"),
    }
    return (fam_a_name, fam_b_name) in allowed


def seed_points_fn(fam_a, lam_a, fam_b, lam_b):
    seeds = []

    seeds.extend([
        np.array([0.0, 0.0], dtype=float),
        np.array([1.0, 0.0], dtype=float),
        np.array([-1.0, 0.0], dtype=float),
        np.array([0.0, 1.0], dtype=float),
        np.array([0.0, -1.0], dtype=float),
    ])

    def add_circle_line_seeds(circle_family, radius, line_y):
        cx, cy = circle_family.center
        r = float(radius)
        y = float(line_y)
        dy = y - cy

        if abs(dy) <= r + 1e-12:
            dx = np.sqrt(max(r * r - dy * dy, 0.0))
            seeds.append(np.array([cx - dx, y], dtype=float))
            seeds.append(np.array([cx + dx, y], dtype=float))

            eps = 0.05
            seeds.append(np.array([cx - dx - eps, y], dtype=float))
            seeds.append(np.array([cx - dx + eps, y], dtype=float))
            seeds.append(np.array([cx + dx - eps, y], dtype=float))
            seeds.append(np.array([cx + dx + eps, y], dtype=float))

        seeds.append(np.array([cx, y], dtype=float))

    if fam_a.name.endswith("circle_family") and fam_b.name == "bridge_line_family":
        add_circle_line_seeds(fam_a, lam_a, lam_b)

    if fam_b.name.endswith("circle_family") and fam_a.name == "bridge_line_family":
        add_circle_line_seeds(fam_b, lam_b, lam_a)

    uniq = []
    for s in seeds:
        if not any(np.linalg.norm(s - t) < 1e-8 for t in uniq):
            uniq.append(s)
    return uniq


def build_restricted_leaf_graph(families, goal_point):
    graph = build_leaf_graph(
        families=families,
        project_newton=project_newton,
        seed_points_fn=seed_points_fn,
        goal_point=goal_point,
        max_candidates_per_pair=2,
    )

    filtered = {}
    for src, edges in graph.adjacency.items():
        kept = []
        for e in edges:
            if allowed_family_pair(e.src[0], e.dst[0]):
                kept.append(e)
        filtered[src] = kept
    graph.adjacency = filtered
    return graph


def edge_cost_fn(edge):
    return 1.0 + edge.score


# ============================================================
# Plot helpers
# ============================================================

def plot_manifold(ax, manifold, color="lightgray", lw=1.2, alpha=0.30):
    if isinstance(manifold, LineManifold):
        p = manifold.point
        n = manifold.normal
        t = np.array([-n[1], n[0]], dtype=float)
        s = np.linspace(-6.0, 6.0, 400)
        pts = p[None, :] + s[:, None] * t[None, :]
        ax.plot(pts[:, 0], pts[:, 1], color=color, lw=lw, alpha=alpha)

    elif isinstance(manifold, CircleManifold):
        th = np.linspace(0.0, 2.0 * np.pi, 400)
        pts = np.column_stack([
            manifold.center[0] + manifold.radius * np.cos(th),
            manifold.center[1] + manifold.radius * np.sin(th),
        ])
        ax.plot(pts[:, 0], pts[:, 1], color=color, lw=lw, alpha=alpha)


def plot_all_families(ax, families):
    for fam in families:
        for lam in fam.sample_lambdas():
            plot_manifold(ax, fam.manifold(lam))


def concatenate_steps(steps) -> np.ndarray:
    pts = []
    for i, step in enumerate(steps):
        path = np.asarray(step.path)
        if len(path) == 0:
            continue
        if i == 0:
            pts.extend(list(path))
        else:
            pts.extend(list(path[1:]))
    if not pts:
        return np.zeros((0, 2))
    return np.asarray(pts)


# ============================================================
# Main
# ============================================================

def main():
    np.random.seed(7)

    families, start_state, goal_cases = build_benchmark()
    goal_family_name = "right_circle_family"
    goal_lam = 1.40
    start_key = (start_state.family_name, start_state.lam)
    goal_key = (goal_family_name, goal_lam)

    fig, axes = plt.subplots(1, 3, figsize=(18, 5))

    print("\nExample 35: same graph, different goals")
    print(f"start = {start_state.family_name}[{start_state.lam}] at {start_state.x}")

    for ax, goal_case in zip(axes, goal_cases):
        graph = build_restricted_leaf_graph(
            families=families,
            goal_point=goal_case.goal_point,
        )

        route = shortest_leaf_route(
            graph=graph,
            start=start_key,
            goal=goal_key,
            edge_cost_fn=edge_cost_fn,
        )

        if route is None:
            print(f"\n{goal_case.title}: no route found")
            plot_all_families(ax, families)
            ax.set_title(goal_case.title + "\n(no route)")
            ax.set_aspect("equal")
            ax.grid(True, alpha=0.25)
            continue

        chosen_bridge_lambda = None
        for e in route:
            if e.dst[0] == "bridge_line_family":
                chosen_bridge_lambda = e.dst[1]

        realized = realize_leaf_route(
            start_state=start_state,
            goal_point=goal_case.goal_point,
            goal_family=type("GoalFamilyStub", (), {"name": goal_family_name})(),
            goal_lam=goal_lam,
            families=families,
            route_edges=route,
            step_size=0.08,
            local_planner_name="projection",
            local_planner_kwargs=dict(
                goal_tol=1e-3,
                max_iters=500,
                projection_tol=1e-10,
                projection_max_iters=50,
                projection_damping=1.0,
            ),
        )

        print(f"\n{goal_case.title}")
        print(f"  goal point          : {goal_case.goal_point}")
        print(f"  chosen bridge lambda: {chosen_bridge_lambda}")
        print(f"  success             : {realized.success}")

        plot_all_families(ax, families)

        pts = concatenate_steps(realized.steps)
        if len(pts) > 0:
            ax.plot(pts[:, 0], pts[:, 1], color="tab:red", lw=3.0)

        for e in route:
            ax.scatter(
                e.transition_point[0],
                e.transition_point[1],
                s=45,
                marker="o",
                color="tab:blue",
                edgecolor="black",
                zorder=5,
            )

        ax.scatter(start_state.x[0], start_state.x[1], s=80, marker="s", color="black")
        ax.scatter(goal_case.goal_point[0], goal_case.goal_point[1], s=120, marker="*", color="gold", edgecolor="black")

        ax.set_title(f"{goal_case.title}\nchosen λ = {chosen_bridge_lambda}")
        ax.set_aspect("equal")
        ax.grid(True, alpha=0.25)

    plt.tight_layout()
    plt.show()


if __name__ == "__main__":
    main()