from __future__ import annotations

import numpy as np
import matplotlib
matplotlib.use("TkAgg")
import matplotlib.pyplot as plt

from primitive_manifold_planner.families.base import ManifoldFamily
from primitive_manifold_planner.families.leaf_state import LeafState

from primitive_manifold_planner.manifolds import LineManifold, CircleManifold
from primitive_manifold_planner.planning.local import constrained_interpolate
from primitive_manifold_planner.projection import project_newton

from primitive_manifold_planner.planners.leaf_graph import (
    build_leaf_graph,
    shortest_leaf_route,
)
from primitive_manifold_planner.planners.realize_leaf_route import realize_leaf_route


class ParallelLineLeafFamily(ManifoldFamily):
    def __init__(self, name: str, lambdas=None):
        super().__init__(name)
        self._lambdas = lambdas if lambdas is not None else [-1.0, 0.0, 1.0]

    def manifold(self, lam):
        return LineManifold(
            point=np.array([0.0, lam], dtype=float),
            normal=np.array([0.0, 1.0], dtype=float),
            name=f"{self.name}_lam_{lam}",
        )

    def sample_lambdas(self, context=None):
        return list(self._lambdas)


class ConcentricCircleLeafFamily(ManifoldFamily):
    def __init__(self, name: str, center=(0.0, 0.0), radii=None):
        super().__init__(name)
        self.center = np.array(center, dtype=float)
        self._radii = radii if radii is not None else [0.9, 1.4]

    def manifold(self, lam):
        return CircleManifold(
            center=self.center,
            radius=float(lam),
            name=f"{self.name}_r_{lam}",
        )

    def sample_lambdas(self, context=None):
        return list(self._radii)


def plot_family(ax, fam, color="lightgray", n=300):
    if isinstance(fam, ParallelLineLeafFamily):
        xs = np.linspace(-3, 3, n)
        for lam in fam.sample_lambdas():
            ys = np.full_like(xs, lam)
            ax.plot(xs, ys, "--", color=color, linewidth=1.0)

    elif isinstance(fam, ConcentricCircleLeafFamily):
        ts = np.linspace(0, 2 * np.pi, n)
        for r in fam.sample_lambdas():
            xs = fam.center[0] + r * np.cos(ts)
            ys = fam.center[1] + r * np.sin(ts)
            ax.plot(xs, ys, "--", color=color, linewidth=1.0)


def plot_realized_result(ax, result):
    colors = {
        "line_family": "tab:blue",
        "circle_family": "tab:orange",
    }

    for step in result.steps:
        pts = np.asarray(step.path)
        if len(pts) == 0:
            continue
        ax.plot(
            pts[:, 0],
            pts[:, 1],
            "-",
            color=colors.get(step.family_name, "tab:green"),
            linewidth=2.5,
        )
        if step.transition_point is not None:
            tp = step.transition_point
            ax.scatter(tp[0], tp[1], color="red", s=55, marker="x")


def informed_seed_points_fn(fam_a, lam_a, fam_b, lam_b):
    """
    Better seeds for finding leaf intersections.

    This is the important upgrade:
    instead of weak generic seeds, propose seeds near where
    intersections are likely to exist.
    """
    seeds = []

    # -----------------------------
    # line-family vs circle-family
    # -----------------------------
    if isinstance(fam_a, ParallelLineLeafFamily) and isinstance(fam_b, ConcentricCircleLeafFamily):
        y = float(lam_a)
        c = fam_b.center
        r = float(lam_b)

        # If |y-cy| <= r, the horizontal line can intersect the circle.
        dy = y - c[1]
        if abs(dy) <= r + 1e-9:
            dx_sq = max(r * r - dy * dy, 0.0)
            dx = np.sqrt(dx_sq)

            # Seeds near the actual intersections
            seeds.append(np.array([c[0] + dx, y], dtype=float))
            seeds.append(np.array([c[0] - dx, y], dtype=float))

        # Additional nearby seeds along the line
        for x in np.linspace(c[0] - 1.5 * r, c[0] + 1.5 * r, 9):
            seeds.append(np.array([x, y], dtype=float))

        # Circle anchor seeds
        for theta in np.linspace(0.0, 2.0 * np.pi, 12, endpoint=False):
            seeds.append(c + r * np.array([np.cos(theta), np.sin(theta)], dtype=float))

    elif isinstance(fam_a, ConcentricCircleLeafFamily) and isinstance(fam_b, ParallelLineLeafFamily):
        # symmetric case
        return informed_seed_points_fn(fam_b, lam_b, fam_a, lam_a)

    # -----------------------------
    # circle-family vs circle-family
    # -----------------------------
    elif isinstance(fam_a, ConcentricCircleLeafFamily) and isinstance(fam_b, ConcentricCircleLeafFamily):
        c1 = fam_a.center
        r1 = float(lam_a)
        c2 = fam_b.center
        r2 = float(lam_b)

        # Sample around both circles
        for theta in np.linspace(0.0, 2.0 * np.pi, 16, endpoint=False):
            seeds.append(c1 + r1 * np.array([np.cos(theta), np.sin(theta)], dtype=float))
            seeds.append(c2 + r2 * np.array([np.cos(theta), np.sin(theta)], dtype=float))

        # Midpoints between corresponding radial samples
        for theta in np.linspace(0.0, 2.0 * np.pi, 8, endpoint=False):
            p1 = c1 + r1 * np.array([np.cos(theta), np.sin(theta)], dtype=float)
            p2 = c2 + r2 * np.array([np.cos(theta), np.sin(theta)], dtype=float)
            seeds.append(0.5 * (p1 + p2))

    # -----------------------------
    # line-family vs line-family
    # -----------------------------
    elif isinstance(fam_a, ParallelLineLeafFamily) and isinstance(fam_b, ParallelLineLeafFamily):
        y1 = float(lam_a)
        y2 = float(lam_b)

        # Parallel distinct lines do not intersect, but if same leaf, we could seed anyway.
        if abs(y1 - y2) < 1e-9:
            for x in np.linspace(-3.0, 3.0, 9):
                seeds.append(np.array([x, y1], dtype=float))
        else:
            # Distinct parallel lines: no intersection
            return []

    else:
        # generic fallback
        seeds.extend([
            np.array([0.0, 0.0], dtype=float),
            np.array([1.0, 0.0], dtype=float),
            np.array([-1.0, 0.0], dtype=float),
            np.array([0.0, 1.0], dtype=float),
            np.array([0.0, -1.0], dtype=float),
        ])

    # Remove near-duplicates
    unique = []
    for s in seeds:
        if not any(np.linalg.norm(s - u) < 1e-8 for u in unique):
            unique.append(s)
    return unique


def main():
    np.random.seed(7)

    line_family = ParallelLineLeafFamily("line_family", lambdas=[-1.0, 0.0, 1.0])
    circle_family = ConcentricCircleLeafFamily("circle_family", center=(0.0, 0.0), radii=[0.9, 1.4])
    families = [line_family, circle_family]

    start_x = np.array([-2.2, -1.0], dtype=float)
    goal_point = np.array([2.2, 1.0], dtype=float)

    start_state = LeafState("line_family", -1.0, start_x)
    goal_family = line_family
    goal_lam = 1.0

    start_key = (start_state.family_name, start_state.lam)
    goal_key = (goal_family.name, goal_lam)

    graph = build_leaf_graph(
        families=families,
        project_newton=project_newton,
        seed_points_fn=informed_seed_points_fn,
    )

    print("\n=== Graph adjacency ===")
    for node, edges in graph.adjacency.items():
        print(f"{node}: {len(edges)} edge(s)")
        for e in edges:
            print(f"    -> {e.dst}, transition={np.round(e.transition_point, 4)}, score={e.score:.4f}")

    route = shortest_leaf_route(graph, start=start_key, goal=goal_key)

    print("\n=== Example 18 leaf-graph route ===")
    if route is None:
        print("No leaf route found.")
        return

    for i, edge in enumerate(route):
        print(f"  edge {i}: {edge.src} -> {edge.dst}, transition={np.round(edge.transition_point, 4)}, score={edge.score:.4f}")

    realized = realize_leaf_route(
        start_state=start_state,
        goal_point=goal_point,
        goal_family=goal_family,
        goal_lam=goal_lam,
        families=families,
        route_edges=route,
        constrained_interpolate=constrained_interpolate,
        step_size=0.08,
    )

    print("\n=== Example 18 realized route ===")
    print("success:", realized.success)
    print("message:", realized.message)
    print("num steps:", len(realized.steps))

    fig, ax = plt.subplots(figsize=(8, 8))
    plot_family(ax, line_family, color="lightblue")
    plot_family(ax, circle_family, color="moccasin")
    plot_realized_result(ax, realized)

    ax.scatter(start_x[0], start_x[1], color="purple", s=90, label="start")
    ax.scatter(goal_point[0], goal_point[1], color="green", s=90, label="goal")

    ax.set_aspect("equal", adjustable="box")
    ax.set_title("Example 18: Leaf-graph multimodal switching")
    ax.legend()
    ax.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig("example_18_parallel_family_goal_aware_switch.png", dpi=180)
    plt.show()


if __name__ == "__main__":
    main()