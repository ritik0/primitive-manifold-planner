from __future__ import annotations

import numpy as np
import matplotlib.pyplot as plt

from primitive_manifold_planner.families.leaf_state import LeafState
from primitive_manifold_planner.planners.multimodal_component_planner import (
    MultimodalComponentPlanner,
    PlannerConfig,
)
from primitive_manifold_planner.planners.admissibility import (
    CoordinateAbsoluteValueAdmissibility,
    GoalDistanceAdmissibility,
    SumAdmissibilityModel,
    TransitionContext,
)
from primitive_manifold_planner.planners.mode_semantics import PlanningSemanticContext
from primitive_manifold_planner.planners.semantic_templates import (
    build_support_bridge_transfer_goal_semantic_model,
)
from primitive_manifold_planner.planners.component_discovery import (
    StaticComponentModel,
    build_component_model_registry,
)
from primitive_manifold_planner.projection import project_newton

from primitive_manifold_planner.examplesupport.planar2link import (
    Planar2LinkKinematics,
    wrap_q,
    torus_distance,
)
from primitive_manifold_planner.examplesupport.planar2link_families import (
    EndEffectorXFamily,
    EndEffectorYFamily,
    Joint2Family,
)
from primitive_manifold_planner.examplesupport.planar2link_helpers import (
    make_seed_points_fn,
    allowed_switch_pair,
)


def sample_leaf_points(manifold, q1_vals, q2_vals, tol=1e-3):
    pts = []
    for q1 in q1_vals:
        for q2 in q2_vals:
            q = np.array([q1, q2], dtype=float)
            try:
                proj = project_newton(
                    manifold=manifold,
                    x0=q,
                    tol=1e-10,
                    max_iters=50,
                    damping=1.0,
                )
            except Exception:
                continue
            if not proj.success:
                continue
            q_proj = wrap_q(np.asarray(proj.x_projected, dtype=float))
            if np.linalg.norm(manifold.residual(q_proj)) <= tol:
                duplicate = False
                for p in pts:
                    if np.linalg.norm(wrap_q(q_proj - p)) < 1e-2:
                        duplicate = True
                        break
                if not duplicate:
                    pts.append(q_proj)
    if len(pts) == 0:
        return np.zeros((0, 2))
    return np.asarray(pts)


def main():
    np.random.seed(7)

    robot = Planar2LinkKinematics(l1=1.0, l2=1.0)

    families = [
        EndEffectorXFamily("left_x_family", robot, [-1.00]),
        Joint2Family("switch_q2_family", [0.0]),
        EndEffectorYFamily("bridge_y_family", robot, [-1.00, 1.00]),
        EndEffectorXFamily("right_x_family", robot, [1.00]),
    ]

    q1_vals = np.linspace(-np.pi, np.pi, 25)
    q2_vals = np.linspace(-np.pi, np.pi, 25)

    def seed_samples_for_leaf(fam, lam: float):
        return sample_leaf_points(fam.manifold(lam), q1_vals, q2_vals, tol=1e-3)

    def should_discover(fam, lam: float) -> bool:
        _ = lam
        return fam.name != "switch_q2_family"

    def static_model_for_leaf(fam, lam: float):
        _ = lam
        if fam.name == "switch_q2_family":
            return StaticComponentModel(ids=["switch"])
        return None

    component_registry, discovered = build_component_model_registry(
        families=families,
        seed_samples_for_leaf_fn=seed_samples_for_leaf,
        should_discover_fn=should_discover,
        static_model_fn=static_model_for_leaf,
        assignment_distance_fn=torus_distance,
        local_planner_name="projection",
        local_planner_kwargs=dict(
            goal_tol=1e-3,
            max_iters=400,
            projection_tol=1e-10,
            projection_max_iters=50,
            projection_damping=1.0,
        ),
        step_size=0.08,
        neighbor_radius=0.45,
    )

    start_q = wrap_q(np.array([0.5 * np.pi, 0.5 * np.pi], dtype=float))
    goal_q = wrap_q(np.array([0.0, -0.5 * np.pi], dtype=float))

    switch_admissibility = SumAdmissibilityModel(
        [
            GoalDistanceAdmissibility(weight=0.15, distance_fn=torus_distance),
            CoordinateAbsoluteValueAdmissibility(axis=0, weight=0.05),
        ]
    )

    def semantic_admissibility(context: PlanningSemanticContext) -> float:
        involved = {context.source_family_name, context.target_family_name}
        if "switch_q2_family" not in involved or context.point is None:
            return 0.0
        return float(
            switch_admissibility(
                TransitionContext(
                    source_family_name=context.source_family_name,
                    source_lam=context.source_lam,
                    target_family_name=context.target_family_name,
                    target_lam=context.target_lam,
                    point=np.asarray(context.point, dtype=float),
                    goal_point=(
                        None
                        if context.goal_point is None
                        else np.asarray(context.goal_point, dtype=float)
                    ),
                    metadata=context.metadata,
                )
            )
        )

    semantic_model = build_support_bridge_transfer_goal_semantic_model(
        support_families=["left_x_family"],
        bridge_families=["bridge_y_family"],
        transfer_families=["switch_q2_family"],
        goal_support_families=["right_x_family"],
        transition_admissibility_fn=semantic_admissibility,
    )

    config = PlannerConfig(
        max_candidates_per_pair=8,
        semantic_model=semantic_model,
        wrap_state_fn=wrap_q,
        state_distance_fn=torus_distance,
        local_planner_name="projection",
        local_planner_kwargs=dict(
            goal_tol=1e-3,
            max_iters=1200,
            projection_tol=1e-10,
            projection_max_iters=50,
            projection_damping=1.0,
        ),
        step_size=0.08,
    )

    planner = MultimodalComponentPlanner(
        families=families,
        project_newton=project_newton,
        seed_points_fn=make_seed_points_fn(robot),
        component_model_registry=component_registry,
        allowed_family_pair_fn=allowed_switch_pair,
        config=config,
    )

    start_state = LeafState("left_x_family", -1.0, start_q.copy())

    result = planner.plan_with_inferred_components(
        start_state=start_state,
        goal_family_name="right_x_family",
        goal_lam=1.0,
        goal_q=goal_q.copy(),
    )

    start_comp = planner.infer_component("left_x_family", -1.0, start_q)
    goal_comp = planner.infer_component("right_x_family", 1.0, goal_q)

    print("\nExample 55: automatic component discovery demo")
    print(f"start_q = {np.round(start_q, 4)}")
    print(f"goal_q  = {np.round(goal_q, 4)}")
    print(f"auto start component = {start_comp}")
    print(f"auto goal component  = {goal_comp}")
    print(f"route_found = {result.route_found}")
    print(f"realization_success = {result.realization_success}")
    print(f"path_length = {result.path_length:.4f}")
    print(f"message = {result.message}")
    print(f"route = {result.diagnostics.selected_route_string}")
    print(f"route base score = {result.diagnostics.selected_route_base_score:.4f}")
    print(f"route admissibility cost = {result.diagnostics.selected_route_admissibility_cost:.4f}")
    print(f"route total edge cost = {result.diagnostics.selected_route_total_edge_cost:.4f}")

    fig, ax = plt.subplots(figsize=(8, 6))

    # Plot discovered samples/components for x/y leaves
    for (fam_name, lam), disc in discovered.items():
        for comp in disc.components:
            pts = np.asarray(comp.samples)
            ax.scatter(
                pts[:, 0], pts[:, 1],
                s=12,
                alpha=0.45,
                label=f"{fam_name}[{lam}] comp {comp.component_id}" if comp.component_id == 0 else None,
            )

    if result.realization is not None and result.realization.success:
        path = []
        for i, step in enumerate(result.realization.steps):
            p = np.asarray(step.path)
            if len(p) == 0:
                continue
            if i == 0:
                path.extend(list(p))
            else:
                path.extend(list(p[1:]))
        path = np.asarray(path)
        if len(path) > 0:
            ax.plot(path[:, 0], path[:, 1], linewidth=3, label="realized path")

    ax.scatter(start_q[0], start_q[1], s=80, marker="s", color="black", label="start")
    ax.scatter(goal_q[0], goal_q[1], s=120, marker="*", color="gold", edgecolor="black", label="goal")
    ax.set_xlim([-np.pi, np.pi])
    ax.set_ylim([-np.pi, np.pi])
    ax.set_xlabel("q1 [rad]")
    ax.set_ylabel("q2 [rad]")
    ax.set_title("Automatic component discovery on leaves")
    ax.grid(True, alpha=0.25)
    ax.legend()
    plt.tight_layout()
    plt.show()


if __name__ == "__main__":
    main()
