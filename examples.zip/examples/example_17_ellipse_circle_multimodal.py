from __future__ import annotations

import numpy as np
import matplotlib
matplotlib.use("TkAgg")
import matplotlib.pyplot as plt

from primitive_manifold_planner.manifolds import CircleManifold, EllipseManifold
from primitive_manifold_planner.planning import build_mode_graph, plan_multimodal_route
from primitive_manifold_planner.visualization import (
    finalize_2d_axes,
    plot_circle_manifold,
    plot_ellipse_manifold,
    plot_path_2d,
    plot_start_goal,
    plot_transition_candidates_2d,
)


def main() -> None:
    ellipse = EllipseManifold(center=np.array([0.0, 0.0]), a=3.0, b=2.0, name="ellipse")
    circle = CircleManifold(center=np.array([1.0, 0.0]), radius=2.0, name="circle")

    manifolds = {
        "ellipse": ellipse,
        "circle": circle,
    }

    start_point = ellipse.point_from_angle(np.pi)
    goal_point = np.array([3.0, 0.0])  # on circle

    rng = np.random.default_rng(9)
    graph, diagnostics = build_mode_graph(
        manifolds=manifolds,
        bounds_min=np.array([-4.0, -3.0]),
        bounds_max=np.array([4.0, 3.0]),
        num_seeds=150,
        tol=1e-8,
        rng=rng,
    )

    print("=== Mode graph ===")
    print(graph)
    print(f"Nodes: {list(graph.nodes.keys())}")
    print(f"Edges: {len(graph.edges)}")

    for pair, diag in diagnostics.items():
        print(f"\nPair {pair}")
        print(f"  success           : {diag.success}")
        print(f"  message           : {diag.message}")
        print(f"  # candidates      : {len(diag.candidates)}")

    result = plan_multimodal_route(
        graph=graph,
        start_mode="ellipse",
        goal_mode="circle",
        start_point=start_point,
        goal_point=goal_point,
        step_size=0.15,
        goal_tol=5e-2,
        max_iters=900,
    )

    print("\n=== Multimodal plan result ===")
    print(f"Success        : {result.success}")
    print(f"Message        : {result.message}")

    selected_transition = None
    if result.route is not None:
        print(f"Mode sequence  : {result.route.mode_sequence}")
        print(f"# transitions  : {len(result.route.transition_steps)}")

        for i, step in enumerate(result.route.transition_steps):
            print(f"\n  Transition {i + 1}")
            print(f"    from       : {step.from_mode}")
            print(f"    to         : {step.to_mode}")
            print(f"    point      : {step.transition_point}")
            print(f"    residual   : {step.residual_norm:.3e}")
            selected_transition = step.transition_point

    fig, ax = plt.subplots(figsize=(8, 7))

    plot_ellipse_manifold(ax, ellipse, label="ellipse")
    plot_circle_manifold(ax, circle, label="circle")
    plot_start_goal(ax, start_point, goal_point)

    edge = graph.get_edge("ellipse", "circle")
    if edge is not None:
        plot_transition_candidates_2d(
            ax,
            edge.transition_candidates,
            selected_point=selected_transition,
            annotate=True,
        )

    if result.full_path is not None:
        plot_path_2d(ax, result.full_path, show_points=True, label="full multimodal path")

    finalize_2d_axes(ax, title="Ellipse-circle multimodal planning")

    out_path = "example_17_ellipse_circle_multimodal.png"
    plt.savefig(out_path, dpi=200, bbox_inches="tight")
    print(f"Saved figure to: {out_path}")

    plt.show(block=True)


if __name__ == "__main__":
    main()