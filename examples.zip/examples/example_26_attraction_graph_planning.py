from __future__ import annotations

import numpy as np
import matplotlib
matplotlib.use("TkAgg")
import matplotlib.pyplot as plt

from primitive_manifold_planner.families.base import ManifoldFamily
from primitive_manifold_planner.families.leaf_state import LeafState
from primitive_manifold_planner.manifolds import LineManifold, CircleManifold
from primitive_manifold_planner.planning.local import constrained_interpolate
from primitive_manifold_planner.projection import project_newton
from primitive_manifold_planner.planners.realize_leaf_route import realize_leaf_route
from primitive_manifold_planner.planners.leaf_graph_attraction import (
    build_leaf_graph_via_attraction,
    shortest_leaf_route,
)


class ParallelLineLeafFamily(ManifoldFamily):
    def __init__(self, name: str, lambdas=None):
        super().__init__(name)
        self._lambdas = lambdas if lambdas is not None else [-1.0, 1.0]

    def manifold(self, lam):
        return LineManifold(
            point=np.array([0.0, lam], dtype=float),
            normal=np.array([0.0, 1.0], dtype=float),
            name=f"{self.name}_lam_{lam}",
        )

    def sample_lambdas(self, context=None):
        return list(self._lambdas)


class SingleCircleLeafFamily(ManifoldFamily):
    def __init__(self, name: str, center=(0.0, 0.0), radii=None):
        super().__init__(name)
        self.center = np.array(center, dtype=float)
        self._radii = radii if radii is not None else [1.05]

    def manifold(self, lam):
        return CircleManifold(
            center=self.center,
            radius=float(lam),
            name=f"{self.name}_r_{lam}",
        )

    def sample_lambdas(self, context=None):
        return list(self._radii)


def plot_family(ax, fam, color="lightgray", n=300):
    if isinstance(fam, ParallelLineLeafFamily):
        xs = np.linspace(-3.2, 3.2, n)
        for lam in fam.sample_lambdas():
            ys = np.full_like(xs, lam)
            ax.plot(xs, ys, "--", color=color, linewidth=1.2)

    elif isinstance(fam, SingleCircleLeafFamily):
        ts = np.linspace(0.0, 2.0 * np.pi, n)
        for r in fam.sample_lambdas():
            xs = fam.center[0] + r * np.cos(ts)
            ys = fam.center[1] + r * np.sin(ts)
            ax.plot(xs, ys, "--", color=color, linewidth=1.2)


def plot_graph_edges(ax, graph):
    for _, edges in graph.adjacency.items():
        for e in edges:
            p = e.transition_point
            ax.scatter(p[0], p[1], color="red", s=22, alpha=0.45)


def plot_realized_result(ax, result):
    color_map = {
        "line_family": "tab:blue",
        "left_bridge": "tab:orange",
        "right_bridge": "tab:green",
    }

    for step in result.steps:
        pts = np.asarray(step.path)
        if len(pts) == 0:
            continue
        ax.plot(
            pts[:, 0],
            pts[:, 1],
            "-",
            color=color_map.get(step.family_name, "tab:purple"),
            linewidth=2.8,
        )

        if step.transition_point is not None:
            tp = step.transition_point
            ax.scatter(tp[0], tp[1], color="black", s=70, marker="x")


def main():
    np.random.seed(7)

    line_family = ParallelLineLeafFamily("line_family", lambdas=[-1.0, 1.0])
    left_bridge = SingleCircleLeafFamily("left_bridge", center=(-0.9, 0.0), radii=[1.05])
    right_bridge = SingleCircleLeafFamily("right_bridge", center=(0.9, 0.0), radii=[1.05])

    families = [line_family, left_bridge, right_bridge]

    start_x = np.array([0.0, -1.0], dtype=float)
    goal_point = np.array([2.25, 1.0], dtype=float)

    start_state = LeafState("line_family", -1.0, start_x)
    goal_family = line_family
    goal_lam = 1.0

    # Representative points per leaf: this matters for attraction-based graph discovery
    current_point_map = {
        ("line_family", -1.0): start_x,
        ("line_family", 1.0): goal_point,
        ("left_bridge", 1.05): np.array([-0.9 + 1.05, 0.0], dtype=float),
        ("right_bridge", 1.05): np.array([0.9 + 1.05, 0.0], dtype=float),
    }

    graph = build_leaf_graph_via_attraction(
        families=families,
        project_newton=project_newton,
        current_point_map=current_point_map,
        goal_point=goal_point,
        max_candidates_per_pair=3,
        ambient_local_radius=0.7,
        n_local_samples=45,
        n_goal_bias_samples=35,
        goal_band_width=0.20,
        target_residual_threshold=0.30,
    )

    print("\n=== Example 26 attraction-built graph adjacency ===")
    for node, edges in graph.adjacency.items():
        print(f"{node}: {len(edges)} edge(s)")
        for e in edges:
            print(
                f"    -> {e.dst}, cand={e.candidate_index}, "
                f"transition={np.round(e.transition_point, 4)}, score={e.score:.4f}"
            )

    route = shortest_leaf_route(
        graph,
        start=(start_state.family_name, start_state.lam),
        goal=(goal_family.name, goal_lam),
    )

    print("\n=== Example 26 chosen route ===")
    if route is None:
        print("No leaf route found.")
        return

    for i, edge in enumerate(route):
        print(
            f"  edge {i}: {edge.src} -> {edge.dst}, "
            f"cand={edge.candidate_index}, "
            f"transition={np.round(edge.transition_point, 4)}, score={edge.score:.4f}"
        )

    realized = realize_leaf_route(
        start_state=start_state,
        goal_point=goal_point,
        goal_family=goal_family,
        goal_lam=goal_lam,
        families=families,
        route_edges=route,
        constrained_interpolate=constrained_interpolate,
        step_size=0.08,
    )

    print("\n=== Example 26 realized route ===")
    print("success:", realized.success)
    print("message:", realized.message)
    print("num steps:", len(realized.steps))

    fig, ax = plt.subplots(figsize=(9, 8))
    plot_family(ax, line_family, color="lightblue")
    plot_family(ax, left_bridge, color="moccasin")
    plot_family(ax, right_bridge, color="honeydew")
    plot_graph_edges(ax, graph)
    plot_realized_result(ax, realized)

    ax.scatter(start_x[0], start_x[1], color="purple", s=95, label="start")
    ax.scatter(goal_point[0], goal_point[1], color="green", s=95, label="goal")

    ax.set_aspect("equal", adjustable="box")
    ax.set_title("Example 26: Attraction-based leaf-graph planning")
    ax.legend()
    ax.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig("example_26_attraction_graph_planning.png", dpi=180)
    plt.show()


if __name__ == "__main__":
    main()