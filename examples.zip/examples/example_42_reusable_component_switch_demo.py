from __future__ import annotations

from dataclasses import dataclass
from typing import List
import numpy as np
import matplotlib.pyplot as plt

from primitive_manifold_planner.families.leaf_state import LeafState
from primitive_manifold_planner.planners.component_leaf_graph import (
    build_component_leaf_graph,
    shortest_component_route,
)
from primitive_manifold_planner.planners.realize_component_leaf_route import (
    realize_component_route,
)
from primitive_manifold_planner.projection import project_newton


# ============================================================
# Simple 2-link planar arm kinematics
# ============================================================

class Planar2LinkKinematics:
    def __init__(self, l1: float = 1.0, l2: float = 1.0):
        self.l1 = float(l1)
        self.l2 = float(l2)

    def fk(self, q: np.ndarray) -> np.ndarray:
        q = np.asarray(q, dtype=float)
        q1, q2 = q
        x = self.l1 * np.cos(q1) + self.l2 * np.cos(q1 + q2)
        y = self.l1 * np.sin(q1) + self.l2 * np.sin(q1 + q2)
        return np.array([x, y], dtype=float)

    def jacobian_xy(self, q: np.ndarray) -> np.ndarray:
        q = np.asarray(q, dtype=float)
        q1, q2 = q
        dx_dq1 = -self.l1 * np.sin(q1) - self.l2 * np.sin(q1 + q2)
        dx_dq2 = -self.l2 * np.sin(q1 + q2)
        dy_dq1 = self.l1 * np.cos(q1) + self.l2 * np.cos(q1 + q2)
        dy_dq2 = self.l2 * np.cos(q1 + q2)
        return np.array(
            [
                [dx_dq1, dx_dq2],
                [dy_dq1, dy_dq2],
            ],
            dtype=float,
        )


# ============================================================
# Manifolds
# ============================================================

class EndEffectorXManifold:
    def __init__(self, robot: Planar2LinkKinematics, target_x: float, name: str):
        self.robot = robot
        self.target_x = float(target_x)
        self.name = name

    def _coerce_point(self, q: np.ndarray) -> np.ndarray:
        q = np.asarray(q, dtype=float).reshape(-1)
        return q[:2].copy()

    def residual(self, q: np.ndarray) -> np.ndarray:
        q = self._coerce_point(q)
        return np.array([self.robot.fk(q)[0] - self.target_x], dtype=float)

    def jacobian(self, q: np.ndarray) -> np.ndarray:
        q = self._coerce_point(q)
        return self.robot.jacobian_xy(q)[0:1, :]

    def is_valid(self, q: np.ndarray, tol: float = 1e-6) -> bool:
        return float(np.linalg.norm(self.residual(q))) <= tol


class EndEffectorYManifold:
    def __init__(self, robot: Planar2LinkKinematics, target_y: float, name: str):
        self.robot = robot
        self.target_y = float(target_y)
        self.name = name

    def _coerce_point(self, q: np.ndarray) -> np.ndarray:
        q = np.asarray(q, dtype=float).reshape(-1)
        return q[:2].copy()

    def residual(self, q: np.ndarray) -> np.ndarray:
        q = self._coerce_point(q)
        return np.array([self.robot.fk(q)[1] - self.target_y], dtype=float)

    def jacobian(self, q: np.ndarray) -> np.ndarray:
        q = self._coerce_point(q)
        return self.robot.jacobian_xy(q)[1:2, :]

    def is_valid(self, q: np.ndarray, tol: float = 1e-6) -> bool:
        return float(np.linalg.norm(self.residual(q))) <= tol


class Joint2Manifold:
    def __init__(self, target_q2: float, name: str):
        self.target_q2 = float(target_q2)
        self.name = name

    def _coerce_point(self, q: np.ndarray) -> np.ndarray:
        q = np.asarray(q, dtype=float).reshape(-1)
        return q[:2].copy()

    def residual(self, q: np.ndarray) -> np.ndarray:
        q = self._coerce_point(q)
        return np.array([q[1] - self.target_q2], dtype=float)

    def jacobian(self, q: np.ndarray) -> np.ndarray:
        _ = self._coerce_point(q)
        return np.array([[0.0, 1.0]], dtype=float)

    def is_valid(self, q: np.ndarray, tol: float = 1e-6) -> bool:
        return float(np.linalg.norm(self.residual(q))) <= tol


# ============================================================
# Families
# ============================================================

class BenchmarkLeafFamily:
    def __init__(self, name: str, lambdas: List[float]):
        self.name = name
        self._lambdas = [float(v) for v in lambdas]

    def manifold(self, lam: float):
        raise NotImplementedError

    def sample_lambdas(self, context=None):
        return list(self._lambdas)

    def lambda_distance(self, lam_a, lam_b) -> float:
        return abs(float(lam_a) - float(lam_b))


class EndEffectorXFamily(BenchmarkLeafFamily):
    def __init__(self, name: str, robot: Planar2LinkKinematics, lambdas: List[float]):
        super().__init__(name=name, lambdas=lambdas)
        self.robot = robot

    def manifold(self, lam: float):
        return EndEffectorXManifold(
            robot=self.robot,
            target_x=float(lam),
            name=f"{self.name}_lambda_{lam:g}",
        )


class EndEffectorYFamily(BenchmarkLeafFamily):
    def __init__(self, name: str, robot: Planar2LinkKinematics, lambdas: List[float]):
        super().__init__(name=name, lambdas=lambdas)
        self.robot = robot

    def manifold(self, lam: float):
        return EndEffectorYManifold(
            robot=self.robot,
            target_y=float(lam),
            name=f"{self.name}_lambda_{lam:g}",
        )


class Joint2Family(BenchmarkLeafFamily):
    def manifold(self, lam: float):
        return Joint2Manifold(
            target_q2=float(lam),
            name=f"{self.name}_lambda_{lam:g}",
        )


# ============================================================
# Helper functions for torus / components / seeding
# ============================================================

def wrap_to_pi(angle: float) -> float:
    return (float(angle) + np.pi) % (2.0 * np.pi) - np.pi


def wrap_q(q: np.ndarray) -> np.ndarray:
    q = np.asarray(q, dtype=float).copy()
    q[0] = wrap_to_pi(q[0])
    q[1] = wrap_to_pi(q[1])
    return q


def torus_diff(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    a = np.asarray(a, dtype=float)
    b = np.asarray(b, dtype=float)
    d = a - b
    d[0] = wrap_to_pi(d[0])
    d[1] = wrap_to_pi(d[1])
    return d


def torus_distance(a: np.ndarray, b: np.ndarray) -> float:
    return float(np.linalg.norm(torus_diff(a, b)))


def component_of_q(q: np.ndarray) -> str:
    q = np.asarray(q, dtype=float)
    q2 = float(wrap_to_pi(q[1]))
    if abs(q2) < 1e-6:
        return "switch"
    return "up" if q2 > 0.0 else "down"


def two_link_ik_solutions(robot, x: float, y: float):
    l1 = float(robot.l1)
    l2 = float(robot.l2)

    r2 = x * x + y * y
    cos_q2 = (r2 - l1 * l1 - l2 * l2) / (2.0 * l1 * l2)

    if cos_q2 < -1.0 - 1e-10 or cos_q2 > 1.0 + 1e-10:
        return []

    cos_q2 = np.clip(cos_q2, -1.0, 1.0)
    q2_candidates = [np.arccos(cos_q2), -np.arccos(cos_q2)]

    sols = []
    for q2 in q2_candidates:
        k1 = l1 + l2 * np.cos(q2)
        k2 = l2 * np.sin(q2)
        q1 = np.arctan2(y, x) - np.arctan2(k2, k1)

        q1 = wrap_to_pi(q1)
        q2 = wrap_to_pi(q2)
        q = np.array([q1, q2], dtype=float)

        duplicate = False
        for s in sols:
            if np.linalg.norm(torus_diff(q, s)) < 1e-8:
                duplicate = True
                break
        if not duplicate:
            sols.append(q)

    return sols


def component_ids_for_family(fam, lam: float):
    if fam.name == "switch_q2_family":
        return ["switch"]
    return ["up", "down"]


def compatible_components_for_leaf(fam, lam: float, q_transition: np.ndarray):
    q_comp = component_of_q(q_transition)

    if fam.name == "switch_q2_family":
        return ["switch"] if q_comp == "switch" else []

    if q_comp == "switch":
        return ["up", "down"]

    return [q_comp]


def allowed_family_pair(fam_a_name: str, fam_b_name: str) -> bool:
    allowed = {
        ("left_x_family", "switch_q2_family"),
        ("switch_q2_family", "left_x_family"),
        ("switch_q2_family", "bridge_y_family"),
        ("bridge_y_family", "switch_q2_family"),
        ("bridge_y_family", "right_x_family"),
        ("right_x_family", "bridge_y_family"),
    }
    return (fam_a_name, fam_b_name) in allowed


def make_seed_points_fn(robot: Planar2LinkKinematics):
    def seed_points_fn(fam_a, lam_a, fam_b, lam_b):
        seeds = []

        vals = np.linspace(-np.pi, np.pi, 9)
        for q1 in vals:
            for q2 in vals:
                seeds.append(np.array([q1, q2], dtype=float))

        def add_xy_ik_seeds(x_target: float, y_target: float):
            sols = two_link_ik_solutions(robot, x_target, y_target)
            eps = 0.05
            for q in sols:
                seeds.append(q.copy())
                seeds.append(q + np.array([eps, 0.0]))
                seeds.append(q + np.array([-eps, 0.0]))
                seeds.append(q + np.array([0.0, eps]))
                seeds.append(q + np.array([0.0, -eps]))

        def add_q2_zero_x_seeds(x_target: float):
            if abs(x_target / 2.0) <= 1.0 + 1e-10:
                c = np.clip(x_target / 2.0, -1.0, 1.0)
                q1a = np.arccos(c)
                q1b = -np.arccos(c)
                for q1 in [q1a, q1b]:
                    q = np.array([wrap_to_pi(q1), 0.0], dtype=float)
                    seeds.append(q.copy())
                    seeds.append(q + np.array([0.05, 0.02]))
                    seeds.append(q + np.array([-0.05, -0.02]))

        def add_q2_zero_y_seeds(y_target: float):
            if abs(y_target / 2.0) <= 1.0 + 1e-10:
                s = np.clip(y_target / 2.0, -1.0, 1.0)
                q1a = np.arcsin(s)
                q1b = np.pi - q1a
                for q1 in [q1a, q1b]:
                    q = np.array([wrap_to_pi(q1), 0.0], dtype=float)
                    seeds.append(q.copy())
                    seeds.append(q + np.array([0.05, 0.02]))
                    seeds.append(q + np.array([-0.05, -0.02]))

        if fam_a.name.endswith("x_family") and fam_b.name.endswith("y_family"):
            add_xy_ik_seeds(float(lam_a), float(lam_b))
        if fam_b.name.endswith("x_family") and fam_a.name.endswith("y_family"):
            add_xy_ik_seeds(float(lam_b), float(lam_a))

        if fam_a.name.endswith("x_family") and fam_b.name == "switch_q2_family":
            add_q2_zero_x_seeds(float(lam_a))
        if fam_b.name.endswith("x_family") and fam_a.name == "switch_q2_family":
            add_q2_zero_x_seeds(float(lam_b))

        if fam_a.name.endswith("y_family") and fam_b.name == "switch_q2_family":
            add_q2_zero_y_seeds(float(lam_a))
        if fam_b.name.endswith("y_family") and fam_a.name == "switch_q2_family":
            add_q2_zero_y_seeds(float(lam_b))

        uniq = []
        for s in seeds:
            s = wrap_q(s)
            if not any(np.linalg.norm(torus_diff(s, t)) < 1e-8 for t in uniq):
                uniq.append(s)

        return uniq

    return seed_points_fn


# ============================================================
# Example setup
# ============================================================

@dataclass
class BenchmarkCase:
    start_family_name: str
    start_lam: float
    start_q: np.ndarray
    goal_family_name: str
    goal_lam: float
    goal_q: np.ndarray
    title: str


def build_benchmark():
    robot = Planar2LinkKinematics(l1=1.0, l2=1.0)

    start_q = np.array([0.5 * np.pi, 0.5 * np.pi], dtype=float)
    goal_q = np.array([0.0, -0.5 * np.pi], dtype=float)

    families = [
        EndEffectorXFamily("left_x_family", robot, [-1.00]),
        Joint2Family("switch_q2_family", [0.0]),
        EndEffectorYFamily("bridge_y_family", robot, [-1.00]),
        EndEffectorXFamily("right_x_family", robot, [1.00]),
    ]

    case = BenchmarkCase(
        start_family_name="left_x_family",
        start_lam=-1.0,
        start_q=start_q,
        goal_family_name="right_x_family",
        goal_lam=1.0,
        goal_q=goal_q,
        title="Example 42: reusable component-aware framework with explicit switch connector",
    )
    return robot, families, case


# ============================================================
# Plot helpers
# ============================================================

def concatenate_steps(steps) -> np.ndarray:
    pts = []
    for i, step in enumerate(steps):
        path = np.asarray(step.path)
        if len(path) == 0:
            continue
        if i == 0:
            pts.extend(list(path))
        else:
            pts.extend(list(path[1:]))
    if not pts:
        return np.zeros((0, 2))
    return np.asarray(pts)


def total_path_length_from_steps(steps) -> float:
    total = 0.0
    for step in steps:
        path = np.asarray(step.path)
        if len(path) >= 2:
            total += float(np.sum(np.linalg.norm(np.diff(path, axis=0), axis=1)))
    return total


def summarize_component_route(route_edges, start_key):
    seq = [f"{start_key[0]}[{start_key[1]}|{start_key[2]}]"]
    for e in route_edges:
        fam, lam, comp = e.dst
        seq.append(f"{fam}[{lam}|{comp}]")
    return " -> ".join(seq)


def plot_jointspace_families(ax, robot, families):
    q1 = np.linspace(-np.pi, np.pi, 300)
    q2 = np.linspace(-np.pi, np.pi, 300)
    Q1, Q2 = np.meshgrid(q1, q2)

    X = robot.l1 * np.cos(Q1) + robot.l2 * np.cos(Q1 + Q2)
    Y = robot.l1 * np.sin(Q1) + robot.l2 * np.sin(Q1 + Q2)

    for fam in families:
        for lam in fam.sample_lambdas():
            if fam.name.endswith("x_family"):
                ax.contour(Q1, Q2, X, levels=[lam], linewidths=1.2, alpha=0.35)
            elif fam.name.endswith("y_family"):
                ax.contour(Q1, Q2, Y, levels=[lam], linewidths=1.2, alpha=0.35)
            elif fam.name == "switch_q2_family":
                ax.axhline(float(lam), linewidth=1.2, alpha=0.40)


def plot_workspace_path(ax, robot, q_path: np.ndarray, label: str):
    if len(q_path) == 0:
        return
    ee = np.asarray([robot.fk(q) for q in q_path])
    ax.plot(ee[:, 0], ee[:, 1], lw=2.5, label=label)


# ============================================================
# Main
# ============================================================

def main():
    np.random.seed(7)

    robot, families, case = build_benchmark()

    start_comp = component_of_q(case.start_q)
    goal_comp = component_of_q(case.goal_q)

    start_key = (case.start_family_name, case.start_lam, start_comp)
    goal_key = (case.goal_family_name, case.goal_lam, goal_comp)

    start_state = LeafState(
        family_name=case.start_family_name,
        lam=case.start_lam,
        x=case.start_q.copy(),
    )

    graph = build_component_leaf_graph(
        families=families,
        project_newton=project_newton,
        seed_points_fn=make_seed_points_fn(robot),
        goal_point=case.goal_q.copy(),
        component_ids_for_family_fn=component_ids_for_family,
        compatible_components_fn=compatible_components_for_leaf,
        allowed_family_pair_fn=allowed_family_pair,
        max_candidates_per_pair=6,
    )

    print(f"\n{case.title}")
    print(f"start q = {np.round(case.start_q, 4)}  comp={start_comp}")
    print(f"goal  q = {np.round(case.goal_q, 4)}  comp={goal_comp}")
    print(f"start EE = {np.round(robot.fk(case.start_q), 4)}")
    print(f"goal  EE = {np.round(robot.fk(case.goal_q), 4)}")
    print(f"start_key = {start_key}")
    print(f"goal_key  = {goal_key}")

    route = shortest_component_route(
        graph=graph,
        start=start_key,
        goal=goal_key,
    )

    if route is None:
        print("\nNo reusable component-aware route found.")
        return

    print("\nSelected reusable component-aware route:")
    print("  " + summarize_component_route(route, start_key))

    print("\nNominal route edges:")
    for i, e in enumerate(route):
        print(
            f"  edge {i}: {e.src} -> {e.dst}, "
            f"cand={e.candidate_index}, "
            f"q_transition={np.round(e.transition_point, 4)}, "
            f"score={e.score:.4f}, "
            f"EE={np.round(robot.fk(e.transition_point), 4)}, "
            f"q_comp={component_of_q(e.transition_point)}"
        )

    realized = realize_component_route(
        graph=graph,
        start_state=start_state,
        start_component=start_comp,
        goal_q=case.goal_q.copy(),
        families=families,
        route_edges=route,
        step_size=0.08,
        local_planner_name="projection",
        local_planner_kwargs=dict(
            goal_tol=1e-3,
            max_iters=1200,
            projection_tol=1e-10,
            projection_max_iters=50,
            projection_damping=1.0,
        ),
        wrap_state_fn=wrap_q,
        state_distance_fn=torus_distance,
    )

    print("\nRealization result:")
    print(f"  success      : {realized.success}")
    print(f"  message      : {realized.message}")
    print(f"  path length  : {total_path_length_from_steps(realized.steps):.4f}")
    for i, step in enumerate(realized.steps):
        print(
            f"  step {i}: family={step.family_name}[{step.lam}|{step.component_id}], "
            f"transition={None if step.transition_point is None else np.round(step.transition_point, 4)}, "
            f"msg={step.message}"
        )

    q_path = concatenate_steps(realized.steps)

    fig, axes = plt.subplots(1, 2, figsize=(14, 6))

    ax = axes[0]
    plot_jointspace_families(ax, robot, families)
    if len(q_path) > 0:
        ax.plot(q_path[:, 0], q_path[:, 1], lw=3.0, label="joint-space path")
    for i, step in enumerate(realized.steps[:-1]):
        if step.transition_point is not None:
            ax.scatter(
                step.transition_point[0],
                step.transition_point[1],
                s=70,
                zorder=5,
                label="used exact transition" if i == 0 else None,
            )
    ax.scatter(case.start_q[0], case.start_q[1], s=90, marker="s", color="black", label="start")
    ax.scatter(case.goal_q[0], case.goal_q[1], s=120, marker="*", color="gold", edgecolor="black", label="goal")
    ax.set_title("Reusable component-aware planning in joint space")
    ax.set_xlabel("q1 [rad]")
    ax.set_ylabel("q2 [rad]")
    ax.set_xlim([-np.pi, np.pi])
    ax.set_ylim([-np.pi, np.pi])
    ax.grid(True, alpha=0.25)
    ax.legend()

    ax = axes[1]
    plot_workspace_path(ax, robot, q_path, label="end-effector path")
    ax.scatter(*robot.fk(case.start_q), s=90, marker="s", color="black", label="start EE")
    ax.scatter(*robot.fk(case.goal_q), s=120, marker="*", color="gold", edgecolor="black", label="goal EE")
    ax.set_title("Workspace interpretation")
    ax.set_xlabel("x")
    ax.set_ylabel("y")
    ax.set_aspect("equal")
    ax.grid(True, alpha=0.25)
    ax.legend()

    plt.tight_layout()
    plt.show()


if __name__ == "__main__":
    main()