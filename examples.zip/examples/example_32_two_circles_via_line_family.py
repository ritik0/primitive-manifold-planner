from __future__ import annotations

from dataclasses import dataclass
from typing import List, Dict
import numpy as np
import matplotlib.pyplot as plt

from primitive_manifold_planner.families.leaf_state import LeafState
from primitive_manifold_planner.manifolds import (
    LineManifold,
    CircleManifold,
)
from primitive_manifold_planner.planners.plan_foliated_route import plan_foliated_route
from primitive_manifold_planner.projection import project_newton
from primitive_manifold_planner.planners.leaf_graph_plot import plot_leaf_graph_from_routes


# ============================================================
# Thin benchmark family wrappers
# ============================================================

class BenchmarkLeafFamily:
    def __init__(self, name: str, lambdas: List[float]):
        self.name = name
        self._lambdas = [float(l) for l in lambdas]

    def manifold(self, lam: float):
        raise NotImplementedError

    def sample_lambdas(self, context=None):
        return list(self._lambdas)


class CircleFamilyAdapter(BenchmarkLeafFamily):
    """
    Family where lambda selects the radius of a circle centered at a fixed point.
    """
    def __init__(self, name: str, center: np.ndarray, lambdas: List[float]):
        super().__init__(name=name, lambdas=lambdas)
        self.center = np.asarray(center, dtype=float)

    def manifold(self, lam: float):
        return CircleManifold(
            center=self.center.copy(),
            radius=float(lam),
            name=f"{self.name}_lambda_{lam:g}",
        )


class HorizontalLineFamily(BenchmarkLeafFamily):
    """
    Line family: y = lambda
    """
    def manifold(self, lam: float):
        return LineManifold(
            point=np.array([0.0, float(lam)]),
            normal=np.array([0.0, 1.0]),
            name=f"{self.name}_lambda_{lam:g}",
        )


# ============================================================
# Benchmark case
# ============================================================

@dataclass
class BenchmarkCase:
    start_family_name: str
    start_lam: float
    start_point: np.ndarray
    goal_family_name: str
    goal_lam: float
    goal_point: np.ndarray
    title: str


def build_benchmark():
    """
    Two non-intersecting circle families connected only through a family of lines.

    Geometry idea:
    - left circle family centered at (-2.0, 0.0)
    - right circle family centered at (+2.0, 0.0)
    - line family y = lambda

    With these centers and radii, the circles do not intersect each other,
    but several horizontal lines can intersect each circle, so the line family
    acts as the multimodal bridge.
    """
    families = [
        CircleFamilyAdapter(
            name="left_circle_family",
            center=np.array([-2.0, 0.0]),
            lambdas=[1.00, 1.20, 1.40],
        ),
        HorizontalLineFamily(
            name="bridge_line_family",
            lambdas=[-0.80, -0.40, 0.00, 0.40, 0.80],
        ),
        CircleFamilyAdapter(
            name="right_circle_family",
            center=np.array([2.0, 0.0]),
            lambdas=[1.00, 1.20, 1.40],
        ),
    ]

    cases = [
        BenchmarkCase(
            start_family_name="left_circle_family",
            start_lam=1.20,
            start_point=np.array([-3.20, 0.00]),   # leftmost point of circle radius 1.2
            goal_family_name="right_circle_family",
            goal_lam=1.20,
            goal_point=np.array([3.20, 0.00]),     # rightmost point of circle radius 1.2
            title="Case 0: symmetric circles bridged by line family",
        ),
        BenchmarkCase(
            start_family_name="left_circle_family",
            start_lam=1.40,
            start_point=np.array([-2.0, 1.40]),    # top of left circle
            goal_family_name="right_circle_family",
            goal_lam=1.00,
            goal_point=np.array([2.0, -1.00]),     # bottom of right circle
            title="Case 1: top-to-bottom via line bridge",
        ),
    ]

    # Force only circle -> line -> circle transitions.
    allowed_family_transitions = {
        "left_circle_family": ["bridge_line_family"],
        "bridge_line_family": ["right_circle_family"],
        "right_circle_family": [],
    }

    return families, cases, allowed_family_transitions


# ============================================================
# Helpers
# ============================================================

def get_family_map(families):
    return {f.name: f for f in families}


def plot_manifold(ax, manifold, color="lightgray", lw=1.2, alpha=0.30):
    if isinstance(manifold, LineManifold):
        p = manifold.point
        n = manifold.normal
        t = np.array([-n[1], n[0]], dtype=float)
        s = np.linspace(-6.0, 6.0, 400)
        pts = p[None, :] + s[:, None] * t[None, :]
        ax.plot(pts[:, 0], pts[:, 1], color=color, lw=lw, alpha=alpha)

    elif isinstance(manifold, CircleManifold):
        th = np.linspace(0.0, 2.0 * np.pi, 400)
        pts = np.column_stack([
            manifold.center[0] + manifold.radius * np.cos(th),
            manifold.center[1] + manifold.radius * np.sin(th),
        ])
        ax.plot(pts[:, 0], pts[:, 1], color=color, lw=lw, alpha=alpha)


def plot_all_families(ax, families):
    for fam in families:
        for lam in fam.sample_lambdas():
            plot_manifold(ax, fam.manifold(lam))


def concatenate_steps(steps) -> np.ndarray:
    pts = []
    for i, step in enumerate(steps):
        path = np.asarray(step.path)
        if len(path) == 0:
            continue
        if i == 0:
            pts.extend(list(path))
        else:
            pts.extend(list(path[1:]))
    if not pts:
        return np.zeros((0, 2))
    return np.asarray(pts)


def total_path_length_from_steps(steps) -> float:
    total = 0.0
    for step in steps:
        path = np.asarray(step.path)
        if len(path) >= 2:
            total += float(np.sum(np.linalg.norm(np.diff(path, axis=0), axis=1)))
    return total


def print_plan_summary(label: str, result):
    print(f"\n=== {label} ===")
    print(f"success      : {result.success}")
    print(f"message      : {result.message}")
    print(f"num steps    : {len(result.steps)}")
    print(f"path length  : {total_path_length_from_steps(result.steps):.4f}")

    for i, step in enumerate(result.steps):
        step_path = np.asarray(step.path)
        path_len = 0.0
        if len(step_path) >= 2:
            path_len = float(np.sum(np.linalg.norm(np.diff(step_path, axis=0), axis=1)))
        print(
            f"  step {i:02d} | kind={step.kind:>6s} | "
            f"family={step.family_name}[{step.lam}] | "
            f"planner={getattr(step, 'planner_name', 'unknown')} | "
            f"charts={getattr(step, 'chart_count', 0)} | "
            f"len={path_len:.4f}"
        )


def summarize_leaf_sequence(result):
    seq = []
    for step in result.steps:
        fam_lam = f"{step.family_name}[{step.lam}]"
        if not seq or seq[-1] != fam_lam:
            seq.append(fam_lam)
    return " -> ".join(seq)


def route_nodes_from_result(result):
    nodes = []
    for step in result.steps:
        node = (step.family_name, step.lam)
        if not nodes or nodes[-1] != node:
            nodes.append(node)
    return nodes


def build_leaf_graph_for_plot(families, allowed_family_transitions):
    nodes = []
    fam_to_lams = {}

    for fam in families:
        lams = list(fam.sample_lambdas())
        fam_to_lams[fam.name] = lams
        for lam in lams:
            nodes.append((fam.name, lam))

    edges = []
    edge_labels = {}

    for src_family, dst_families in allowed_family_transitions.items():
        src_lams = fam_to_lams.get(src_family, [])
        for dst_family in dst_families:
            dst_lams = fam_to_lams.get(dst_family, [])
            for lam_a in src_lams:
                for lam_b in dst_lams:
                    a = (src_family, lam_a)
                    b = (dst_family, lam_b)
                    edges.append((a, b))
                    key = (a, b) if str(a) <= str(b) else (b, a)
                    edge_labels[key] = ""

    return nodes, edges, edge_labels


# ============================================================
# Main
# ============================================================

def main():
    np.random.seed(7)

    families, cases, allowed_family_transitions = build_benchmark()
    family_map = get_family_map(families)

    # Change this to 0 or 1
    case_id = 1
    case = cases[case_id]

    start_state = LeafState(
        family_name=case.start_family_name,
        lam=case.start_lam,
        x=case.start_point.copy(),
    )
    goal_family = family_map[case.goal_family_name]
    goal_lam = case.goal_lam
    goal_point = case.goal_point.copy()

    result = plan_foliated_route(
        start_state=start_state,
        goal_point=goal_point,
        goal_family=goal_family,
        goal_lam=goal_lam,
        families=families,
        project_newton=project_newton,
        max_switches=3,
        local_step_size=0.08,
        progress_tol=1e-4,
        local_planner_name="projection",
        local_planner_kwargs=dict(
            goal_tol=1e-3,
            max_iters=500,
            projection_tol=1e-10,
            projection_max_iters=50,
            projection_damping=1.0,
        ),
        allowed_family_transitions=allowed_family_transitions,
        goal_leaf_mismatch_penalty=10.0,
    )

    print(f"\nRunning {case.title}")
    print(f"start = {case.start_family_name}[{case.start_lam}] at {case.start_point}")
    print(f"goal  = {case.goal_family_name}[{case.goal_lam}] at {case.goal_point}")
    print(f"allowed transitions = {allowed_family_transitions}")

    print_plan_summary("Projection multimodal route", result)
    print(f"leaf sequence : {summarize_leaf_sequence(result)}")

    route_nodes = route_nodes_from_result(result)
    graph_nodes, graph_edges, edge_labels = build_leaf_graph_for_plot(
        families=families,
        allowed_family_transitions=allowed_family_transitions,
    )

    # Workspace plot
    fig, ax = plt.subplots(figsize=(10, 7))
    plot_all_families(ax, families)

    pts = concatenate_steps(result.steps)
    if len(pts) > 0:
        ax.plot(
            pts[:, 0],
            pts[:, 1],
            color="tab:red",
            lw=3.0,
            label="realized route",
        )

    ax.scatter(case.start_point[0], case.start_point[1], s=90, marker="s", color="black", label="start")
    ax.scatter(case.goal_point[0], case.goal_point[1], s=140, marker="*", color="gold", edgecolor="black", label="goal")

    ax.set_title(f"Example 32: two circles connected via line family\n{case.title}")
    ax.set_aspect("equal")
    ax.grid(True, alpha=0.25)
    ax.legend()
    plt.tight_layout()
    plt.show()

    # Leaf graph plot
    plot_leaf_graph_from_routes(
        nodes=graph_nodes,
        edges=graph_edges,
        primary_route=route_nodes,
        secondary_route=None,
        edge_labels=edge_labels,
        title="Leaf graph: circle A -> line family -> circle B",
        primary_label="selected route",
        secondary_label="",
    )
    plt.show()


if __name__ == "__main__":
    main()