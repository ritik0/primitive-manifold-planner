from __future__ import annotations

import numpy as np
import matplotlib.pyplot as plt

from primitive_manifold_planner.manifolds import CircleManifold
from primitive_manifold_planner.planning import build_mode_graph, plan_multimodal_route
from primitive_manifold_planner.visualization import (
    finalize_2d_axes,
    plot_circle_manifold,
    plot_path_2d,
    plot_start_goal,
    plot_transition_candidates_2d,
)


def main() -> None:
    # ------------------------------------------------------------
    # Define two intersecting circle modes
    # ------------------------------------------------------------
    circle_a = CircleManifold(center=np.array([0.0, 0.0]), radius=2.0, name="circle_a")
    circle_b = CircleManifold(center=np.array([2.0, 0.0]), radius=2.0, name="circle_b")

    manifolds = {
        "circle_a": circle_a,
        "circle_b": circle_b,
    }

    # Try changing the goal to [1.0,  1.73205081] or [1.0, -1.73205081]
    # to see context-aware transition selection switch between candidates.
    start_point = np.array([-2.0, 0.0])
    goal_point = np.array([2.0, 2.0])

    # ------------------------------------------------------------
    # Build mode graph
    # ------------------------------------------------------------
    rng = np.random.default_rng(42)
    graph, diagnostics = build_mode_graph(
        manifolds=manifolds,
        bounds_min=np.array([-3.0, -3.0]),
        bounds_max=np.array([5.0, 3.0]),
        num_seeds=100,
        tol=1e-8,
        rng=rng,
    )

    print("=== Mode graph ===")
    print(graph)
    print(f"Nodes: {list(graph.nodes.keys())}")
    print(f"Edges: {len(graph.edges)}")

    for pair, diag in diagnostics.items():
        print(f"\nPair {pair}")
        print(f"  success           : {diag.success}")
        print(f"  message           : {diag.message}")
        print(f"  # candidates      : {len(diag.candidates)}")
        if diag.best_candidate is not None:
            print(f"  best point        : {diag.best_candidate.point}")
            print(f"  best residual     : {diag.best_candidate.residual_norm:.3e}")
            print(f"  best score        : {diag.best_candidate.score:.6f}")

        for i, cand in enumerate(diag.candidates):
            print(f"    candidate {i}: point={cand.point}, residual={cand.residual_norm:.3e}, score={cand.score:.6f}")

    # ------------------------------------------------------------
    # Plan full multimodal route
    # ------------------------------------------------------------
    result = plan_multimodal_route(
        graph=graph,
        start_mode="circle_a",
        goal_mode="circle_b",
        start_point=start_point,
        goal_point=goal_point,
        step_size=0.15,
        goal_tol=5e-2,
        max_iters=800,
    )

    print("\n=== Multimodal plan result ===")
    print(f"Success        : {result.success}")
    print(f"Message        : {result.message}")

    selected_transition = None
    if result.route is not None:
        print(f"Mode sequence  : {result.route.mode_sequence}")
        print(f"# transitions  : {len(result.route.transition_steps)}")

        for i, step in enumerate(result.route.transition_steps):
            print(f"\n  Transition {i + 1}")
            print(f"    from       : {step.from_mode}")
            print(f"    to         : {step.to_mode}")
            print(f"    point      : {step.transition_point}")
            print(f"    residual   : {step.residual_norm:.3e}")
            selected_transition = step.transition_point

    print(f"\n# segments     : {len(result.segment_plans)}")
    for i, seg in enumerate(result.segment_plans):
        print(f"\n  Segment {i + 1}")
        print(f"    mode       : {seg.mode_name}")
        print(f"    success    : {seg.success}")
        print(f"    message    : {seg.message}")
        print(f"    start      : {seg.start_point}")
        print(f"    end        : {seg.end_point}")
        print(f"    path shape : {seg.path.shape}")

    # ------------------------------------------------------------
    # Plot
    # ------------------------------------------------------------
    fig, ax = plt.subplots(figsize=(8, 7))

    plot_circle_manifold(ax, circle_a, label="circle_a")
    plot_circle_manifold(ax, circle_b, label="circle_b")
    plot_start_goal(ax, start_point, goal_point)

    edge = graph.get_edge("circle_a", "circle_b")
    if edge is not None:
        plot_transition_candidates_2d(
            ax,
            edge.transition_candidates,
            selected_point=selected_transition,
            annotate=True,
        )

    if result.full_path is not None:
        plot_path_2d(ax, result.full_path, show_points=True, label="full multimodal path")

    finalize_2d_axes(ax, title="Two-circle multimodal planning with transition diagnostics")
    plt.show()


if __name__ == "__main__":
    main()