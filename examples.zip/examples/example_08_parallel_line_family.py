from __future__ import annotations

import numpy as np
import matplotlib
matplotlib.use("TkAgg")
import matplotlib.pyplot as plt

from primitive_manifold_planner.manifolds import ParallelLineFamily
from primitive_manifold_planner.visualization import finalize_2d_axes


def main() -> None:
    family = ParallelLineFamily(name="horizontal_lines")
    lambdas = family.sample_lambdas(-2.0, 2.0, 5)

    print("=== Parallel line family ===")
    print("Sampled lambdas:", lambdas)

    fig, ax = plt.subplots(figsize=(8, 6))

    xs = np.linspace(-4.0, 4.0, 200)

    for lam in lambdas:
        ys = np.full_like(xs, lam)
        leaf = family.leaf(lam)
        ax.plot(xs, ys, label=leaf.name)

    ax.scatter([0.0], [1.0], s=80, label="example point")
    finalize_2d_axes(ax, title="Parallel line family: first leaf-family benchmark")
    plt.show(block=True)


if __name__ == "__main__":
    main()