from __future__ import annotations

from dataclasses import dataclass
from typing import List, Dict, Tuple
import math
import numpy as np
import matplotlib.pyplot as plt

from primitive_manifold_planner.families.leaf_state import LeafState
from primitive_manifold_planner.manifolds import (
    CircleManifold,
    LineManifold,
)
from primitive_manifold_planner.planners.leaf_graph import (
    build_leaf_graph,
    shortest_leaf_route,
)
from primitive_manifold_planner.planners.realize_leaf_route import realize_leaf_route
from primitive_manifold_planner.planners.leaf_graph_plot import plot_leaf_graph
from primitive_manifold_planner.projection import project_newton


# ============================================================
# Thin benchmark family wrappers
# ============================================================

class BenchmarkLeafFamily:
    def __init__(self, name: str, lambdas: List[float]):
        self.name = name
        self._lambdas = [float(l) for l in lambdas]

    def manifold(self, lam: float):
        raise NotImplementedError

    def sample_lambdas(self, context=None):
        return list(self._lambdas)

    def lambda_distance(self, lam_a, lam_b) -> float:
        return abs(float(lam_a) - float(lam_b))


class CircleFamilyAdapter(BenchmarkLeafFamily):
    """
    Family where lambda selects the radius of a circle centered at a fixed point.
    """
    def __init__(self, name: str, center: np.ndarray, lambdas: List[float]):
        super().__init__(name=name, lambdas=lambdas)
        self.center = np.asarray(center, dtype=float)

    def manifold(self, lam: float):
        return CircleManifold(
            center=self.center.copy(),
            radius=float(lam),
            name=f"{self.name}_lambda_{lam:g}",
        )


class HorizontalLineFamily(BenchmarkLeafFamily):
    """
    Line family: y = lambda
    """
    def manifold(self, lam: float):
        return LineManifold(
            point=np.array([0.0, float(lam)]),
            normal=np.array([0.0, 1.0]),
            name=f"{self.name}_lambda_{lam:g}",
        )


# ============================================================
# Benchmark case
# ============================================================

@dataclass
class BenchmarkCase:
    start_family_name: str
    start_lam: float
    start_point: np.ndarray
    goal_family_name: str
    goal_lam: float
    goal_point: np.ndarray
    title: str


def build_benchmark():
    """
    Two non-intersecting circle leaves connected only via a horizontal line family.

    Geometry:
      - left circle center  = (-2, 0)
      - right circle center = (+2, 0)
      - maximum radius used = 1.4

    Since center distance is 4.0 and radius sum is at most 2.4 or 2.8 depending on pair,
    the chosen start and goal leaves do not intersect each other.
    """
    families = [
        CircleFamilyAdapter(
            name="left_circle_family",
            center=np.array([-2.0, 0.0]),
            lambdas=[1.00, 1.20, 1.40],
        ),
        HorizontalLineFamily(
            name="bridge_line_family",
            lambdas=[-0.80, -0.40, 0.00, 0.40, 0.80],
        ),
        CircleFamilyAdapter(
            name="right_circle_family",
            center=np.array([2.0, 0.0]),
            lambdas=[1.00, 1.20, 1.40],
        ),
    ]

    cases = [
        BenchmarkCase(
            start_family_name="left_circle_family",
            start_lam=1.40,
            start_point=np.array([-2.0, 1.40]),   # top of left circle
            goal_family_name="right_circle_family",
            goal_lam=1.00,
            goal_point=np.array([2.0, 1.00]),     # top of right circle
            title="Case 0: top-to-top via line-family bridge",
        ),
        BenchmarkCase(
            start_family_name="left_circle_family",
            start_lam=1.40,
            start_point=np.array([-2.0, 1.40]),   # top of left circle
            goal_family_name="right_circle_family",
            goal_lam=1.00,
            goal_point=np.array([2.0, -1.00]),    # bottom of right circle
            title="Case 1: top-to-bottom via line-family bridge",
        ),
    ]

    return families, cases


# ============================================================
# Graph-building helpers
# ============================================================

def get_family_map(families):
    return {f.name: f for f in families}


def allowed_family_pair(fam_a_name: str, fam_b_name: str) -> bool:
    """
    Only allow circle <-> line and line <-> circle transitions.
    Explicitly disallow direct circle <-> circle transitions.
    """
    allowed = {
        ("left_circle_family", "bridge_line_family"),
        ("bridge_line_family", "left_circle_family"),
        ("bridge_line_family", "right_circle_family"),
        ("right_circle_family", "bridge_line_family"),
    }
    return (fam_a_name, fam_b_name) in allowed


def seed_points_fn(fam_a, lam_a, fam_b, lam_b):
    """
    Good seeds for circle-line intersections.

    For circle/line pairs, seed around the analytic intersection locations:
        (x-cx)^2 + (y-cy)^2 = r^2
        y = lambda
    """
    seeds = []

    # generic fallback seeds
    seeds.extend([
        np.array([0.0, 0.0], dtype=float),
        np.array([1.0, 0.0], dtype=float),
        np.array([-1.0, 0.0], dtype=float),
        np.array([0.0, 1.0], dtype=float),
        np.array([0.0, -1.0], dtype=float),
    ])

    def add_circle_line_seeds(circle_family, radius, line_family, line_y):
        cx, cy = circle_family.center
        r = float(radius)
        y = float(line_y)
        dy = y - cy

        # if the line can intersect the circle, seed near exact intersections
        if abs(dy) <= r + 1e-12:
            dx_sq = max(r * r - dy * dy, 0.0)
            dx = math.sqrt(dx_sq)

            seeds.append(np.array([cx - dx, y], dtype=float))
            seeds.append(np.array([cx + dx, y], dtype=float))

            # small perturbations around the exact intersections
            eps = 0.05
            seeds.append(np.array([cx - dx - eps, y], dtype=float))
            seeds.append(np.array([cx - dx + eps, y], dtype=float))
            seeds.append(np.array([cx + dx - eps, y], dtype=float))
            seeds.append(np.array([cx + dx + eps, y], dtype=float))

        # also seed directly below/above the circle center on the target line
        seeds.append(np.array([cx, y], dtype=float))

    if fam_a.name.endswith("circle_family") and fam_b.name == "bridge_line_family":
        add_circle_line_seeds(fam_a, lam_a, fam_b, lam_b)

    if fam_b.name.endswith("circle_family") and fam_a.name == "bridge_line_family":
        add_circle_line_seeds(fam_b, lam_b, fam_a, lam_a)

    # remove duplicates approximately
    uniq = []
    for s in seeds:
        if not any(np.linalg.norm(s - t) < 1e-8 for t in uniq):
            uniq.append(s)

    return uniq


def build_restricted_leaf_graph(families, goal_point):
    """
    Build a leaf graph while only keeping allowed family-pair transitions.
    """
    full_graph = build_leaf_graph(
        families=families,
        project_newton=project_newton,
        seed_points_fn=seed_points_fn,
        goal_point=goal_point,
        max_candidates_per_pair=2,
    )

    # Filter out disallowed family-family edges
    filtered_adjacency = {}
    for src, edges in full_graph.adjacency.items():
        kept = []
        for e in edges:
            if allowed_family_pair(e.src[0], e.dst[0]):
                kept.append(e)
        filtered_adjacency[src] = kept

    full_graph.adjacency = filtered_adjacency
    return full_graph


def edge_cost_fn(edge):
    """
    Slightly prefer lower-score transitions and keep switch cost simple.
    """
    return 1.0 + edge.score


# ============================================================
# Plot helpers
# ============================================================

def plot_manifold(ax, manifold, color="lightgray", lw=1.2, alpha=0.30):
    if isinstance(manifold, LineManifold):
        p = manifold.point
        n = manifold.normal
        t = np.array([-n[1], n[0]], dtype=float)
        s = np.linspace(-6.0, 6.0, 400)
        pts = p[None, :] + s[:, None] * t[None, :]
        ax.plot(pts[:, 0], pts[:, 1], color=color, lw=lw, alpha=alpha)

    elif isinstance(manifold, CircleManifold):
        th = np.linspace(0.0, 2.0 * np.pi, 400)
        pts = np.column_stack([
            manifold.center[0] + manifold.radius * np.cos(th),
            manifold.center[1] + manifold.radius * np.sin(th),
        ])
        ax.plot(pts[:, 0], pts[:, 1], color=color, lw=lw, alpha=alpha)


def plot_all_families(ax, families):
    for fam in families:
        for lam in fam.sample_lambdas():
            plot_manifold(ax, fam.manifold(lam))


def concatenate_steps(steps) -> np.ndarray:
    pts = []
    for i, step in enumerate(steps):
        path = np.asarray(step.path)
        if len(path) == 0:
            continue
        if i == 0:
            pts.extend(list(path))
        else:
            pts.extend(list(path[1:]))
    if not pts:
        return np.zeros((0, 2))
    return np.asarray(pts)


def total_path_length_from_steps(steps) -> float:
    total = 0.0
    for step in steps:
        path = np.asarray(step.path)
        if len(path) >= 2:
            total += float(np.sum(np.linalg.norm(np.diff(path, axis=0), axis=1)))
    return total


def summarize_leaf_sequence(route_edges, start_key):
    seq = [f"{start_key[0]}[{start_key[1]}]"]
    for e in route_edges:
        seq.append(f"{e.dst[0]}[{e.dst[1]}]")
    return " -> ".join(seq)


# ============================================================
# Main
# ============================================================

def main():
    np.random.seed(7)

    families, cases = build_benchmark()
    family_map = get_family_map(families)

    # Change this to 0 or 1
    case_id = 0
    case = cases[case_id]

    start_key = (case.start_family_name, case.start_lam)
    goal_key = (case.goal_family_name, case.goal_lam)

    start_state = LeafState(
        family_name=case.start_family_name,
        lam=case.start_lam,
        x=case.start_point.copy(),
    )
    goal_family = family_map[case.goal_family_name]
    goal_lam = case.goal_lam
    goal_point = case.goal_point.copy()

    graph = build_restricted_leaf_graph(
        families=families,
        goal_point=goal_point,
    )

    route = shortest_leaf_route(
        graph=graph,
        start=start_key,
        goal=goal_key,
        edge_cost_fn=edge_cost_fn,
    )

    print(f"\nRunning {case.title}")
    print(f"start = {case.start_family_name}[{case.start_lam}] at {case.start_point}")
    print(f"goal  = {case.goal_family_name}[{case.goal_lam}] at {case.goal_point}")

    if route is None:
        print("\nNo route found in the leaf graph.")
        plot_leaf_graph(graph, route=None, title="Example 33 leaf graph (no route found)")
        plt.show()
        return

    print("\nSelected leaf route:")
    print("  " + summarize_leaf_sequence(route, start_key))

    print("\nSelected transition edges:")
    for i, e in enumerate(route):
        print(
            f"  edge {i}: {e.src} -> {e.dst}, "
            f"cand={e.candidate_index}, "
            f"transition={np.round(e.transition_point, 4)}, "
            f"score={e.score:.4f}"
        )

    realized = realize_leaf_route(
        start_state=start_state,
        goal_point=goal_point,
        goal_family=goal_family,
        goal_lam=goal_lam,
        families=families,
        route_edges=route,
        step_size=0.08,
        local_planner_name="projection",
        local_planner_kwargs=dict(
            goal_tol=1e-3,
            max_iters=500,
            projection_tol=1e-10,
            projection_max_iters=50,
            projection_damping=1.0,
        ),
    )

    print("\nRealization result:")
    print(f"  success     : {realized.success}")
    print(f"  message     : {realized.message}")
    print(f"  total length: {total_path_length_from_steps(realized.steps):.4f}")

    for i, step in enumerate(realized.steps):
        path = np.asarray(step.path)
        seg_len = 0.0
        if len(path) >= 2:
            seg_len = float(np.sum(np.linalg.norm(np.diff(path, axis=0), axis=1)))
        print(
            f"  step {i}: family={step.family_name}[{step.lam}], "
            f"len={seg_len:.4f}, transition={None if step.transition_point is None else np.round(step.transition_point, 4)}"
        )

    # Workspace plot
    fig, ax = plt.subplots(figsize=(10, 7))
    plot_all_families(ax, families)

    pts = concatenate_steps(realized.steps)
    if len(pts) > 0:
        ax.plot(
            pts[:, 0],
            pts[:, 1],
            color="tab:red",
            lw=3.0,
            label="realized route",
        )

    # transition markers
    for e in route:
        ax.scatter(
            e.transition_point[0],
            e.transition_point[1],
            s=55,
            marker="o",
            color="tab:blue",
            edgecolor="black",
            zorder=5,
        )

    ax.scatter(case.start_point[0], case.start_point[1], s=90, marker="s", color="black", label="start")
    ax.scatter(case.goal_point[0], case.goal_point[1], s=140, marker="*", color="gold", edgecolor="black", label="goal")

    ax.set_title(f"Example 33: circle A -> line-family bridge -> circle B\n{case.title}")
    ax.set_aspect("equal")
    ax.grid(True, alpha=0.25)
    ax.legend()
    plt.tight_layout()
    plt.show()

    # Leaf graph plot
    plot_leaf_graph(
        graph,
        route=route,
        title="Leaf graph: selected bridge-line leaf highlighted",
    )
    plt.show()


if __name__ == "__main__":
    main()