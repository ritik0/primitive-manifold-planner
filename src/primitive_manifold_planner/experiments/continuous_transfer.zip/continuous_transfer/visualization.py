"""PyVista visualization helpers for the staged continuous-transfer experiment."""

from __future__ import annotations

import numpy as np

from primitive_manifold_planner.visualization import add_manifold, add_points, pyvista_available

from .family_definition import build_continuous_scene, obstacle_patch_on_leaf, plane_leaf_patch
from .graph_types import ContinuousTransferRoute
from .support import build_segment_polydata

try:
    import pyvista as pv
except Exception:
    pv = None


def show_continuous_route(result: ContinuousTransferRoute) -> bool:
    if not pyvista_available() or pv is None:
        print("PyVista is not available in this environment.")
        return False

    left_family, transfer_family, right_family, start_q, goal_q = build_continuous_scene(
        obstacle_profile=result.scene_profile
    )
    left_manifold = left_family.manifold(float(left_family.sample_lambdas()[0]))
    right_manifold = right_family.manifold(float(right_family.sample_lambdas()[0]))
    plotter = pv.Plotter(window_size=(1380, 860))
    plotter.add_text("Example 65: parallel family evidence under fixed left -> family -> right sequence", font_size=12)
    actor_groups = {
        "Supports": [],
        "FamilyLeaves": [],
        "Obstacles": [],
        "LeftStage": [],
        "FamilyLeaf": [],
        "FamilyTransverse": [],
        "RightStage": [],
        "Clusters": [],
        "Seeds": [],
        "Path": [],
        "Invalid": [],
        "StartGoal": [],
    }

    actor = add_manifold(plotter, left_manifold, color="#c58b4c", opacity=0.11, label="left support sphere")
    if actor is not None:
        actor_groups["Supports"].append(actor)
    actor = add_manifold(plotter, right_manifold, color="#c58b4c", opacity=0.11, label="right support sphere")
    if actor is not None:
        actor_groups["Supports"].append(actor)

    leaf_lambdas = np.asarray(result.explored_lambda_values, dtype=float)
    if len(leaf_lambdas) > 12:
        ids = np.linspace(0, len(leaf_lambdas) - 1, 12, dtype=int)
        leaf_lambdas = leaf_lambdas[ids]
    for idx, lam in enumerate(leaf_lambdas):
        corners = plane_leaf_patch(transfer_family, lam)
        faces = np.hstack([[4, 0, 1, 2, 3]])
        patch = pv.PolyData(corners, faces)
        actor = plotter.add_mesh(
            patch,
            color="#90caf9",
            opacity=0.08,
            show_edges=False,
            smooth_shading=False,
            label="explored family leaves" if idx == 0 else None,
        )
        if actor is not None:
            actor_groups["FamilyLeaves"].append(actor)
    if result.primary_entry_lambda is not None:
        primary_corners = plane_leaf_patch(transfer_family, float(result.primary_entry_lambda))
        primary_faces = np.hstack([[4, 0, 1, 2, 3]])
        primary_patch = pv.PolyData(primary_corners, primary_faces)
        actor = plotter.add_mesh(
            primary_patch,
            color="#29b6f6",
            opacity=0.16,
            show_edges=True,
            line_width=1.2,
            label="primary entry leaf",
        )
        if actor is not None:
            actor_groups["FamilyLeaves"].append(actor)
    if len(transfer_family.obstacles) > 0:
        for obstacle_idx, obstacle in enumerate(transfer_family.obstacles):
            lam = float(0.5 * (obstacle.lambda_min + obstacle.lambda_max))
            corners = obstacle_patch_on_leaf(transfer_family, obstacle, lam)
            faces = np.hstack([[4, 0, 1, 2, 3]])
            patch = pv.PolyData(corners, faces)
            actor = plotter.add_mesh(
                patch,
                color="#ef5350",
                opacity=0.24,
                show_edges=True,
                line_width=1.2,
                label="family obstacle" if obstacle_idx == 0 else None,
            )
            if actor is not None:
                actor_groups["Obstacles"].append(actor)

    colors_by_mode = {
        "left": "#81c784",
        "family_leaf": "#4fc3f7",
        "family_transverse": "#7e57c2",
        "right": "#81c784",
    }
    for mode, edges in result.explored_edges_by_mode.items():
        graph = build_segment_polydata(edges)
        if graph is None:
            continue
        actor = plotter.add_mesh(graph, color=colors_by_mode.get(mode, "#90a4ae"), line_width=2.2, opacity=0.40)
        if actor is not None:
            if mode == "left":
                actor_groups["LeftStage"].append(actor)
            elif mode == "family_leaf":
                actor_groups["FamilyLeaf"].append(actor)
            elif mode == "family_transverse":
                actor_groups["FamilyTransverse"].append(actor)
            elif mode == "right":
                actor_groups["RightStage"].append(actor)

    if len(result.family_transverse_edges) > 0:
        link_graph = build_segment_polydata(result.family_transverse_edges)
        if link_graph is not None:
            actor = plotter.add_mesh(link_graph, color="#7e57c2", line_width=2.6, opacity=0.55)
            if actor is not None:
                actor_groups["FamilyTransverse"].append(actor)

    if len(result.family_cluster_centers) > 0:
        palette = ["#ef5350", "#ffb74d", "#66bb6a", "#42a5f5", "#ab47bc", "#26a69a"]
        for idx, center in enumerate(np.asarray(result.family_cluster_centers, dtype=float)):
            actor = add_points(
                plotter,
                np.asarray(center, dtype=float),
                color=palette[idx % len(palette)],
                size=13.0,
                label="family evidence region centers" if idx == 0 else None,
            )
            if actor is not None:
                actor_groups["Clusters"].append(actor)

    certified_path = np.asarray(result.certified_path, dtype=float)
    display_path = np.asarray(result.display_path, dtype=float)
    if len(display_path) >= 2:
        polyline = pv.lines_from_points(display_path)
        actor = plotter.add_mesh(polyline, color="#1565c0", line_width=7.0, label="display path")
        if actor is not None:
            actor_groups["Path"].append(actor)
    same_display_path = (
        certified_path.shape == display_path.shape
        and np.allclose(certified_path, display_path)
    )
    if len(certified_path) >= 2 and not same_display_path:
        raw_polyline = pv.lines_from_points(certified_path)
        actor = plotter.add_mesh(raw_polyline, color="#90a4ae", line_width=3.0, opacity=0.7, label="certified route")
        if actor is not None:
            actor_groups["Path"].append(actor)
    if len(result.strict_invalid_points) > 0:
        actor = add_points(plotter, result.strict_invalid_points, color="#d32f2f", size=14.0, label="strict validation failures")
        if actor is not None:
            actor_groups["Invalid"].append(actor)

    if len(result.explored_points) > 0:
        actor = add_points(plotter, result.explored_points, color="#5c6bc0", size=5.5, label="explored vertices")
        if actor is not None:
            actor_groups["FamilyLeaf"].append(actor)
    if len(result.candidate_entries) > 0:
        actor = add_points(plotter, result.candidate_entries, color="#00acc1", size=10.0, label="entry seeds")
        if actor is not None:
            actor_groups["Seeds"].append(actor)
    if len(result.entry_transition_points) > 0:
        actor = add_points(plotter, result.entry_transition_points, color="#26a69a", size=11.0, label="certified entry seeds")
        if actor is not None:
            actor_groups["Seeds"].append(actor)
    if len(result.exit_transition_points) > 0:
        actor = add_points(plotter, result.exit_transition_points, color="#66bb6a", size=11.0, label="discovered exit seeds")
        if actor is not None:
            actor_groups["Seeds"].append(actor)
    actor = add_points(plotter, start_q, color="black", size=16.0, label="start")
    if actor is not None:
        actor_groups["StartGoal"].append(actor)
    actor = add_points(plotter, goal_q, color="gold", size=18.0, label="goal")
    if actor is not None:
        actor_groups["StartGoal"].append(actor)
    if result.entry_switch is not None:
        actor = add_points(plotter, result.entry_switch, color="#212121", size=16.0, label="selected entry switch")
        if actor is not None:
            actor_groups["Seeds"].append(actor)
    if result.exit_switch is not None:
        actor = add_points(plotter, result.exit_switch, color="#2e7d32", size=16.0, label="selected exit switch")
        if actor is not None:
            actor_groups["Seeds"].append(actor)

    def set_visibility(name: str, visible: bool):
        for actor_inner in actor_groups.get(name, []):
            actor_inner.SetVisibility(bool(visible))
        plotter.render()

    labels = [
        "Supports",
        "LeftStage",
        "FamilyLeaves",
        "Obstacles",
        "FamilyLeaf",
        "FamilyTransverse",
        "RightStage",
        "Clusters",
        "Seeds",
        "Path",
        "Invalid",
        "StartGoal",
    ]
    for idx, label in enumerate(labels):
        y = 10 + idx * 42
        plotter.add_text(label, position=(55, y + 7), font_size=10, color="black")
        plotter.add_checkbox_button_widget(
            callback=lambda state, name=label: set_visibility(name, state),
            value=True,
            position=(10, y),
            size=28,
            color_on="lightgray",
            color_off="white",
            background_color="gray",
        )

    plotter.add_axes()
    plotter.show_grid()
    plotter.show()
    return True
