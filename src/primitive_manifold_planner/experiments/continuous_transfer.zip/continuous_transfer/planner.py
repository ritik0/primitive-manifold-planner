"""Top-level orchestration for the staged continuous-transfer planner in Example 65."""

from __future__ import annotations

from typing import Any

import numpy as np

from .algorithms.staged_planner import StagedPlannerDelegates, StagedPlannerShell
from .benchmarks.scene_loader import build_continuous_transfer_scene, default_example_65_scene_description
from .config import (
    DEFAULT_EVIDENCE_SATURATION_CONTINUATION,
    DEFAULT_FAMILY_EVIDENCE_ROUNDS,
    DEFAULT_POST_ROUTE_EVIDENCE_ROUNDS,
    FAMILY_ROUTE_SELECTION_EXIT_HINT,
    LEFT_STAGE_BASE_ROUNDS,
)
from .core.stage_graph import StageGraph, StageNode, TransitionConstraint
from .family_stage import bridge_committed_family_support, plan_within_family_stage, start_reachable_family_node_ids
from .graph_types import ContinuousTransferRoute, FamilyConnectivityGraph, RightStageClosureResult
from .left_stage import discover_entry_seeds_from_left
from .lambda_utils import (
    clamp_lambda,
    family_lambda_values,
    refine_lambda_region_if_promising,
    summarize_explored_lambda_regions,
    summarize_lambda_coverage_gaps,
)
from .projection_utils import sphere_radius_from_family
from .right_stage import build_outer_route_from_family_exit
from .graph_paths import shortest_path_over_graph
from .route_geometry import build_route_geometry_views
from .route_semantics import (
    GraphRouteCandidate,
    profile_family_route,
    rank_graph_route_candidates,
    rank_transition_supports_for_route_selection,
    summarize_family_route_semantics,
)
from .strict_validation import validate_selected_route_strictly
from .support import (
    deduplicate_points,
    explored_points_from_edges,
    merge_edges,
    sample_chart_centers,
)


def _build_example_65_stage_graph() -> StageGraph:
    """Create the fixed left -> family -> right stage graph for Example 65."""

    return StageGraph(
        nodes=[
            StageNode(stage_id="left", label="Left Outer Stage", stage_kind="outer_support"),
            StageNode(stage_id="family", label="Continuous Family Stage", stage_kind="transfer_family"),
            StageNode(stage_id="right", label="Right Outer Stage", stage_kind="outer_support"),
        ],
        transitions=[
            TransitionConstraint(source_stage_id="left", target_stage_id="family", transition_kind="entry"),
            TransitionConstraint(source_stage_id="family", target_stage_id="right", transition_kind="exit"),
        ],
    )


def _build_left_stage_failure_route(
    *,
    scene_profile: str,
    transfer_family,
    start_q: np.ndarray,
    start_node_id: int,
    left_round_budget: int,
    graph: FamilyConnectivityGraph,
    frontier_ids: dict[str, list[int]],
    explored_edges_by_mode: dict[str, list[tuple[np.ndarray, np.ndarray]]],
    family_transverse_edges: list[tuple[np.ndarray, np.ndarray]],
    entry_transition_points: list[np.ndarray],
    round_sources: list[np.ndarray],
    round_targets: list[np.ndarray],
) -> ContinuousTransferRoute:
    explored_edges = merge_edges(*explored_edges_by_mode.values())
    explored_points = explored_points_from_edges(explored_edges)
    return ContinuousTransferRoute(
        success=False,
        message="Left-stage exploration did not discover any robust certified entry seed into the transfer family.",
        selected_lambda=None,
        graph_node_path=[int(start_node_id)],
        graph_edge_path=[],
        certified_path=np.asarray([start_q], dtype=float),
        display_path=np.asarray([start_q], dtype=float),
        path=np.asarray([start_q], dtype=float),
        raw_path=np.asarray([start_q], dtype=float),
        scene_profile=scene_profile,
        family_obstacle_count=len(transfer_family.obstacles),
        family_obstacle_summary=transfer_family.obstacle_summaries(),
        candidate_entries=np.zeros((0, 3), dtype=float),
        candidate_lambdas=np.zeros((0,), dtype=float),
        exit_candidates=np.zeros((0, 3), dtype=float),
        explored_edges=explored_edges,
        explored_points=explored_points,
        round_sources=np.asarray(round_sources, dtype=float) if round_sources else np.zeros((0, 3), dtype=float),
        round_targets=np.asarray(round_targets, dtype=float) if round_targets else np.zeros((0, 3), dtype=float),
        chart_centers=sample_chart_centers(explored_points, max(1, len(explored_points))),
        chart_count=len(explored_points),
        evaluation_count=len(round_targets),
        round_count=int(left_round_budget),
        explored_edges_by_mode=explored_edges_by_mode,
        family_transverse_edges=family_transverse_edges,
        entry_transition_points=deduplicate_points(entry_transition_points, tol=1e-4),
        exit_transition_points=np.zeros((0, 3), dtype=float),
        explored_lambda_values=family_lambda_values(graph),
        entry_seed_count=0,
        family_frontier_count=len(frontier_ids.get("family", [])),
        lambda_coverage_gaps=summarize_lambda_coverage_gaps(transfer_family, family_lambda_values(graph)),
        graph_node_count=len(graph.nodes),
        graph_edge_count=len(graph.edges),
        right_frontier_count=len(frontier_ids.get("right", [])),
        augmented_family_state_count=sum(1 for node in graph.nodes if str(node.mode) == "family"),
        augmented_family_edge_count=sum(
            1 for edge in graph.edges if str(edge.kind) in {"family_leaf_motion", "family_transverse"}
        ),
        augmented_family_changing_lambda_edge_count=sum(
            1
            for edge in graph.edges
            if str(edge.kind) in {"family_leaf_motion", "family_transverse"}
            and len(np.asarray(edge.path_lambdas, dtype=float)) > 1
            and float(np.max(np.asarray(edge.path_lambdas, dtype=float)) - np.min(np.asarray(edge.path_lambdas, dtype=float))) > 1.5e-2
        ),
        augmented_family_constant_lambda_edge_count=0,
        family_space_sampler_usage={},
        route_lambda_span=0.0,
        route_lambda_variation_total=0.0,
        route_constant_lambda_edge_count=0,
        route_lambda_varying_edge_count=0,
    )


def _select_route_exit_seeds_for_closure(
    graph: FamilyConnectivityGraph,
    start_node_id: int,
    family_result,
    transfer_family,
):
    reachable_family_ids = start_reachable_family_node_ids(graph, start_node_id)
    route_exit_seeds = [
        seed for seed in family_result.exit_seeds if int(seed.family_node_id) in reachable_family_ids
    ]
    if len(route_exit_seeds) == 0:
        route_exit_seeds = list(family_result.exit_seeds)
    if family_result.primary_entry_lambda is not None and len(transfer_family.obstacles) == 0:
        same_leaf_route_exit_seeds = [
            seed
            for seed in route_exit_seeds
            if abs(float(seed.lambda_value) - float(family_result.primary_entry_lambda)) <= 1.5e-2
        ]
        if len(same_leaf_route_exit_seeds) > 0:
            route_exit_seeds = same_leaf_route_exit_seeds
    return route_exit_seeds


def _build_final_continuous_route(
    *,
    scene_profile: str,
    graph: FamilyConnectivityGraph,
    start_node_id: int,
    goal_node_id: int,
    start_q: np.ndarray,
    goal_q: np.ndarray,
    left_manifold,
    left_center: np.ndarray,
    left_radius: float,
    transfer_family,
    right_manifold,
    right_center: np.ndarray,
    right_radius: float,
    frontier_ids: dict[str, list[int]],
    explored_edges_by_mode: dict[str, list[tuple[np.ndarray, np.ndarray]]],
    family_transverse_edges: list[tuple[np.ndarray, np.ndarray]],
    entry_transition_points: list[np.ndarray],
    exit_transition_points: list[np.ndarray],
    round_sources: list[np.ndarray],
    round_targets: list[np.ndarray],
    entry_seeds,
    family_result,
    bridge_rounds: int,
    route_exit_seeds,
    right_closure_result: RightStageClosureResult,
    top_k_assignments: int,
    left_round_budget: int,
) -> ContinuousTransferRoute:
    direct_graph_cost, direct_node_path, direct_edge_path = shortest_path_over_graph(graph, start_node_id, goal_node_id)
    candidate_routes: list[GraphRouteCandidate] = []
    if len(direct_edge_path) > 0:
        candidate_routes.append(
            GraphRouteCandidate(
                total_cost=float(direct_graph_cost),
                node_path=list(direct_node_path),
                edge_path=list(direct_edge_path),
                terminal_support=None,
            )
        )
    candidate_exit_seeds = rank_transition_supports_for_route_selection(
        route_exit_seeds,
        target_q=np.asarray(goal_q, dtype=float),
        top_k_assignments=top_k_assignments,
    )
    for exit_seed in candidate_exit_seeds:
        cost_to_exit, nodes_to_exit, edges_to_exit = shortest_path_over_graph(graph, start_node_id, int(exit_seed.right_node_id))
        cost_to_goal, nodes_to_goal, edges_to_goal = shortest_path_over_graph(graph, int(exit_seed.right_node_id), goal_node_id)
        if len(edges_to_exit) == 0 or len(edges_to_goal) == 0:
            continue
        candidate_routes.append(
            GraphRouteCandidate(
                total_cost=float(cost_to_exit + cost_to_goal),
                node_path=list(nodes_to_exit) + list(nodes_to_goal[1:]),
                edge_path=list(edges_to_exit) + list(edges_to_goal),
                terminal_support=exit_seed,
            )
        )
    unique_candidates: dict[tuple[int, ...], GraphRouteCandidate] = {}
    for candidate in candidate_routes:
        key = tuple(int(edge_id) for edge_id in candidate.edge_path)
        if key not in unique_candidates or float(candidate.total_cost) < float(unique_candidates[key].total_cost):
            unique_candidates[key] = candidate
    ranked_candidates = rank_graph_route_candidates(
        graph=graph,
        candidates=list(unique_candidates.values()),
        primary_entry_lambda=family_result.primary_entry_lambda,
    )
    if len(ranked_candidates) > 0:
        best_candidate = ranked_candidates[0]
        best_node_path = list(best_candidate.node_path)
        best_edge_path = list(best_candidate.edge_path)
        chosen_exit_seed = best_candidate.terminal_support
    else:
        best_node_path, best_edge_path, chosen_exit_seed = [], [], None

    explored_edges = merge_edges(*explored_edges_by_mode.values())
    explored_points = explored_points_from_edges(explored_edges)
    route_views = (
        build_route_geometry_views(
            graph=graph,
            node_path=best_node_path,
            edge_path=best_edge_path,
            left_manifold=left_manifold,
            left_center=left_center,
            left_radius=left_radius,
            transfer_family=transfer_family,
            right_manifold=right_manifold,
            right_center=right_center,
            right_radius=right_radius,
        )
        if len(best_edge_path) > 0
        else None
    )
    certified_path = (
        np.asarray(route_views.certified_path, dtype=float)
        if route_views is not None and len(route_views.certified_path) > 0
        else np.asarray([start_q], dtype=float)
    )
    display_path = (
        np.asarray(route_views.display_path, dtype=float)
        if route_views is not None and len(route_views.display_path) > 0
        else certified_path.copy()
    )
    route_is_strict, strict_message, strict_failures, strict_invalid_points = validate_selected_route_strictly(
        graph=graph,
        edge_path=best_edge_path,
        left_manifold=left_manifold,
        left_center=left_center,
        left_radius=left_radius,
        transfer_family=transfer_family,
        right_manifold=right_manifold,
        right_center=right_center,
        right_radius=right_radius,
    )
    has_graph_route = len(best_node_path) > 0 and len(best_edge_path) > 0
    has_certified_geometry = len(certified_path) > 0
    chosen_transition_nodes = (
        deduplicate_points([graph.nodes[nid].q for nid in best_node_path if graph.nodes[nid].kind == "transition"], tol=1e-4)
        if len(best_node_path) > 0
        else np.zeros((0, 3), dtype=float)
    )
    family_path_lambdas = [
        float(graph.nodes[nid].lambda_value)
        for nid in best_node_path
        if graph.nodes[nid].mode == "family" and graph.nodes[nid].lambda_value is not None
    ]
    explored_lambda_values = family_lambda_values(graph)
    explored_lambda_regions = summarize_explored_lambda_regions(graph)
    lambda_coverage_span = 0.0 if len(explored_lambda_values) == 0 else float(np.max(explored_lambda_values) - np.min(explored_lambda_values))
    lambda_coverage_gaps = summarize_lambda_coverage_gaps(transfer_family, explored_lambda_values)
    family_exit_discovery_round = (
        None if family_result.exit_discovery_round is None else int(left_round_budget + family_result.exit_discovery_round)
    )
    if len(best_node_path) == 0 or not route_is_strict:
        first_solution_round = None
        best_solution_round = None
    else:
        first_solution_round = int(
            left_round_budget
            + family_result.expansion_rounds
            + max(1, int(right_closure_result.route_discovery_round or right_closure_result.rounds))
        )
        best_solution_round = max(
            first_solution_round,
            int(left_round_budget + family_result.expansion_rounds + max(1, right_closure_result.rounds)),
        )
    exploration_mode_usage = {"left_entry_discovery": int(left_round_budget)}
    exploration_mode_usage.update(family_result.mode_usage)
    exploration_mode_usage["right_stage_closure"] = int(right_closure_result.rounds)
    selected_exit_seed = chosen_exit_seed or next(
        (
            seed
            for seed in family_result.exit_seeds
            if int(seed.family_node_id) in set(best_node_path) or int(seed.right_node_id) in set(best_node_path)
        ),
        None,
    )
    alternate_exit_seed_usage_count = 0
    if selected_exit_seed is not None and len(family_result.exit_seeds) > 1:
        earliest_exit_round = min(int(seed.discovered_round) for seed in family_result.exit_seeds)
        if int(selected_exit_seed.discovered_round) > earliest_exit_round:
            alternate_exit_seed_usage_count = 1
    final_route_same_leaf_first, final_route_same_leaf_only = summarize_family_route_semantics(
        graph=graph,
        edge_path=best_edge_path,
        primary_entry_lambda=family_result.primary_entry_lambda,
    )
    route_profile = profile_family_route(
        graph=graph,
        edge_path=best_edge_path,
        primary_entry_lambda=family_result.primary_entry_lambda,
    ) if len(best_edge_path) > 0 else None
    route_lambda_values: list[float] = []
    for edge_id in best_edge_path:
        edge = graph.edges[int(edge_id)]
        if str(edge.kind) not in {"family_leaf_motion", "family_transverse", "entry_transition", "exit_transition"}:
            continue
        if len(edge.path_lambdas) > 0:
            route_lambda_values.extend(float(v) for v in np.asarray(edge.path_lambdas, dtype=float).reshape(-1))
        elif edge.lambda_value is not None:
            route_lambda_values.append(float(edge.lambda_value))
    route_lambda_variation_total = 0.0
    if len(route_lambda_values) >= 2:
        route_lambda_variation_total = float(np.sum(np.abs(np.diff(np.asarray(route_lambda_values, dtype=float)))))
    route_constant_lambda_edge_count = sum(
        1
        for edge_id in best_edge_path
        if str(graph.edges[int(edge_id)].kind) in {"family_leaf_motion", "family_transverse"}
        and len(np.asarray(graph.edges[int(edge_id)].path_lambdas, dtype=float)) > 0
        and float(np.max(np.asarray(graph.edges[int(edge_id)].path_lambdas, dtype=float)) - np.min(np.asarray(graph.edges[int(edge_id)].path_lambdas, dtype=float))) <= 1.5e-2
    )
    route_lambda_varying_edge_count = sum(
        1
        for edge_id in best_edge_path
        if str(graph.edges[int(edge_id)].kind) in {"family_leaf_motion", "family_transverse"}
        and len(np.asarray(graph.edges[int(edge_id)].path_lambdas, dtype=float)) > 0
        and float(np.max(np.asarray(graph.edges[int(edge_id)].path_lambdas, dtype=float)) - np.min(np.asarray(graph.edges[int(edge_id)].path_lambdas, dtype=float))) > 1.5e-2
    )
    committed_family_region_count = max(
        0,
        len(
            {
                round(float(graph.nodes[node_id].lambda_value) / 0.08)
                for node_id in best_node_path
                if graph.nodes[node_id].mode == "family" and graph.nodes[node_id].lambda_value is not None
            }
        ),
    )
    return ContinuousTransferRoute(
        success=has_graph_route and has_certified_geometry and route_is_strict,
        message=(
            "The planner accumulated left/family/right evidence in parallel, extracted a certified sequential route from that evidence graph, and only then produced a display route after strict manifold validation passed."
            if has_graph_route and has_certified_geometry and route_is_strict
            else strict_message
            if has_graph_route and has_certified_geometry
            else "The planner reached the right stage but did not close a certified start-to-goal route within the right-stage closure budget."
            if len(family_result.exit_seeds) > 0
            else "The left stage found entry seeds, but the family evidence explorer did not discover a certified right exit within budget despite maintaining alternate family evidence regions."
        ),
        selected_lambda=None if len(family_path_lambdas) == 0 else float(np.mean(family_path_lambdas)),
        graph_node_path=[int(node_id) for node_id in best_node_path],
        graph_edge_path=[int(edge_id) for edge_id in best_edge_path],
        certified_path=certified_path,
        display_path=display_path,
        path=display_path,
        raw_path=certified_path,
        scene_profile=scene_profile,
        family_obstacle_count=len(transfer_family.obstacles),
        family_obstacle_summary=transfer_family.obstacle_summaries(),
        entry_switch=None if len(chosen_transition_nodes) == 0 else np.asarray(chosen_transition_nodes[0], dtype=float),
        exit_switch=None if len(chosen_transition_nodes) == 0 else np.asarray(chosen_transition_nodes[-1], dtype=float),
        candidate_entries=deduplicate_points([seed.q for seed in entry_seeds], tol=1e-4),
        candidate_lambdas=np.asarray([seed.lambda_value for seed in entry_seeds], dtype=float),
        exit_candidates=deduplicate_points([seed.q for seed in family_result.exit_seeds], tol=1e-4),
        explored_edges=explored_edges,
        explored_points=explored_points,
        round_sources=np.asarray(round_sources, dtype=float) if round_sources else np.zeros((0, 3), dtype=float),
        round_targets=np.asarray(round_targets, dtype=float) if round_targets else np.zeros((0, 3), dtype=float),
        chart_centers=sample_chart_centers(explored_points, max(1, len(explored_points))),
        chart_count=len(explored_points),
        evaluation_count=len(round_targets),
        round_count=left_round_budget + family_result.expansion_rounds + right_closure_result.rounds,
        explored_edges_by_mode=explored_edges_by_mode,
        family_transverse_edges=family_transverse_edges,
        entry_transition_points=deduplicate_points(entry_transition_points, tol=1e-4),
        exit_transition_points=deduplicate_points(exit_transition_points, tol=1e-4),
        explored_lambda_values=explored_lambda_values,
        family_leaf_motion_edge_count=sum(1 for edge in graph.edges if edge.kind == "family_leaf_motion"),
        family_transverse_edge_count=sum(1 for edge in graph.edges if edge.kind == "family_transverse"),
        rejected_transverse_count=family_result.rejected_transverse_count,
        entry_transition_count=sum(1 for edge in graph.edges if edge.kind == "entry_transition"),
        exit_transition_count=sum(1 for edge in graph.edges if edge.kind == "exit_transition"),
        entry_seed_count=len(entry_seeds),
        exit_seed_count=len(family_result.exit_seeds),
        family_frontier_count=len(frontier_ids.get("family", [])),
        family_expansion_rounds=family_result.expansion_rounds + bridge_rounds,
        family_exit_discovery_round=family_exit_discovery_round,
        family_cluster_count=family_result.cluster_count,
        active_family_cluster_count=family_result.active_cluster_count,
        stalled_family_cluster_count=family_result.stalled_cluster_count,
        cluster_switch_count=family_result.cluster_switch_count,
        alternate_entry_seed_usage_count=family_result.alternate_entry_seed_usage_count,
        alternate_exit_seed_usage_count=alternate_exit_seed_usage_count,
        family_exit_candidates_kept=len(family_result.exit_seeds),
        family_regions_with_no_exit=family_result.family_regions_with_no_exit,
        family_regions_with_exit=family_result.family_regions_with_exit,
        best_right_residual_seen=family_result.best_right_residual_seen,
        lambda_coverage_span=lambda_coverage_span,
        lambda_coverage_gaps=lambda_coverage_gaps,
        family_cluster_summaries=family_result.family_cluster_summaries,
        family_cluster_centers=family_result.family_cluster_centers,
        explored_lambda_region_count=len(explored_lambda_regions),
        explored_lambda_regions=explored_lambda_regions,
        first_solution_round=first_solution_round,
        best_solution_round=best_solution_round,
        continued_after_first_solution=bool(
            first_solution_round is not None and best_solution_round is not None and best_solution_round > first_solution_round
        ),
        lambda_hypothesis_count=len(explored_lambda_values),
        family_candidates_before_solution=len(entry_seeds),
        exploration_mode_usage=exploration_mode_usage,
        graph_node_count=len(graph.nodes),
        graph_edge_count=len(graph.edges),
        right_closure_rounds=right_closure_result.rounds,
        right_frontier_count=right_closure_result.right_frontier_count,
        right_closure_attempt_count=right_closure_result.closure_attempt_count,
        successful_right_closure_seed_count=right_closure_result.successful_seed_count,
        failed_right_closure_seed_count=right_closure_result.failed_seed_count,
        best_goal_residual_seen_on_right=right_closure_result.best_goal_residual_seen,
        right_goal_connection_attempts=right_closure_result.goal_connection_attempts,
        right_goal_connection_successes=right_closure_result.goal_connection_successes,
        right_goal_connection_failures=right_closure_result.goal_connection_failures,
        best_goal_distance_seen_on_right=right_closure_result.best_goal_distance_seen,
        final_graph_route_found_before_validation=has_graph_route,
        primary_entry_lambda=family_result.primary_entry_lambda,
        primary_entry_seed_id=family_result.primary_entry_seed_id,
        same_leaf_attempt_count=family_result.same_leaf_attempt_count,
        same_leaf_progress_count=family_result.same_leaf_progress_count,
        same_leaf_failure_count=family_result.same_leaf_failure_count,
        same_leaf_successful_exit_found=family_result.same_leaf_successful_exit_found,
        same_leaf_stagnation_triggered=family_result.same_leaf_stagnation_triggered,
        transverse_switch_count_after_entry=family_result.transverse_switch_count_after_entry,
        first_transverse_round_after_entry=family_result.first_transverse_round_after_entry,
        first_transverse_switch_reason=family_result.first_transverse_switch_reason,
        transverse_switch_reason_counts=family_result.transverse_switch_reason_counts,
        final_route_same_leaf_first=final_route_same_leaf_first,
        final_route_same_leaf_only=final_route_same_leaf_only,
        shared_proposals_processed=family_result.shared_proposals_processed,
        proposals_used_by_multiple_family_regions=family_result.proposals_used_by_multiple_family_regions,
        family_evidence_region_count=family_result.family_evidence_region_count,
        family_evidence_only_region_count=family_result.family_evidence_only_region_count,
        committed_family_region_count=committed_family_region_count,
        family_lambda_coverage_before_first_committed_route=family_result.family_lambda_coverage_before_first_committed_route,
        family_lambda_coverage_after_first_committed_route=family_result.family_lambda_coverage_after_first_committed_route,
        transition_hypotheses_left_family=family_result.transition_hypotheses_left_family,
        transition_hypotheses_family_right=family_result.transition_hypotheses_family_right,
        family_region_updates_per_round=family_result.family_region_updates_per_round,
        committed_route_changes_after_first_solution=family_result.committed_route_changes_after_first_solution,
        average_useful_family_regions_per_proposal=family_result.average_useful_family_regions_per_proposal,
        augmented_family_state_count=family_result.augmented_family_state_count,
        augmented_family_edge_count=family_result.augmented_family_edge_count,
        augmented_family_changing_lambda_edge_count=family_result.augmented_family_changing_lambda_edge_count,
        augmented_family_constant_lambda_edge_count=family_result.augmented_family_constant_lambda_edge_count,
        family_space_sampler_usage=family_result.family_space_sampler_usage,
        route_lambda_span=0.0 if route_profile is None else float(route_profile.lambda_span),
        route_lambda_variation_total=float(route_lambda_variation_total),
        route_constant_lambda_edge_count=int(route_constant_lambda_edge_count),
        route_lambda_varying_edge_count=int(route_lambda_varying_edge_count),
        strict_validation_message=strict_message,
        strict_validation_failures=strict_failures,
        strict_invalid_points=strict_invalid_points,
    )


def _capture_stage_value(stage_fn, sink: dict[str, object]):
    """Capture one staged delegate result for later finalization without changing behavior."""

    result = stage_fn()
    sink["value"] = result
    return result


def plan_continuous_transfer_route(
    max_ambient_probes: int | None = DEFAULT_FAMILY_EVIDENCE_ROUNDS,
    continue_after_first_solution: bool = DEFAULT_EVIDENCE_SATURATION_CONTINUATION,
    max_extra_rounds_after_first_solution: int | None = DEFAULT_POST_ROUTE_EVIDENCE_ROUNDS,
    top_k_assignments: int = FAMILY_ROUTE_SELECTION_EXIT_HINT,
    seed: int | None = 41,
    obstacle_profile: str = "none",
    scene_description: dict[str, Any] | str | None = None,
) -> ContinuousTransferRoute:
    scene_profile = "none" if obstacle_profile is None else str(obstacle_profile)
    resolved_scene_description = (
        default_example_65_scene_description(obstacle_profile=scene_profile)
        if scene_description is None
        else scene_description
    )
    scene = build_continuous_transfer_scene(resolved_scene_description)
    scene_profile = str(scene.description.get("transfer_family", {}).get("obstacle_profile", scene_profile))
    left_family = scene.left_support
    transfer_family = scene.transfer_family
    right_family = scene.right_support
    start_q = np.asarray(scene.start_q, dtype=float)
    goal_q = np.asarray(scene.goal_q, dtype=float)
    left_manifold = left_family.manifold(float(left_family.sample_lambdas()[0]))
    right_manifold = right_family.manifold(float(right_family.sample_lambdas()[0]))
    left_center = np.asarray(left_family.center, dtype=float)
    left_radius = sphere_radius_from_family(left_family)
    right_center = np.asarray(right_family.center, dtype=float)
    right_radius = sphere_radius_from_family(right_family)
    bounds_min = np.asarray(scene.bounds_min, dtype=float)
    bounds_max = np.asarray(scene.bounds_max, dtype=float)
    rng = np.random.default_rng(seed)

    graph = FamilyConnectivityGraph()
    start_node_id = graph.register_node("left", start_q, 0, "start")
    goal_node_id = graph.register_node("right", goal_q, 0, "goal")
    frontier_ids: dict[str, list[int]] = {"left": [start_node_id], "family": [], "right": [goal_node_id]}
    explored_edges_by_mode = {"left": [], "family_leaf": [], "family_transverse": [], "right": []}
    family_transverse_edges: list[tuple[np.ndarray, np.ndarray]] = []
    entry_transition_points: list[np.ndarray] = []
    exit_transition_points: list[np.ndarray] = []
    round_sources: list[np.ndarray] = []
    round_targets: list[np.ndarray] = []
    adaptive_lambda_values: set[float] = {float(v) for v in transfer_family.sample_lambdas({"count": 5})}
    left_round_budget = max(LEFT_STAGE_BASE_ROUNDS, 1 + int(0 if max_ambient_probes is None else max_ambient_probes) // 3)
    family_round_budget = DEFAULT_FAMILY_EVIDENCE_ROUNDS if max_ambient_probes is None else int(max_ambient_probes)
    stage_graph = _build_example_65_stage_graph()

    def run_left_stage():
        return discover_entry_seeds_from_left(
            graph=graph,
            start_node_id=start_node_id,
            left_manifold=left_manifold,
            left_center=left_center,
            left_radius=left_radius,
            transfer_family=transfer_family,
            clamp_lambda_fn=clamp_lambda,
            frontier_ids=frontier_ids,
            bounds_min=bounds_min,
            bounds_max=bounds_max,
            rng=rng,
            left_round_budget=left_round_budget,
            explored_edges_by_mode=explored_edges_by_mode,
            adaptive_lambda_values=adaptive_lambda_values,
            refine_lambda_region_if_promising_fn=refine_lambda_region_if_promising,
            entry_transition_points=entry_transition_points,
            round_sources=round_sources,
            round_targets=round_targets,
        )

    def build_left_stage_failure():
        return _build_left_stage_failure_route(
            scene_profile=scene_profile,
            transfer_family=transfer_family,
            start_q=np.asarray(start_q, dtype=float),
            start_node_id=start_node_id,
            left_round_budget=left_round_budget,
            graph=graph,
            frontier_ids=frontier_ids,
            explored_edges_by_mode=explored_edges_by_mode,
            family_transverse_edges=family_transverse_edges,
            entry_transition_points=entry_transition_points,
            round_sources=round_sources,
            round_targets=round_targets,
        )

    def run_middle_stage(entry_seed_result):
        return plan_within_family_stage(
            graph=graph,
            start_node_id=start_node_id,
            entry_seeds=entry_seed_result,
            transfer_family=transfer_family,
            right_manifold=right_manifold,
            right_center=right_center,
            right_radius=right_radius,
            frontier_ids=frontier_ids,
            bounds_min=bounds_min,
            bounds_max=bounds_max,
            adaptive_lambda_values=adaptive_lambda_values,
            explored_edges_by_mode=explored_edges_by_mode,
            family_transverse_edges=family_transverse_edges,
            exit_transition_points=exit_transition_points,
            round_sources=round_sources,
            round_targets=round_targets,
            rng=rng,
            round_offset=left_round_budget,
            family_round_budget=family_round_budget,
            continue_after_first_solution=continue_after_first_solution,
            max_extra_rounds_after_first_solution=max_extra_rounds_after_first_solution,
        )

    def bridge_middle_support(family_result):
        return bridge_committed_family_support(
            graph=graph,
            start_node_id=start_node_id,
            exit_seeds=family_result.exit_seeds,
            transfer_family=transfer_family,
            frontier_ids=frontier_ids,
            bounds_min=bounds_min,
            bounds_max=bounds_max,
            adaptive_lambda_values=adaptive_lambda_values,
            explored_edges_by_mode=explored_edges_by_mode,
            family_transverse_edges=family_transverse_edges,
            round_sources=round_sources,
            round_targets=round_targets,
            round_idx=left_round_budget + family_result.expansion_rounds + 1,
        )

    def select_right_stage_inputs(family_result):
        return _select_route_exit_seeds_for_closure(
            graph=graph,
            start_node_id=start_node_id,
            family_result=family_result,
            transfer_family=transfer_family,
        )

    def run_right_stage(family_result, route_exit_seeds):
        right_closure_result = RightStageClosureResult(right_frontier_count=len(frontier_ids.get("right", [])))
        if len(route_exit_seeds) > 0:
            right_closure_result = build_outer_route_from_family_exit(
                graph=graph,
                start_node_id=start_node_id,
                goal_node_id=goal_node_id,
                exit_seeds=route_exit_seeds,
                right_manifold=right_manifold,
                right_center=right_center,
                right_radius=right_radius,
                goal_q=goal_q,
                frontier_ids=frontier_ids,
                bounds_min=bounds_min,
                bounds_max=bounds_max,
                round_idx=left_round_budget + family_result.expansion_rounds + 1,
                explored_edges_by_mode=explored_edges_by_mode,
                round_sources=round_sources,
                round_targets=round_targets,
                rng=rng,
            )
        return right_closure_result

    def finalize_route(family_result, bridge_rounds, route_exit_seeds, right_closure_result):
        return _build_final_continuous_route(
            scene_profile=scene_profile,
            graph=graph,
            start_node_id=start_node_id,
            goal_node_id=goal_node_id,
            start_q=np.asarray(start_q, dtype=float),
            goal_q=np.asarray(goal_q, dtype=float),
            left_manifold=left_manifold,
            left_center=left_center,
            left_radius=left_radius,
            transfer_family=transfer_family,
            right_manifold=right_manifold,
            right_center=right_center,
            right_radius=right_radius,
            frontier_ids=frontier_ids,
            explored_edges_by_mode=explored_edges_by_mode,
            family_transverse_edges=family_transverse_edges,
            entry_transition_points=entry_transition_points,
            exit_transition_points=exit_transition_points,
            round_sources=round_sources,
            round_targets=round_targets,
            entry_seeds=list(run_left_result.get("value", [])),
            family_result=family_result,
            bridge_rounds=int(bridge_rounds),
            route_exit_seeds=route_exit_seeds,
            right_closure_result=right_closure_result,
            top_k_assignments=top_k_assignments,
            left_round_budget=left_round_budget,
        )

    run_left_result: dict[str, object] = {}
    delegates = StagedPlannerDelegates(
        run_left_stage=lambda: _capture_stage_value(run_left_stage, run_left_result),
        build_left_stage_failure=build_left_stage_failure,
        run_middle_stage=run_middle_stage,
        bridge_middle_support=bridge_middle_support,
        select_right_stage_inputs=select_right_stage_inputs,
        run_right_stage=run_right_stage,
        finalize_route=finalize_route,
    )
    shell = StagedPlannerShell(stage_graph=stage_graph, delegates=delegates)
    return shell.run()


def print_continuous_route_summary(result: ContinuousTransferRoute) -> None:
    fields = [
        ("success", result.success),
        ("message", result.message),
        ("scene_profile", result.scene_profile),
        ("family_obstacle_count", result.family_obstacle_count),
        ("family_obstacle_summary", result.family_obstacle_summary),
        ("selected_lambda", None if result.selected_lambda is None else round(float(result.selected_lambda), 6)),
        ("total_rounds", result.round_count),
        ("evaluation_events", result.evaluation_count),
        ("entry_seed_count", result.entry_seed_count),
        ("exit_seed_count", result.exit_seed_count),
        ("shared_proposals_processed", result.shared_proposals_processed),
        ("proposals_used_by_multiple_family_regions", result.proposals_used_by_multiple_family_regions),
        ("family_evidence_region_count", result.family_evidence_region_count),
        ("family_evidence_only_region_count", result.family_evidence_only_region_count),
        ("committed_family_region_count", result.committed_family_region_count),
        ("family_lambda_coverage_before_first_committed_route", result.family_lambda_coverage_before_first_committed_route),
        ("family_lambda_coverage_after_first_committed_route", result.family_lambda_coverage_after_first_committed_route),
        ("transition_hypotheses_left_family", result.transition_hypotheses_left_family),
        ("transition_hypotheses_family_right", result.transition_hypotheses_family_right),
        ("family_region_updates_per_round", round(float(result.family_region_updates_per_round), 4)),
        ("committed_route_changes_after_first_solution", result.committed_route_changes_after_first_solution),
        ("average_useful_family_regions_per_proposal", round(float(result.average_useful_family_regions_per_proposal), 4)),
        ("augmented_family_state_count", result.augmented_family_state_count),
        ("augmented_family_edge_count", result.augmented_family_edge_count),
        ("augmented_family_changing_lambda_edge_count", result.augmented_family_changing_lambda_edge_count),
        ("augmented_family_constant_lambda_edge_count", result.augmented_family_constant_lambda_edge_count),
        ("route_lambda_span", round(float(result.route_lambda_span), 6)),
        ("route_lambda_variation_total", round(float(result.route_lambda_variation_total), 6)),
        ("route_constant_lambda_edge_count", result.route_constant_lambda_edge_count),
        ("route_lambda_varying_edge_count", result.route_lambda_varying_edge_count),
        ("primary_entry_lambda", None if result.primary_entry_lambda is None else round(float(result.primary_entry_lambda), 6)),
        ("primary_entry_seed_id", result.primary_entry_seed_id),
        ("same_leaf_attempt_count", result.same_leaf_attempt_count),
        ("same_leaf_progress_count", result.same_leaf_progress_count),
        ("same_leaf_failure_count", result.same_leaf_failure_count),
        ("same_leaf_successful_exit_found", result.same_leaf_successful_exit_found),
        ("same_leaf_stagnation_triggered", result.same_leaf_stagnation_triggered),
        ("transverse_switch_count_after_entry", result.transverse_switch_count_after_entry),
        ("first_transverse_round_after_entry", result.first_transverse_round_after_entry),
        ("first_transverse_switch_reason", result.first_transverse_switch_reason),
        ("transverse_switch_reason_counts", result.transverse_switch_reason_counts),
        ("final_route_same_leaf_first", result.final_route_same_leaf_first),
        ("final_route_same_leaf_only", result.final_route_same_leaf_only),
        ("family_frontier_count", result.family_frontier_count),
        ("family_expansion_rounds", result.family_expansion_rounds),
        ("family_exit_discovery_round", result.family_exit_discovery_round),
        ("family_cluster_count", result.family_cluster_count),
        ("active_family_cluster_count", result.active_family_cluster_count),
        ("stalled_family_cluster_count", result.stalled_family_cluster_count),
        ("cluster_switch_count", result.cluster_switch_count),
        ("alternate_entry_seed_usage_count", result.alternate_entry_seed_usage_count),
        ("alternate_exit_seed_usage_count", result.alternate_exit_seed_usage_count),
        ("family_exit_candidates_kept", result.family_exit_candidates_kept),
        ("family_regions_with_no_exit", result.family_regions_with_no_exit),
        ("family_regions_with_exit", result.family_regions_with_exit),
        ("best_right_residual_seen", None if not np.isfinite(result.best_right_residual_seen) else round(float(result.best_right_residual_seen), 6)),
        ("right_closure_rounds", result.right_closure_rounds),
        ("right_frontier_count", result.right_frontier_count),
        ("right_closure_attempt_count", result.right_closure_attempt_count),
        ("successful_right_closure_seed_count", result.successful_right_closure_seed_count),
        ("failed_right_closure_seed_count", result.failed_right_closure_seed_count),
        ("right_goal_connection_attempts", result.right_goal_connection_attempts),
        ("right_goal_connection_successes", result.right_goal_connection_successes),
        ("right_goal_connection_failures", result.right_goal_connection_failures),
        ("best_goal_residual_seen_on_right", None if not np.isfinite(result.best_goal_residual_seen_on_right) else round(float(result.best_goal_residual_seen_on_right), 6)),
        ("best_goal_distance_seen_on_right", None if not np.isfinite(result.best_goal_distance_seen_on_right) else round(float(result.best_goal_distance_seen_on_right), 6)),
        ("lambda_coverage_span", round(float(result.lambda_coverage_span), 6)),
        ("lambda_coverage_gaps", result.lambda_coverage_gaps),
        ("graph_nodes", result.graph_node_count),
        ("graph_edges", result.graph_edge_count),
        ("graph_route_nodes", len(result.graph_node_path)),
        ("graph_route_edges", len(result.graph_edge_path)),
        ("explored_family_lambdas", len(result.explored_lambda_values)),
        ("family_leaf_motion_edges", result.family_leaf_motion_edge_count),
        ("family_transverse_edges", result.family_transverse_edge_count),
        ("rejected_transverse_attempts", result.rejected_transverse_count),
        ("certified_entry_transitions", result.entry_transition_count),
        ("certified_exit_transitions", result.exit_transition_count),
        ("explored_lambda_region_count", result.explored_lambda_region_count),
        ("explored_lambda_regions", result.explored_lambda_regions),
        ("first_solution_round", result.first_solution_round),
        ("best_solution_round", result.best_solution_round),
        ("continued_after_first_solution", result.continued_after_first_solution),
        ("certified_path_points", len(result.certified_path)),
        ("display_path_points", len(result.display_path)),
        ("path_points", len(result.path)),
        ("raw_path_points", len(result.raw_path)),
        ("strict_validation_message", result.strict_validation_message),
        ("strict_validation_failures", len(result.strict_validation_failures)),
    ]
    for key, value in fields:
        print(f"{key} = {value}")
    for mode_name in sorted(result.exploration_mode_usage):
        print(f"mode_{mode_name} = {result.exploration_mode_usage[mode_name]}")
    for sampler_name in sorted(result.family_space_sampler_usage):
        print(f"family_space_sampler_{sampler_name} = {result.family_space_sampler_usage[sampler_name]}")
    for summary in result.family_cluster_summaries:
        print(f"cluster_summary = {summary}")
    for failure in result.strict_validation_failures:
        print(f"strict_failure = {failure}")


def obstacle_profile_comparison_row(result: ContinuousTransferRoute) -> dict[str, str]:
    """Build one compact comparison row for obstacle-profile falsification runs."""

    return {
        "profile": str(result.scene_profile),
        "success": str(bool(result.success)),
        "primary_entry_lambda": (
            "-"
            if result.primary_entry_lambda is None
            else f"{float(result.primary_entry_lambda):.3f}"
        ),
        "same_leaf_successful_exit_found": str(bool(result.same_leaf_successful_exit_found)),
        "same_leaf_stagnation_triggered": str(bool(result.same_leaf_stagnation_triggered)),
        "first_transverse_switch_reason": (
            "-" if result.first_transverse_switch_reason is None else str(result.first_transverse_switch_reason)
        ),
        "transverse_switch_reason_counts": (
            "-"
            if len(result.transverse_switch_reason_counts) == 0
            else ",".join(
                f"{key}:{result.transverse_switch_reason_counts[key]}"
                for key in sorted(result.transverse_switch_reason_counts)
            )
        ),
        "explored_lambda_regions": (
            "-"
            if len(result.explored_lambda_regions) == 0
            else ",".join(result.explored_lambda_regions)
        ),
        "final_route_same_leaf_only": str(bool(result.final_route_same_leaf_only)),
    }


def print_obstacle_profile_comparison(results: list[ContinuousTransferRoute]) -> None:
    """Print a compact comparison table for systematic obstacle-profile runs."""

    if len(results) == 0:
        return
    rows = [obstacle_profile_comparison_row(result) for result in results]
    columns = [
        "profile",
        "success",
        "primary_entry_lambda",
        "same_leaf_successful_exit_found",
        "same_leaf_stagnation_triggered",
        "first_transverse_switch_reason",
        "transverse_switch_reason_counts",
        "explored_lambda_regions",
        "final_route_same_leaf_only",
    ]
    widths = {
        column: max(len(column), *(len(str(row[column])) for row in rows))
        for column in columns
    }
    header = " | ".join(column.ljust(widths[column]) for column in columns)
    divider = "-+-".join("-" * widths[column] for column in columns)
    print(header)
    print(divider)
    for row in rows:
        print(" | ".join(str(row[column]).ljust(widths[column]) for column in columns))
