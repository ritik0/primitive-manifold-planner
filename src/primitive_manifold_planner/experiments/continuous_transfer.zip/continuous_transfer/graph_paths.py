"""Graph-path utilities for the continuous-transfer experiment.

This module owns graph-centric route queries such as shortest-path extraction.
It stays intentionally small so planner orchestration can depend on path queries
without also importing route scoring or geometry shaping code.
"""

from __future__ import annotations

import heapq

from .graph_types import FamilyConnectivityGraph


def shortest_path_over_graph(
    graph: FamilyConnectivityGraph,
    start_node_id: int,
    goal_node_id: int,
) -> tuple[float, list[int], list[int]]:
    dist = {int(start_node_id): 0.0}
    parent_node: dict[int, int] = {}
    parent_edge: dict[int, int] = {}
    queue: list[tuple[float, int]] = [(0.0, int(start_node_id))]
    while queue:
        current_dist, node_id = heapq.heappop(queue)
        if current_dist > dist.get(node_id, float("inf")) + 1e-12:
            continue
        if node_id == int(goal_node_id):
            break
        for edge_id in graph.adjacency.get(node_id, []):
            edge = graph.edges[edge_id]
            other = edge.node_v if edge.node_u == node_id else edge.node_u
            new_dist = float(current_dist + edge.cost)
            if new_dist + 1e-12 >= dist.get(other, float("inf")):
                continue
            dist[other] = new_dist
            parent_node[other] = node_id
            parent_edge[other] = edge_id
            heapq.heappush(queue, (new_dist, other))
    if int(goal_node_id) not in dist:
        return float("inf"), [], []
    node_path = [int(goal_node_id)]
    edge_path: list[int] = []
    cursor = int(goal_node_id)
    while cursor != int(start_node_id):
        edge_id = parent_edge[cursor]
        prev = parent_node[cursor]
        edge_path.append(edge_id)
        node_path.append(prev)
        cursor = prev
    node_path.reverse()
    edge_path.reverse()
    return float(dist[int(goal_node_id)]), node_path, edge_path
